import sys
import os

def splitData(file_name, store_id):
	infile = open(file_name,'rU')
	weather_lines = infile.read().split("\n")
	ind = 0
	print len(weather_lines)
	while(ind != len(weather_lines)-1 and weather_lines[ind].split(",")[0] != store_id):
		ind += 1
	if(ind < len(weather_lines)-1):
		outfile = open("weather_data_store"+store_id+".csv",'w')
		for index in range(len(weather_lines)):
			if(weather_lines[index].split(",")[0] == store_id):
				outfile.write(weather_lines[index]+"\n")
		outfile.close()
		

	infile.close()
	
		 

if __name__ == "__main__":
	if(len(sys.argv) == 0):
		print "Please provide input weather file."
	else :
		file_name = sys.argv[1]
		store_id = sys.argv[2]
		splitData(file_name, store_id)
