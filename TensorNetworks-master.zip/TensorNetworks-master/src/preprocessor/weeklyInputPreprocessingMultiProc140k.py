import datetime
import os
import sys
import numpy as np
import csv
from collections import OrderedDict
import time
#import concurrent.futures
import pandas as pd
import multiprocessing
from multiprocessing import Queue

def getWeatherDict(filename):
	final_dict=OrderedDict(list())
        infile = open(filename,'rU')
        reader = csv.reader(infile, delimiter=',')
        for line in reader:
                indate = line[1]
                if indate not in final_dict :
                        outList = []
                        outList.append(line[3])
                        outList.append(line[6])
                        outList.append(line[9])
                        outList.append(line[12])
                        final_dict[indate] = outList
                else:
                        print "Date repeating......."

	return final_dict


def normalizeWeatherVars(wea_filename):
	print("----------------------------------- Adding normalised weather variables in data set -----------------------------------")
	weatherDict = getWeatherDict(wea_filename)


	# finding max values of each weather parameter.
	max_tmpf = 0.0
        max_dwpf = 0.0
        max_relh = 0.0
        max_prec = 0.0

	for k,v in weatherDict.items():

		tmpf = weatherDict[k][0]
		dwpf = weatherDict[k][1]
		relh = weatherDict[k][2]
		prec = weatherDict[k][3]


		if max_tmpf < float(tmpf):
			max_tmpf = float(tmpf)
		if max_dwpf < float(dwpf):
                        max_dwpf = float(dwpf)
		if max_relh < float(relh):
                        max_relh = float(relh)
		if max_prec < float(prec):
                        max_prec = float(prec)

	for k,v in weatherDict.items():
		if max_tmpf !=0	:
			weatherDict[k][0] = float(weatherDict[k][0])/max_tmpf
		else :
			weatherDict[k][0] = 0

		if max_dwpf !=0 :
                        weatherDict[k][1] = float(weatherDict[k][1])/max_dwpf
                else :
                        weatherDict[k][1] = 0

		if max_relh !=0 :
                        weatherDict[k][2] = float(weatherDict[k][2])/max_relh
                else :
                        weatherDict[k][2] = 0

		if max_prec !=0 :
                        weatherDict[k][3] = float(weatherDict[k][3])/max_prec
                else :
                        weatherDict[k][3] = 0

	return weatherDict



def aggregateWeatherDataWeekly(weatherDict):
	print("----------------------------------- Aggregating daily level data weather data to weekly level -----------------------------------")

	aggrWeatherDict = OrderedDict(list())
	indate = weatherDict.keys()[0]
	week_list = weatherDict[indate]

	indate = datetime.datetime.strptime(indate,'%Y-%m-%d')
        wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
        wk_end_date = wk_start_date + datetime.timedelta(days = 6)


	counter = 1
	for index in range(len(weatherDict)):
		keyDate = weatherDict.keys()[index]
		indate = datetime.datetime.strptime(weatherDict.keys()[index],'%Y-%m-%d')
		if(indate >= wk_start_date and indate <= wk_end_date):
			if(index!=0):
				counter = counter + 1
				curr_list = weatherDict[keyDate]

				for colindex in range(len(week_list)):
					week_list[colindex] = float(week_list[colindex]) + float(curr_list[colindex])


		else :
			# It is the 1st day of week.
			# Averaging weather variables.
			week_list[0] = float(week_list[0])/float(counter)
			week_list[1] = float(week_list[1])/float(counter)
			week_list[2] = float(week_list[2])/float(counter)
			week_list[3] = float(week_list[3])/float(counter)

			counter = 1
			#week_list.append(wk_start_date)
			week_list.append(wk_end_date.strftime('%Y-%m-%d'))


			#converting wk_start_dt to string and storing as a key in dictionary.
			dictKey = wk_start_date.strftime('%Y-%m-%d')
			if dictKey not in aggrWeatherDict:
                                aggrWeatherDict[dictKey] = week_list

                        wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
                        wk_end_date = wk_start_date + datetime.timedelta(days = 6)
			week_list = weatherDict[keyDate]


	return aggrWeatherDict


def printDict(dict):
	for index in range(len(dict)):
		print(str(dict.keys()[index])+' ------> '+str(dict[dict.keys()[index]]))


def mergeWeatherAndInput(input_data, aggr_wea_dict):

	print "------------- merging -------------"
	list1 = ['0','0','0','0','0']  # four weather variables and last is week end date.

        for index in range(len(input_data)):
                indate = input_data[index][29] # -2 b/c of removing cwl vars. (initially 31)
                if indate in weatherDict:
                        input_data[index] = input_data[index] + weatherDict[indate]
                else:
                        input_data[index] = input_data[index] + list1

        return input_data

def computeAutoRegAndSeasonlityVar(aggr_list):
	print("----------------------------------- Adding Autoregression variables in data set -----------------------------------")

	#Find lowest date in dataset
	lowest_date = datetime.datetime.strptime(aggr_list[0][29],"%Y-%m-%d")

	for index in range(len(aggr_list)):
		curr_line = aggr_list[index]
		curr_wk_st_date = datetime.datetime.strptime(curr_line[29],"%Y-%m-%d")
		curr_wk_en_date = curr_wk_st_date + datetime.timedelta(days = 6)



		# Christmas day
		if(curr_wk_st_date.day <= 25 and curr_wk_en_date.day >= 25 and curr_wk_st_date.month == 12):
			aggr_list[index].append(1)
		else :
			aggr_list[index].append(0)



		# Easter Day
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d')):
                	aggr_list[index].append(1)
		else :
                       	aggr_list[index].append(0)


		# Thanks giving
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d')):
               		aggr_list[index].append(1)
		else :
                       	aggr_list[index].append(0)


		# Cyber monday
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
               	else :
                       	aggr_list[index].append(0)


		# Amazon Prime
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
              	else :
                       	aggr_list[index].append(0)


		# 4th july sale
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
                else :
                       	aggr_list[index].append(0)


		# 25th May sale
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
               	else :
                       	aggr_list[index].append(0)


		if(aggr_list[index][4]!='NULL'):			# Sales Quantity should not be NULL.

			# Number of weeks since last sale
                	num_days = 0
                	temp = index-1
                        #print temp
                	if(temp == -1):
                        	aggr_list[index].append(0)
                	else:
                        	while(temp != 0 and float(aggr_list[temp][4]) == 0.0):
                                	num_days += 1
                                	temp -= 1
                        	aggr_list[index].append(num_days)


              		# Sale bucket
                	if(float(aggr_list[index][4]) == 0.0):
                        	aggr_list[index].append(0)
                	elif(float(aggr_list[index][4]) == 1.0):
                        	aggr_list[index].append(1)
                	elif(float(aggr_list[index][4]) == 2.0):
                        	aggr_list[index].append(2)
                	elif(float(aggr_list[index][4]) == 3.0):
                        	aggr_list[index].append(3)
                	elif(float(aggr_list[index][4]) == 4.0):
                        	aggr_list[index].append(4)
                	elif(float(aggr_list[index][4]) >= 5.0):
                        	aggr_list[index].append(5)



			# 4 week moving Average
			delta = datetime.timedelta(days=28)
			sum = 0
			if((curr_wk_st_date - delta) >= lowest_date):
				for index1 in range(index-4,index):
					sum = sum + float(aggr_list[index1][4])

				aggr_list[index].append((sum/4.0))
			else :
				aggr_list[index].append(0)


			# 1 Week lag
			delta = datetime.timedelta(days=7)
			if((curr_wk_st_date - delta) >= lowest_date):
				aggr_list[index].append(aggr_list[index-1][4])
			else :
				aggr_list[index].append(0)


			# 2 Week lag
			delta = datetime.timedelta(days=14)
                	if((curr_wk_st_date - delta) >= lowest_date):
                        	aggr_list[index].append(aggr_list[index-2][4])
                	else :
                        	aggr_list[index].append(0)


			# 7 Week lag
			delta = datetime.timedelta(days=49)
                	if((curr_wk_st_date - delta) >= lowest_date):
                        	aggr_list[index].append(aggr_list[index-7][4])
                	else :
                 		aggr_list[index].append(0)

		else:
			print "Sales quantity is null"


	# Centered Value of 4 week moving average
	for index in range(len(aggr_list)):

		curr_line = aggr_list[index]
		curr_wk_st_date = datetime.datetime.strptime(curr_line[29],"%Y-%m-%d")
                curr_wk_en_date = curr_wk_st_date + datetime.timedelta(days = 6)

		delta = datetime.timedelta(days=21)
		if((curr_wk_st_date - delta) >= lowest_date and index < len(aggr_list)-1):
			cen_val = float(aggr_list[index-1][46]) + float(aggr_list[index][46]) + float(aggr_list[index+1][46])
			aggr_list[index].append(float(cen_val)/3.0)
		else :
			aggr_list[index].append(0)


	return aggr_list




def listToCsv(out_file, complete_list):
	outfile = open(out_file+'_output.csv','w')

	for index in range(len(complete_list)):
		line = ''
		curr_line = complete_list[index]
		for index2 in range(len(curr_line)):
			if(index2==0):
				line = str(curr_line[index2])
			elif(index2 == (len(curr_line)-1) and index != len(complete_list)-1):
				line = line +','+str(curr_line[index2])+'\n'
			else :
				line = line +','+str(curr_line[index2])

		outfile.write(line)


def get_colNames():
	return ["mdse_item_i",
		"mdse_clas_i",
		"co_loc_i",
		"sls_retl_a",
		"sls_unit_q",
		"fcg_q",
		"boh_q",
		"clearance_pct",
		"max_promo_daynr",
		"max_promo_pctoff",
		"max_promo_dollaroff",
		"max_external_pctoff",
		"max_external_dollaroff",
		#"cwl_offer_daynr",
		#"cwl_pct_off",
		"circular_flag",
		"circular_flag_count",
		"tpc_flag",
		"tpc_flag_count",
		"clearance_flag",
		"clearance_flag_count",
		"dollar_off_flag",
		"dollar_off_flag_count",
		"free_product_flag",
		"free_product_flag_count",
		"pct_off_flag",
		"pct_off_flag_count",
		"giftcard_flag",
		"giftcard_flag_count",
		"external_promo_flag",
		"external_promo_flag_count",
		"week_start_date",
		#"ooo_flag",
		"mode",
		"mdse_dept_ref_i"]

# aggr_wea_dict:
# file_name: sales data names
# df: input data for all depts, sorted by item and wk start date
# dept_id: department id (int)
# queue: to communicate master and its subprocess
def run(aggr_wea_dict, file_name, df, dept_id, queue):
	print "---extracting data for dept=%s---" % (dept_id)
	input_data=df.loc[df['mdse_dept_ref_i'] == dept_id].values.tolist()
	aggr_list = mergeWeatherAndInput(input_data, aggr_wea_dict)
	complete_list = computeAutoRegAndSeasonlityVar(aggr_list)
    queue.put(complete_list)

def convertToList(data_frame):
	return data_frame.values.tolist()

def convertToCSV(output_data, out_file_name):
	print "----------- Writing to CSV ----------------"
	with open(out_file_name, 'w') as csvfile:
		csvwriter=csv.writer(csvfile, delimiter=',')
		csvwriter.writerows(output_data)


if __name__ == "__main__":
        start=time.time()
	if(len(sys.argv) != 4):
		print "Please provide proper inputs in order <filename> <store id> <weather file name>"
	else :
		file_name = sys.argv[1]
		store_id = sys.argv[2]
		wea_filename = sys.argv[3]
		if(os.stat(file_name).st_size == 0):
			print("No data available for this store department and class............")
		elif(os.stat(wea_filename).st_size == 0):
			print("No weather data available for this store ............")
		else:
			# create weather dict
			weatherDict = normalizeWeatherVars(wea_filename)
			aggr_wea_dict = aggregateWeatherDataWeekly(weatherDict)

			# split sales data into each dept
			depts=[3,7,37,49,52,55,63,71,83,94,203,212,213,231,245,253,261]
			colNames=get_colNames()
			df = pd.read_csv(file_name, names=colNames)

			#! multi process
			jobs=[]
			output_data=[]
			for i in range(len(depts)):
                q = Queue()
				#p=multiprocessing.Process(target=run, args=(weatherDict, file_name, data[i],q))
				p=multiprocessing.Process(target=run, args=(aggr_wea_dict, file_name, df, depts[i],q))
				jobs.append((p,q))
				p.start()
                for item,queue in jobs:
                    result = queue.get()
				    output_data.extend(result)
		          	item.join() # wait until all processes are completed

			out_file_name=file_name.split(".")[0] + "_output.csv"
			convertToCSV(output_data, out_file_name)
			print "elapsed time within python script = %s" % (time.time()- start)
			#os.remove(stage_file_names)
			print "done."

