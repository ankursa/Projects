import datetime
import os
import sys
import numpy as np
from sklearn.preprocessing import normalize
import csv


def addNormalizedWeatherVars(store_id, wea_filename,file_name): 
	print("----------------------------------- Adding normalised weather variables in data set -----------------------------------")
 	print wea_filename
	

	weather_file = open(wea_filename,'rU')
        mainfile = open(file_name,'rU')
        mainfile_lines = mainfile.read().split("\n")
        weather_lines = weather_file.read().split("\n")
        output_file = open(file_name.split(".")[0]+'_output1.csv','w')


	dt = []
	tmpf = []
	dwpf = []
	relh = []
	prec = []
	vsby = []

        #Taking each column as numpy array
        for index in range(len(weather_lines)-1):
		if(int(weather_lines[index].split(",")[0]) == int(store_id)):
			dt.append(str(weather_lines[index].split(",")[1]))
			tmpf.append(float(weather_lines[index].split(",")[3]))
			dwpf.append(float(weather_lines[index].split(",")[6]))
			relh.append(float(weather_lines[index].split(",")[9]))
			prec.append(float(weather_lines[index].split(",")[12]))
			vsby.append(float(weather_lines[index].split(",")[15]))

        max_tmpf = max(tmpf)
        max_dwpf = max(dwpf)
        max_relh = max(relh)
        max_prec = max(prec)
        max_vsby = max(vsby)
	
	
	#Normalised weather data
        for index in range(len(weather_lines)-1):
		if max_tmpf!=0:
                        tmpf[index] = float(tmpf[index])/float(max_tmpf)
                else:
                        tmpf[index] = 0.0

                if max_dwpf!=0:
                        dwpf[index] = float(dwpf[index])/float(max_dwpf)
                else:
                        dwpf[index] = 0.0

                if max_relh!=0:
                        relh[index] = float(relh[index])/float(max_relh)
                else:
                        relh[index] = 0.0

                if max_prec!=0:
                        prec[index] = float(prec[index])/float(max_prec)
                else:
                        prec[index] = 0.0
                
                if max_vsby!=0:
                        vsby[index] = float(vsby[index])/float(max_vsby)
                else:
                        vsby[index] = 0.0

	
        for index1 in range(len(mainfile_lines)-1):
                main_date = mainfile_lines[index1].split(",")[16]
                main_date = datetime.datetime.strptime(main_date,"%Y-%m-%d")
                for index2 in range(len(weather_lines)-1):
                        weather_date = datetime.datetime.strptime(dt[index2],"%Y-%m-%d")
                        if(main_date == weather_date):
                                mainfile_lines[index1] = mainfile_lines[index1]+','+str(tmpf[index2])+','+str(dwpf[index2])+','+str(relh[index2])+','+str(prec[index2])+','+str(vsby[index2])
                                output_file.write(mainfile_lines[index1]+"\n")
                                break;

			elif(index2 == len(weather_lines)-2):
				mainfile_lines[index1] = mainfile_lines[index1]+',0,0,0,0,0'
				output_file.write(mainfile_lines[index1]+"\n")
				
	
	
        weather_file.close()
        mainfile.close()
        output_file.close()





def aggregateWeeklyData():
	print("----------------------------------- Aggregating daily level data to weekly level -----------------------------------")
	if(os.stat(file_name.split(".")[0]+"_output1.csv").st_size != 0):
		infile = open(file_name.split(".")[0]+"_output1.csv",'rU')
		outfile = open(file_name.split(".")[0]+"_output2.csv", 'w')
		lines = infile.read().split("\n")
		indate = datetime.datetime.strptime(lines[0].split(",")[16],'%Y-%m-%d')
        	wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
        	wk_end_date = wk_start_date + datetime.timedelta(days = 6)
		tokens = lines[0].split(",")
		wkly_line = tokens[0]+','+tokens[1]+','+str(wk_start_date)+','+str(wk_end_date)+','+tokens[5]+','+tokens[6]+','+tokens[7]+','+tokens[8]+','+tokens[9]+','+tokens[10]+','+tokens[11]+','+tokens[12]+','+tokens[13]+','+tokens[14]+','+tokens[17]+','+tokens[18]+','+tokens[19]+','+tokens[20]+','+tokens[21]+','+tokens[22]+','+tokens[23]+','+tokens[24]+','+tokens[25]
		counter = 1	
		for index in range(0,len(lines)-1):
			indate = datetime.datetime.strptime(lines[index].split(",")[16],'%Y-%m-%d')
			if(indate >= wk_start_date and indate <= wk_end_date):	
				if(index!=0):
					counter = counter + 1 
					tokens = lines[index].split(",")
					wk_token = wkly_line.split(',')
				
					#Adding 10 promotion varibales
					for colindex in range(4,14):
						wk_token[colindex] = int(wk_token[colindex]) + int(tokens[colindex+1])
			
					# Adding sales quatity variable
                                	wk_token[14] = float(wk_token[14]) + float(tokens[17])
				
					# Adding temp variables
					for colindex in range(18,23):
						wk_token[colindex] = float(wk_token[colindex]) + float(tokens[colindex+3])
					
			
					wkly_line = wk_token[0]+','+str(wk_token[1])+','+str(wk_token[2])+','+str(wk_token[3])+','+str(wk_token[4])+','+str(wk_token[5])+','+str(wk_token[6])+','+str(wk_token[7])+','+str(wk_token[8])+','+str(wk_token[9])+','+str(wk_token[10])+','+str(wk_token[11])+','+str(wk_token[12])+','+str(wk_token[13])+','+str(wk_token[14])+','+str(wk_token[15])+','+str(wk_token[16])+','+str(wk_token[17])+','+str(wk_token[18])+','+str(wk_token[19])+','+str(wk_token[20])+','+str(wk_token[21])+','+str(wk_token[22])
			
			else :
				# It is the 1st day of week.
				# Averaging weather variables.
				wk_token = wkly_line.split(",")
				wkly_line = wk_token[0]+','+str(wk_token[1])+','+str(wk_token[2])+','+str(wk_token[3])+','+str(wk_token[4])+','+str(wk_token[5])+','+str(wk_token[6])+','+str(wk_token[7])+','+str(wk_token[8])+','+str(wk_token[9])+','+str(wk_token[10])+','+str(wk_token[11])+','+str(wk_token[12])+','+str(wk_token[13])+','+str(wk_token[14])+','+str(wk_token[15])+','+str(wk_token[16])+','+str(wk_token[17])+','+str(float(wk_token[18])/counter)+','+str(float(wk_token[19])/counter)+','+str(float(wk_token[20])/counter)+','+str(float(wk_token[21])/counter)+','+str(float(wk_token[22])/counter)
			
				counter = 1
			
				outfile.write(wkly_line+'\n')
                        	wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
                        	wk_end_date = wk_start_date + datetime.timedelta(days = 6)
				tokens = lines[index].split(",")
				wkly_line = tokens[0]+','+tokens[1]+','+str(wk_start_date)+','+str(wk_end_date)+','+tokens[5]+','+tokens[6]+','+tokens[7]+','+tokens[8]+','+tokens[9]+','+tokens[10]+','+tokens[11]+','+tokens[12]+','+tokens[13]+','+tokens[14]+','+tokens[17]+','+tokens[18]+','+tokens[19]+','+tokens[20]+','+tokens[21]+','+tokens[22]+','+tokens[23]+','+tokens[24]+','+tokens[25]
		

		outfile.write(wkly_line)
		infile.close()
		outfile.close()
		return 1

	else:
		print("Intermediate file [_output2] file is empty.")
		return 0



def computeAutoRegAndSeasonlityVar(file_name):
	print("----------------------------------- Adding Autoregression variables in data set -----------------------------------")
	if(os.stat(file_name.split(".")[0]+"_output2.csv").st_size != 0):
		infile = open(file_name.split(".")[0]+"_output2.csv", 'rU')
		line = infile.read().split("\n")
	


		#Find lowest date in dataset
		wk_str_date = datetime.datetime.strptime(line[0].split(",")[2],'%Y-%m-%d %H:%M:%S')
		outfile = open(file_name.split(".")[0]+"_output2.csv", 'w')
		for index in range(0,len(line)-1):
			curr_line = line[index].split(",")
			curr_date = datetime.datetime.strptime(curr_line[2], '%Y-%m-%d %H:%M:%S')

			
			# Number of weeks since last sale
			num_days = 0
			temp = index-1
			if(temp == -1):
				line[index] = line[index]+",0"
			else:
				while(temp != 0 and float(line[temp].split(",")[14]) == 0.0):
					num_days += 1
					temp -= 1
				line[index] = line[index]+","+str(num_days)
		
		
			# Sale bucket
		
			if(float(line[index].split(",")[14]) == 0):
				line[index] = line[index]+',0'
			elif(float(line[index].split(",")[14]) == 1):
				line[index] = line[index]+',1'
			elif(float(line[index].split(",")[14]) == 2):
				line[index] = line[index]+',2'
			elif(float(line[index].split(",")[14]) == 3):
				line[index] = line[index]+',3'
			elif(float(line[index].split(",")[14]) == 4):
				line[index] = line[index]+',4'
			elif(float(line[index].split(",")[14]) >= 5):
				line[index] = line[index]+',5'

			
		
			# Christmas day
			start_date = datetime.datetime.strptime(curr_line[2], '%Y-%m-%d %H:%M:%S')
			end_date = datetime.datetime.strptime(curr_line[3], '%Y-%m-%d %H:%M:%S')
			if(start_date.day <= 25 and end_date.day >= 25 and start_date.month == 12):
				line[index] = line[index]+",1"
			else :
				line[index] = line[index]+",0"
	


			# Easter Day
			if(start_date <= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d')):  
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"
		

			# Thanks giving
			if(start_date <= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
               	 	else :
                        	line[index] = line[index]+",0"


			# Cyber monday
			if(start_date <= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"

	
			# Amazon Prime
			if(start_date <= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
              	  	else :
                        	line[index] = line[index]+",0"	


			# 4th july sale
			if(start_date <= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"


			# 25th May sale
			if(start_date <= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"


			# 4 week moving Average
			delta = datetime.timedelta(days=28)
			sum = 0
			if((curr_date - delta) >= wk_str_date):
				for index1 in range(index-4,index):
					sum = sum + float(line[index1].split(",")[14])
			
				line[index] = line[index]+","+str(sum/4.0)
			else :
				line[index] = line[index]+",0"


			# 1 Week lag
			delta = datetime.timedelta(days=7)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-1].split(",")[14]
			else : 
				line[index] = line[index]+",0"	


			# 2 Week lag
			delta = datetime.timedelta(days=14)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-2].split(",")[14]
			else : 
				line[index] = line[index]+",0"


			# 7 Week lag
			delta = datetime.timedelta(days=49)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-7].split(",")[14]
			else : 
				line[index] = line[index]+",0"

		
			outfile.write(line[index]+"\n")


		infile.close()
		outfile.close()


		# Finding centered value of 4 week moving average.

		infile = open(file_name.split(".")[0]+'_output2.csv', 'rU')
		line = infile.read().split("\n")
		four_wk_mvg_avg_list = range(len(line)-1)
		
		outfile = open(file_name.split(".")[0]+'_output3.csv' , 'w')
		outfile.write("A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,AA,AB,AC,AD,AE,AF,AG,AH,AI,AJ,AK"+'\n')
	
		for index in range(0,len(line)-1):
			four_wk_mvg_avg_list[index] = line[index].split(",")[32]

		for index in range(0,len(line)-1):
			curr_line = line[index].split(",")
                	curr_date = datetime.datetime.strptime(curr_line[2], '%Y-%m-%d %H:%M:%S')
			delta = datetime.timedelta(days=7)
			if((curr_date - delta) >= wk_str_date and index < len(line)-2):
				cen_val =  float(four_wk_mvg_avg_list[index-1]) + float(four_wk_mvg_avg_list[index]) + float(four_wk_mvg_avg_list[index+1])
				line[index] = line[index]+ "," + str(cen_val/3.0)
			else : 
				line[index] = line[index] + "," + four_wk_mvg_avg_list[index]	

			outfile.write(line[index]+"\n")
		infile.close()
		outfile.close()
		return 1
	else:
                print("Intermediate file [_output3] is empty.")
		return 0



def reorderingOutput(file_name,store_id):
	with open(file_name, 'r') as infile, open("data_S"+store_id+'.csv','w') as outfile:
		fieldnames = ['A','B','E','F','G','H','I','J','K','L','M','N','P','Q','R','S','T','U','V','W','X','Z','AA','AB','AC','AD','AE','AF','AG','AH','AI','AJ','AK','C','D','O','Y']
		writer = csv.DictWriter(outfile,fieldnames=fieldnames)
	
		# first 2 rows would be header. so leave it. 
		
		for row in csv.DictReader(infile):
        		# writes the reordered rows to the new file
        		writer.writerow(row)
	



if __name__ == "__main__":
	if(len(sys.argv) != 4):
		print "Please provide proper inputs in order <filename> <store id> <weather file name>"
	else :
		file_name = sys.argv[1]
		store_id = sys.argv[2]
		wea_filename = sys.argv[3]
		if(os.stat(file_name).st_size == 0):
			print("No data available for this store department and class............")
		elif(os.stat(wea_filename).st_size == 0):
			print("No weather data available for this store ............")
		else:
			addNormalizedWeatherVars(store_id, wea_filename, file_name) 	
			aggregateWeeklyData()				# If weather file and input file has different dates. so output2 will be empty file.	
			computeAutoRegAndSeasonlityVar(file_name)
			reorderingOutput(file_name.split(".")[0]+'_output3.csv', store_id)
			os.remove(file_name)
			os.remove(file_name.split(".")[0]+"_output1.csv")
			os.remove(file_name.split(".")[0]+"_output2.csv")
			os.remove(file_name.split(".")[0]+"_output3.csv")
