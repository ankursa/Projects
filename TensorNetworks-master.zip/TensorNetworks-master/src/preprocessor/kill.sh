declare -A machines=( ["0"]="brgn0007.target.com" ["1"]="brgn0008.target.com" ["2"]="brgn0009.target.com" ["3"]="brgn0010.target.com"  ["4"]="brgn0011.target.com" )

ssh z001jv4@brgn0007.target.com "/bin/sh /home_dir/z001jv4/preprocessor/clean.sh"
ssh z001jv4@brgn0008.target.com "/bin/sh /home_dir/z001jv4/preprocessor/clean.sh"
ssh z001jv4@brgn0009.target.com "/bin/sh /home_dir/z001jv4/preprocessor/clean.sh"
ssh z001jv4@brgn0010.target.com "/bin/sh /home_dir/z001jv4/preprocessor/clean.sh"
ssh z001jv4@brgn0011.target.com "/bin/sh /home_dir/z001jv4/preprocessor/clean.sh"
