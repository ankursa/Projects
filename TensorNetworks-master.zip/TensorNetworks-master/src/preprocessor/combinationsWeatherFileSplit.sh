# This script fetching all the combinations of store, department and classes from source table.
# Before running this script please make sure that you have weather file named "weather_data_1y.csv" in the same folder.
# After running this script you will get 1 store list file named "store_list.csv", 1 store department and class file named "store_dept_class_list.csv" and around 1800 weather files. Each file have weather data for each store. eg: weather_file_store3.csv will have weather data for store 3.
# You have to run this file only once. If you get all weather files separatly you dont need to run it again.

#--------------------------------------------------------------------------------------

#Getting list of all stores.
#hive -e "select distinct l.co_loc_i a, l.co_loc_ref_i b from cyno_lstm.store_mapping l, prd_dfe_rnn_train.traindat r where l.co_loc_i=r.co_loc_i order by a" | sed 's/[\t]/,/g' > store_list_new.csv


#hive -e "select distinct l.co_loc_i, r.mdse_dept_ref_i, r.mdse_clas_i from prd_dfe_rnn_train.traindat l, dfe_new_comparison_anm.department_item_list r where l.mdse_item_i=r.mdse_item_i order by l.co_loc_i, r.mdse_dept_ref_i, r.mdse_clas_i" | sed 's/[\t]/,/g' > store_dept_class_list.csv


#Spliting weather file storewise.
IFS=','
while read line
do
        arr=($line)
        echo "************************ Store = ${arr[0]} Ref ID= ${arr[1]}************************"
        python splitStorewiseWeatherdata.py weather_data16-17.csv ${arr[1]}
done < store_list_new.csv

echo "All weather files completed ............................"



