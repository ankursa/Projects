import datetime
import os
import sys
import numpy as np
import csv
from collections import OrderedDict


def getWeatherDict(filename):
	final_dict=OrderedDict(list())
        infile = open(filename,'rU')
        reader = csv.reader(infile, delimiter=',')
        for line in reader:
                indate = line[1]
                if indate not in final_dict :
                        outList = []
                        outList.append(line[3])
                        outList.append(line[6])
                        outList.append(line[9])
                        outList.append(line[12])
                        outList.append(line[15])
                        final_dict[indate] = outList
                else:
                        print "Date repeating......."

	return final_dict
	




def addNormalizedWeatherVars(store_id, wea_filename,file_name): 
	print("----------------------------------- Adding normalised weather variables in data set -----------------------------------")
	weatherDict = getWeatherDict(wea_filename)
	
	# Reading input file in list.
	with open(file_name) as f:	
		reader = csv.reader(f)
		input_data = list(reader)

	# finding max values of each weather parameter.
	max_tmpf = 0.0
        max_dwpf = 0.0
        max_relh = 0.0
        max_prec = 0.0
        max_vsby = 0.0

	for k,v in weatherDict.items():
		
		tmpf = weatherDict[k][0]
		dwpf = weatherDict[k][1]
		relh = weatherDict[k][2]
		prec = weatherDict[k][3]
		vsby = weatherDict[k][4]	
				

		if max_tmpf < float(tmpf):
			max_tmpf = float(tmpf)
		if max_dwpf < float(dwpf):
                        max_dwpf = float(dwpf)
		if max_relh < float(relh):
                        max_relh = float(relh)
		if max_prec < float(prec):
                        max_prec = float(prec)
		if max_vsby < float(vsby):
                        max_vsby = float(vsby)

	for k,v in weatherDict.items():
		if max_tmpf !=0	:
			weatherDict[k][0] = float(weatherDict[k][0])/max_tmpf
		else :
			weatherDict[k][0] = 0
		
		if max_dwpf !=0 :
                        weatherDict[k][1] = float(weatherDict[k][1])/max_dwpf
                else :
                        weatherDict[k][1] = 0
		
		if max_relh !=0 :
                        weatherDict[k][2] = float(weatherDict[k][2])/max_relh
                else :
                        weatherDict[k][2] = 0
		
		if max_prec !=0 :
                        weatherDict[k][3] = float(weatherDict[k][3])/max_prec
                else :
                        weatherDict[k][3] = 0

		if max_vsby !=0 :
                        weatherDict[k][4] = float(weatherDict[k][4])/max_vsby
                else :
                        weatherDict[k][4] = 0
	list1 = ['0','0','0','0','0']	

	for index in range(len(input_data)):
		indate = input_data[index][16]
		if indate in weatherDict:
			input_data[index] = input_data[index] + weatherDict[indate]
		else:
			input_data[index] = input_data[index] + list1

	return input_data




def aggregateWeeklyData(input_data):
	print("----------------------------------- Aggregating daily level data to weekly level -----------------------------------")
	
	aggr_list = []
		
	indate = input_data[0][16]
	indate = datetime.datetime.strptime(indate,'%Y-%m-%d')
        wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
        wk_end_date = wk_start_date + datetime.timedelta(days = 6)

	week_list = input_data[0]


	counter = 1	
	for index in range(len(input_data)):
		indate = datetime.datetime.strptime(input_data[index][16],'%Y-%m-%d')
		if(indate >= wk_start_date and indate <= wk_end_date):	
			if(index!=0):
				counter = counter + 1 
				curr_list = input_data[index]
				
				for colindex in range(len(week_list)):
					if(colindex!=0 and colindex!=1 and colindex!=15 and colindex!=16 and colindex!=17 and colindex!=18 and colindex!=19 and colindex!=20 and colindex<20):
						week_list[colindex] = int(week_list[colindex]) + int(curr_list[colindex])

					if(colindex==17 or colindex > 20):			# For weather variables
						week_list[colindex] = float(week_list[colindex]) + float(curr_list[colindex])

			
		else :
			# It is the 1st day of week.
			# Averaging weather variables.
			week_list[21] = float(week_list[21])/float(counter)
			week_list[22] = float(week_list[22])/float(counter)
			week_list[23] = float(week_list[23])/float(counter)
			week_list[24] = float(week_list[24])/float(counter)
			week_list[25] = float(week_list[25])/float(counter)

			counter = 1
			week_list.append(wk_start_date)
			week_list.append(wk_end_date)
			aggr_list.append(week_list)
				
                        wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
                        wk_end_date = wk_start_date + datetime.timedelta(days = 6)
			
			week_list = input_data[index]

	
	return aggr_list



def computeAutoRegAndSeasonlityVar(aggr_list):
	print("----------------------------------- Adding Autoregression variables in data set -----------------------------------")
	
	#Find lowest date in dataset
	
	lowest_date = aggr_list[0][26]
	
	for index in range(len(aggr_list)):
		curr_line = aggr_list[index]
		curr_wk_st_date = curr_line[26]
		curr_wk_en_date = curr_line[27]

		
		# Number of weeks since last sale
		num_days = 0
		temp = index-1
		if(temp == -1):
			aggr_list[index].append(0)
		else:
			while(temp != 0 and float(aggr_list[temp][17]) == 0.0):
				num_days += 1
				temp -= 1
			aggr_list[index].append(num_days)
		

		# Sale bucket
		if(float(aggr_list[index][17]) == 0.0):
			aggr_list[index].append(0)
		elif(float(aggr_list[index][17]) == 1.0):
			aggr_list[index].append(1)
		elif(float(aggr_list[index][17]) == 2.0):
			aggr_list[index].append(2)
		elif(float(aggr_list[index][17]) == 3.0):
			aggr_list[index].append(3)
		elif(float(aggr_list[index][17]) == 4.0):
			aggr_list[index].append(4)
		elif(float(aggr_list[index][17]) >= 5.0):
			aggr_list[index].append(5)

			
		
		# Christmas day
		if(curr_wk_st_date.day <= 25 and curr_wk_en_date.day >= 25 and curr_wk_st_date.month == 12):
			aggr_list[index].append(1)
		else :
			aggr_list[index].append(0)
	


		# Easter Day
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d')):  
                	aggr_list[index].append(1)
		else :
                       	aggr_list[index].append(0)
		

		# Thanks giving
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d')):
               		aggr_list[index].append(1)
		else :
                       	aggr_list[index].append(0)


		# Cyber monday
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
               	else :
                       	aggr_list[index].append(0)

	
		# Amazon Prime
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-7-12",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
              	else :
                       	aggr_list[index].append(0)


		# 4th july sale
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
                else :
                       	aggr_list[index].append(0)


		# 25th May sale
		if(curr_wk_st_date <= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d') and curr_wk_en_date >= datetime.datetime.strptime("2016-5-25",'%Y-%m-%d')):
                       	aggr_list[index].append(1)
               	else :
                       	aggr_list[index].append(0)


		# 4 week moving Average
		delta = datetime.timedelta(days=28)
		sum = 0
		if((curr_wk_st_date - delta) >= lowest_date):
			for index1 in range(index-4,index):
				sum = sum + float(aggr_list[index1][17])
			
			aggr_list[index].append((sum/4.0))
		else :
			aggr_list[index].append(0)


		# 1 Week lag
		delta = datetime.timedelta(days=7)
		if((curr_wk_st_date - delta) >= lowest_date):
			aggr_list[index].append(aggr_list[index-1][17])
		else : 
			aggr_list[index].append(0)	


		# 2 Week lag
		delta = datetime.timedelta(days=14)
                if((curr_wk_st_date - delta) >= lowest_date):
                        aggr_list[index].append(aggr_list[index-2][17])
                else : 
                        aggr_list[index].append(0)


		# 7 Week lag
		delta = datetime.timedelta(days=49)
                if((curr_wk_st_date - delta) >= lowest_date):
                        aggr_list[index].append(aggr_list[index-7][17])
                else : 
                        aggr_list[index].append(0)
		
		
	# Centered Value of 4 week moving average
	for index in range(len(aggr_list)):
	
		curr_line = aggr_list[index]
                curr_wk_st_date = curr_line[26]
                curr_wk_en_date = curr_line[27]

		delta = datetime.timedelta(days=21)
		if((curr_wk_st_date - delta) >= lowest_date and index < len(aggr_list)-1):
			cen_val = float(aggr_list[index-1][37]) + float(aggr_list[index][37]) + float(aggr_list[index+1][37])
			aggr_list[index].append(float(cen_val)/3.0)
		else :
			aggr_list[index].append(0)


	return aggr_list




def listToCsv(out_file, complete_list):
	outfile = open(out_file+'_output.csv','w')
	
	for index in range(len(complete_list)):
		line = ''
		curr_line = complete_list[index]
		for index2 in range(len(curr_line)):
			if(index2==0):
				line = str(curr_line[index2])
			elif(index2 == (len(curr_line)-1) and index != len(complete_list)-1):
				line = line +','+str(curr_line[index2])+'\n'
			else :
				line = line +','+str(curr_line[index2])

		outfile.write(line)	



if __name__ == "__main__":
	if(len(sys.argv) != 4):
		print "Please provide proper inputs in order <filename> <store id> <weather file name>"
	else :
		file_name = sys.argv[1]
		store_id = sys.argv[2]
		wea_filename = sys.argv[3]
		if(os.stat(file_name).st_size == 0):
			print("No data available for this store department and class............")
		elif(os.stat(wea_filename).st_size == 0):
			print("No weather data available for this store ............")
		else:
			input_data = addNormalizedWeatherVars(store_id, wea_filename, file_name) 	
			aggr_list = aggregateWeeklyData(input_data)		# If weather file and input file has different dates. so output2 will be empty file.	
			complete_list = computeAutoRegAndSeasonlityVar(aggr_list)
			out_file = file_name.split(".")[0]
			listToCsv(out_file, complete_list)
			#os.remove(file_name)
