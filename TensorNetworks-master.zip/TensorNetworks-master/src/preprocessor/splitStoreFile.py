import os
import traceback
import re
import sys


def process(stores_file,num_of_divisions):
   try:
      f = open(stores_file)
      lines = f.readlines()
      f.close()



      lines = [item.replace("\n","") for item in lines]

      divisions = len(lines)/num_of_divisions

      remaining = len(lines) - divisions*num_of_divisions

      start,end = 0,divisions
      for i in range(num_of_divisions):
         try:
            f = open("store_list_%d.csv"%i,'w')
            if i == num_of_divisions-1:
               end += remaining

            sub_lines = lines[start:end]
            for item in sub_lines:
               f.write('%s\n'%item)
            f.close()
            start = end
            end += divisions
         except:
            traceback.print_exc()
   except:
      traceback.print_exc()

if __name__=="__main__": 
	res_file = sys.argv[1]
	num_of_divs = int(sys.argv[2])
	process(res_file,num_of_divs)
