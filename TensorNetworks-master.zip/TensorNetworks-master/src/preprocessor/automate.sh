#!/bin/bash

store_file=$1
num_of_processes=$2
zid=$3
password_file=$4
num_machines=5


python splitStoreFile.py $store_file $num_of_processes

declare -A machines=( ["0"]="brgn0007.target.com" ["1"]="brgn0008.target.com" ["2"]="brgn0009.target.com" ["3"]="brgn0010.target.com"  ["4"]="brgn0011.target.com" )

for (( index=0; index<$num_of_processes; ++index ))
do
	number=$(expr $index % $num_machines)
	echo "process $index in assigned to machine ${machines[$number]}"
	ssh $zid@${machines[$number]} "cd ~/preprocessor && nohup /usr/bin/sh IDF_data_fetching_new.sh store_list_$index.csv $zid $password_file > log_$index.txt 2>&1 &"

done	

