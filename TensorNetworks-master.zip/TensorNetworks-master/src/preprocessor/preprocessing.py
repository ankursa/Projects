import datetime
import os
import sys
import numpy as np
from sklearn.preprocessing import normalize


def addPythonDateToData(file_name):
	print("----------------------------------- Adding Date in to data set -----------------------------------")
	print file_name
	infile = open(file_name,'rU')
	line = infile.read().split("\n")
	if(len(line)!=0):
		outfile = open(file_name.split(".")[0]+"_output1.csv", 'w')
		for index in range(0,len(line)-1):
			curr_line = line[index].split(",")
			line[index] = line[index]+","+curr_line[15]+"-"+curr_line[16]+"-"+curr_line[17] 
			outfile.write(line[index]+"\n")
		
		infile.close()
        	outfile.close()
		return 1
	else:
		print("Input file is empty")
		infile.close()
		return 0	



def addNormalizedWeatherVars(store_id, wea_filename): 
	print("----------------------------------- Adding normalised weather variables in data set -----------------------------------")
 	print wea_filename
	if(os.stat(wea_filename).st_size != 0 and os.stat(file_name.split(".")[0]+"_output1.csv").st_size != 0):
		weather_file = open(wea_filename,'rU')
        	mainfile = open(file_name.split(".")[0]+"_output1.csv",'rU')
        	mainfile_lines = mainfile.read().split("\n")
        	weather_lines = weather_file.read().split("\n")
        	output_file = open(file_name.split(".")[0]+'_output2.csv','w')

		dt = []
		tmpf = []
		dwpf = []
		relh = []
		prec = []
		vsby = []

        	#Taking each column as numpy array
        	for index in range(len(weather_lines)-1):
			if(int(weather_lines[index].split(",")[0]) == int(store_id)):
				dt.append(str(weather_lines[index].split(",")[1]))
				tmpf.append(float(weather_lines[index].split(",")[3]))
				dwpf.append(float(weather_lines[index].split(",")[6]))
				relh.append(float(weather_lines[index].split(",")[9]))
				prec.append(float(weather_lines[index].split(",")[12]))
				vsby.append(float(weather_lines[index].split(",")[15]))

        	max_tmpf = max(tmpf)
        	max_dwpf = max(dwpf)
        	max_relh = max(relh)
        	max_prec = max(prec)
        	max_vsby = max(vsby)
	
		#Normalised weather data
        	for index in range(len(weather_lines)-1):
                	tmpf[index] = float(tmpf[index])/float(max_tmpf)
                	dwpf[index] = float(dwpf[index])/float(max_dwpf)
                	relh[index] = float(relh[index])/float(max_relh)
                	prec[index] = float(prec[index])/float(max_prec)
                	vsby[index] = float(vsby[index])/float(max_vsby)

        	for index1 in range(len(mainfile_lines)-1):
                	main_date = mainfile_lines[index1].split(",")[19]
                	main_date = datetime.datetime.strptime(main_date,"%Y-%m-%d")
                	for index2 in range(len(tmpf)-1):
                        	weather_date = dt[index2]
                        	weather_date = datetime.datetime.strptime(weather_date,"%Y-%m-%d")
                        	if(main_date == weather_date):
                                	mainfile_lines[index1] = mainfile_lines[index1]+','+str(tmpf[index2])+','+str(dwpf[index2])+','+str(relh[index2])+','+str(prec[index2])+','+str(vsby[index2])

                                	output_file.write(mainfile_lines[index1]+"\n")
                                	break;



        	weather_file.close()
        	mainfile.close()
        	output_file.close()
		return 1

	else:
		print("Either weather file or intermediate [_output1] file is empty.")
		return 0




def aggregateWeeklyData():
	print("----------------------------------- Aggregating daily level data to weekly level -----------------------------------")
	if(os.stat(file_name.split(".")[0]+"_output2.csv").st_size != 0):
		infile = open(file_name.split(".")[0]+"_output2.csv",'rU')
		outfile = open(file_name.split(".")[0]+"_output3.csv", 'w')
		lines = infile.read().split("\n")
		indate = datetime.datetime.strptime(lines[0].split(",")[19],'%Y-%m-%d')
        	wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
        	wk_end_date = wk_start_date + datetime.timedelta(days = 6)
		tokens = lines[0].split(",")
		wkly_line = tokens[0]+','+str(wk_start_date)+','+str(wk_end_date)+','+tokens[4]+','+tokens[5]+','+tokens[6]+','+tokens[7]+','+tokens[8]+','+tokens[9]+','+tokens[10]+','+tokens[11]+','+tokens[12]+','+tokens[13]+','+tokens[18]+','+tokens[20]+','+tokens[21]+','+tokens[22]+','+tokens[23]+','+tokens[24]
		counter = 1	
		for index in range(0,len(lines)-1):
			indate = datetime.datetime.strptime(lines[index].split(",")[19],'%Y-%m-%d')
			if(indate >= wk_start_date and indate <= wk_end_date):	
				if(index!=0):
					counter = counter + 1 
					tokens = lines[index].split(",")
					wk_token = wkly_line.split(',')
				
					#Adding 10 promotion varibales
					for colindex in range(3,13):
						wk_token[colindex] = int(wk_token[colindex]) + int(tokens[colindex+1])
			
					# Adding sales quatity variable
                                	wk_token[13] = float(wk_token[13]) + float(tokens[18])
				
					# Adding temp variables
					for colindex in range(14,19):
						wk_token[colindex] = float(wk_token[colindex]) + float(tokens[colindex+6])
					
			
					wkly_line = wk_token[0]+','+str(wk_token[1])+','+str(wk_token[2])+','+str(wk_token[3])+','+str(wk_token[4])+','+str(wk_token[5])+','+str(wk_token[6])+','+str(wk_token[7])+','+str(wk_token[8])+','+str(wk_token[9])+','+str(wk_token[10])+','+str(wk_token[11])+','+str(wk_token[12])+','+str(wk_token[13])+','+str(wk_token[14])+','+str(wk_token[15])+','+str(wk_token[16])+','+str(wk_token[17])+','+str(wk_token[18])
			
			else :
				# It is the 1st day of week.
				# Averaging weather variables.
				wk_token = wkly_line.split(",")
				wkly_line = wk_token[0]+','+str(wk_token[1])+','+str(wk_token[2])+','+str(wk_token[3])+','+str(wk_token[4])+','+str(wk_token[5])+','+str(wk_token[6])+','+str(wk_token[7])+','+str(wk_token[8])+','+str(wk_token[9])+','+str(wk_token[10])+','+str(wk_token[11])+','+str(wk_token[12])+','+str(wk_token[13])+','+str(float(wk_token[14])/counter)+','+str(float(wk_token[15])/counter)+','+str(float(wk_token[16])/counter)+','+str(float(wk_token[17])/counter)+','+str(float(wk_token[18])/counter)
			
				counter = 1
			
				outfile.write(wkly_line+'\n')
                        	wk_start_date = indate - datetime.timedelta(days=(indate.weekday()+1)%7)
                        	wk_end_date = wk_start_date + datetime.timedelta(days = 6)
				tokens = lines[index].split(",")
				wkly_line = tokens[0]+','+str(wk_start_date)+','+str(wk_end_date)+','+tokens[4]+','+tokens[5]+','+tokens[6]+','+tokens[7]+','+tokens[8]+','+tokens[9]+','+tokens[10]+','+tokens[11]+','+tokens[12]+','+tokens[13]+','+tokens[18]+','+tokens[20]+','+tokens[21]+','+tokens[22]+','+tokens[23]+','+tokens[24]
		

		outfile.write(wkly_line)
		infile.close()
		outfile.close()
		return 1

	else:
		print("Intermediate file [_output2] file is empty.")
		return 0



def computeAutoRegAndSeasonlityVar(file_name):
	print("----------------------------------- Adding Autoregression variables in data set -----------------------------------")
	if(os.stat(file_name.split(".")[0]+"_output3.csv").st_size != 0):
		infile = open(file_name.split(".")[0]+"_output3.csv", 'rU')
		line = infile.read().split("\n")
	


		#Find lowest date in dataset
		wk_str_date = datetime.datetime.strptime(line[0].split(",")[1],'%Y-%m-%d %H:%M:%S')
		outfile = open(file_name.split(".")[0]+"_output3.csv", 'w')
		for index in range(0,len(line)-1):
			curr_line = line[index].split(",")
			curr_date = datetime.datetime.strptime(curr_line[1], '%Y-%m-%d %H:%M:%S')

			
			# Number of weeks since last sale
			num_days = 0
			temp = index-1
			if(temp == -1):
				line[index] = line[index]+",0"
			else:
				while(temp != 0 and float(line[temp].split(",")[13]) == 0.0):
					num_days += 1
					temp -= 1
				line[index] = line[index]+","+str(num_days)
		
		
			# Sale bucket
		
			if(float(line[index].split(",")[13]) == 0):
				line[index] = line[index]+',0'
			elif(float(line[index].split(",")[13]) == 1):
				line[index] = line[index]+',1'
			elif(float(line[index].split(",")[13]) == 2):
				line[index] = line[index]+',2'
			elif(float(line[index].split(",")[13]) == 3):
				line[index] = line[index]+',3'
			elif(float(line[index].split(",")[13]) == 4):
				line[index] = line[index]+',4'
			elif(float(line[index].split(",")[13]) >= 5):
				line[index] = line[index]+',5'

			
		
			# Christmas day
			start_date = datetime.datetime.strptime(curr_line[1], '%Y-%m-%d %H:%M:%S')
			end_date = datetime.datetime.strptime(curr_line[2], '%Y-%m-%d %H:%M:%S')
			if(start_date.day <= 25 and end_date.day >= 25 and start_date.month == 12):
				line[index] = line[index]+",1"
			else :
				line[index] = line[index]+",0"
	


			# Easter Day
			if(start_date <= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-3-27",'%Y-%m-%d')):  
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"
		

			# Thanks giving
			if(start_date <= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-11-26",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
               	 	else :
                        	line[index] = line[index]+",0"


			# Cyber monday
			if(start_date <= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-11-30",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"

	
			# Amazon Prime
			if(start_date.day <= 12 and end_date.day >= 12 and start_date.month == 07):
                        	line[index] = line[index]+",1"
              	  	else :
                        	line[index] = line[index]+",0"	


			# 4th july sale
			if(start_date <= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d') and end_date >= datetime.datetime.strptime("2016-7-4",'%Y-%m-%d')):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"


			# 25th May sale
			if(start_date.day <= 25 and end_date.day >= 25 and start_date.month == 05):
                        	line[index] = line[index]+",1"
                	else :
                        	line[index] = line[index]+",0"


			# 4 week moving Average
			delta = datetime.timedelta(days=28)
			sum = 0
			if((curr_date - delta) >= wk_str_date):
				for index1 in range(index-4,index):
					sum = sum + float(line[index1].split(",")[13])
			
				line[index] = line[index]+","+str(sum/4.0)
			else :
				line[index] = line[index]+",0"


			# 1 Week lag
			delta = datetime.timedelta(days=7)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-1].split(",")[13]
			else : 
				line[index] = line[index]+",0"	


			# 2 Week lag
			delta = datetime.timedelta(days=14)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-2].split(",")[13]
			else : 
				line[index] = line[index]+",0"


			# 7 Week lag
			delta = datetime.timedelta(days=49)
			if((curr_date - delta) >= wk_str_date):
				line[index] = line[index]+","+line[index-7].split(",")[13]
			else : 
				line[index] = line[index]+",0"

		
			outfile.write(line[index]+"\n")


		infile.close()
		outfile.close()


		# Finding centered value of 4 week moving average.

		infile = open(file_name.split(".")[0]+'_output3.csv', 'rU')
		line = infile.read().split("\n")
		four_wk_mvg_avg_list = range(len(line)-1)
		
		outfile = open(file_name.split(".")[0]+'_temp.csv' , 'w')

	
		for index in range(0,len(line)-1):
			four_wk_mvg_avg_list[index] = line[index].split(",")[28]

		for index in range(0,len(line)-1):
			curr_line = line[index].split(",")
                	curr_date = datetime.datetime.strptime(curr_line[1], '%Y-%m-%d %H:%M:%S')
			delta = datetime.timedelta(days=7)
			if((curr_date - delta) >= wk_str_date and index < len(line)-2):
				cen_val =  float(four_wk_mvg_avg_list[index-1]) + float(four_wk_mvg_avg_list[index]) + float(four_wk_mvg_avg_list[index+1])
				line[index] = line[index]+ "," + str(cen_val/3.0)
			else : 
				line[index] = line[index] + "," + four_wk_mvg_avg_list[index]	

			outfile.write(line[index]+"\n")
		infile.close()
		outfile.close()
		return 1
	else:
                print("Intermediate file [_output3] is empty.")
		return 0


if __name__ == "__main__":
	if(len(sys.argv) != 4):
		print "Please provide proper inputs in order <filename> <store id> <weather file name>"
	else :
		file_name = sys.argv[1]
		store_id = sys.argv[2]
		wea_filename = sys.argv[3]
		if(os.stat(file_name).st_size == 0):
			print("No data available for this store department and class............")
		elif(os.stat(wea_filename).st_size == 0):
			print("No weather data available for this store ............")
		else:
			addPythonDateToData(file_name)
			addNormalizedWeatherVars(store_id, wea_filename) 	
			flag = aggregateWeeklyData()				# If weather file and input file has different dates. so output2 will be empty file.	
			if(flag != 0):
				computeAutoRegAndSeasonlityVar(file_name)
				os.remove(file_name.split(".")[0]+"_output3.csv")

			os.remove(file_name)
			os.remove(file_name.split(".")[0]+"_output1.csv")
			os.remove(file_name.split(".")[0]+"_output2.csv")
