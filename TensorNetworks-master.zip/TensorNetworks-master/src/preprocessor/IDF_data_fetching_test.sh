#Fetching data for all stores, all departments and all classes. 

storeFile=$1

IFS=","
while read line
do
        arr=($line)
	
	echo "------------------------------------------ Store = ${arr[0]}, Ref Id = ${arr[1]} ------------------------------------------"
	
        WEA_FILE=weather_data_store${arr[1]}.csv
	
	if [ -f "$WEA_FILE" ]
	then

        		echo "------------------ Getting new tickets ----------------------------"
        		kdestroy
        		cat ~/.mypass | kinit Z001L92@CORP.TARGET.COM
        		klist

        		echo "------------------------------------------ Data Fetching ------------------------------------------"
			hive -e "select * from cyno_lstm.sales_data2 where co_loc_i=${arr[0]} and (mdse_dept_ref_i=3 or mdse_dept_ref_i=7 or mdse_dept_ref_i=49) order by mdse_item_i,sls_d" | sed 's/[\t]/,/g' > data_S${arr[0]}_D3_7_49.csv
			IN_FILE=data_S${arr[0]}_D3_7_49.csv			
		

			if [ -s $IN_FILE ]
			then
				echo "------------------------------------------ Data Preprocessing ------------------------------------------"
                                python optPreprocessing.py data_S${arr[0]}_D3_7_49.csv ${arr[0]} weather_data_store${arr[1]}.csv

				F_NM=data_S${arr[0]}_D3_7_49_output.csv
				echo $F_NM
				if [ -f "$F_NM" ]
				then
					#load data in hive
					echo "------------------ Getting new tickets again ----------------------------"
                        		kdestroy
                        		cat ~/.mypass | kinit Z001L92@CORP.TARGET.COM
                        		klist


					hive -e "load data local inpath '/home_dir/z001l92/newIDF/data_S${arr[0]}_D3_7_49_output.csv' into table cyno_lstm.temp_input_test"	


					echo "------------------ Getting new tickets again ----------------------------"
                                        kdestroy
                                        cat ~/.mypass | kinit Z001L92@CORP.TARGET.COM
                                        klist

					hive -e "insert overwrite table cyno_lstm.final_input_data_test partition(co_loc_i,mdse_dept_ref_i) select mdse_item_i, mdse_clas_i, promo_on_wknd, tpc_f, circular_f, clearance_f, dollar_off_f, qty_for_dollar_f, pct_off_f, free_product_f, giftcard_f, external_promo_f, algorithm, tmpf, dwpf, relh, prec, vsby, num_wks_last_sale, christmas_f, easter_f, thanks_giving, cyber_monday, amazon_prime, jul_4_16, may25_16, four_wk_mv_avg, one_wk_lag, two_wk_lag, seven_wk_lag, four_wk_mv_cen_val, wk_start_date, wk_end_date, sls_q, sale_bucket, co_loc_i, mdse_dept_ref_i from cyno_lstm.temp_input where co_loc_i=${arr[0]}"
					
					echo "removing data_S${arr[0]}_D3_7_49_output.csv file."	
					rm data_S${arr[0]}_D3_7_49_output.csv
					echo "removing data file."
					rm data_S${arr[0]}_D3_7_49.csv	
				else
					echo "Something went wrong."
				fi

			else
				echo "Input data file is empty."
			fi	
	else
	        echo "Weather file is not present."
	fi

done < $storeFile

echo "------------------------------------------ Data Fetching Completed. ------------------------------------------"
