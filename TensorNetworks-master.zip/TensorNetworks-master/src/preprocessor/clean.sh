#!/bin/bash
id=`ps aux | grep 'IDF_data_fetching_new.sh'`
for i in $id
  do
    echo "killing "$i
    kill -15 $i
  done
