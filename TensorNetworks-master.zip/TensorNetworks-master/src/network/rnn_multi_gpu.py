import os
import read_data as rd
import rnn_df as rnn
import rnn_df_prediction as rnn_pred
from collections import defaultdict
from multiprocessing import Process,Queue
import sys
import misc
import os
import fetch_gpus as fgpus


#NOTE:can be done dynamically 
#how many gpus available
#gpus = ['0','1','2','3']
#gpus = ['0']
gpus = fgpus.get_available_gpus()

#This mapping is across all the departments of a given store on a single machine.
#Assumption is that one store will run on one machine.
def gpu_mapping(ids):
   mapping = defaultdict(list)
   for i in range(len(ids)):
      gpu = i%len(gpus)
      mapping[gpus[gpu]].append(ids[i])

   return mapping

#This mapping is across given stores on a single machine.
#One store on one gpu.
#i.e Store1(all depts) -> GPU0, Store2(all depts) -> GPU2 .. 
def gpu_mapping_stores(gpu_map):
   counter = 0
   new_store_map = {}
   for store_id,value in gpu_map.items():
      gpu = counter%len(gpus)
      new_map = defaultdict(list)
      for k,v in value.items():
        for item in v:
          new_map[gpus[gpu]].append(item)

      new_store_map[store_id]=new_map
      counter +=1 
   return new_store_map

#This is mapping is across given stores and across given depts on a single machine.
#Heterogeneous mapping on multiple stores.
#Round Robin method of assigning depts to a gpu.
def gpu_mapping_store_depts(gpu_map): 
   new_store_map = {}
   total_depts = []

   for store_id,value in gpu_map.items():
      new_map = defaultdict(list)
      for k,v in value.items():
        for item in v:
          total_depts.append((store_id,item))
          
   for i in range(len(total_depts)):
      gpu = gpus[i%len(gpus)]
      store_id,dept = total_depts[i]
      total_depts[i] = (store_id,dept,gpu)

   for store_id,dept,gpu in total_depts:
      dept_map = defaultdict(list)
      if store_id in new_store_map:
         dept_map = new_store_map.get(store_id)
      else: 
         new_store_map[store_id]=dept_map

      dept_map[gpu].append(dept)

   return new_store_map

      
def fetch_data(store_id,depts_list,source_table,credential_file,queue):
   data_map = rd.readData(store_id,depts_list,source_table,credential_file)
   gpu_maps = gpu_mapping(data_map.keys())
   queue.put((data_map,gpu_maps,store_id))


#processing multiple store on a single machine in parallel
def process_multistores(store_list,depts_list,source_table,credential_file,mode):

   num_of_stores_in_parallel = 2
   count = len(store_list)/num_of_stores_in_parallel
   if len(store_list)%num_of_stores_in_parallel > 0:
      count += 1

   start,end=0,num_of_stores_in_parallel

   for _ in range(count):
      store_subset = store_list[start:end]
      stores_data_map = {}
      stores_gpu_map  = {}

      #calling kinit
      misc.kinit(credential_file)

      spids = []
      for store_id in store_subset:
         q = Queue()
         p = Process(target=fetch_data,args=(store_id,depts_list,source_table,credential_file,q))
         #data_map = rd.readdata(store_id,depts_list)
         #gpu_maps = gpu_mapping(data_map.keys())

         #stores_data_map[store_id] = data_map
         #stores_gpu_map[store_id] = gpu_maps
         p.start()
         spids.append((p,q))

      for item,queue in spids:
         data_map,gpu_maps,store_id = queue.get()
         item.join()
         stores_data_map[store_id] = data_map
         stores_gpu_map[store_id] = gpu_maps
         

      start = end
      end += num_of_stores_in_parallel

      stores_gpu_map = gpu_mapping_store_depts(stores_gpu_map)

      #getting the result from 1st level model 
      #Using this as the input variable in the 2nd level model
      pids = []
      output_map = {}
      for item,q,dept_id,store_id in pids:
         output_data = q.get()
         item.join()
         output_map[dept_id+"_"+store_id] = output_data

      pids = []
      for store_id,value in stores_data_map.items():
         gpu_maps = stores_gpu_map.get(store_id)
         data_map = value

         for k,v in gpu_maps.items():
            os.environ["CUDA_VISIBLE_DEVICES"]=k        

            for dept_id in v:
               try:
                  #q = Queue()
                  gpu_name = "gpu_l2_%s_%s"%(dept_id,store_id)
                  data_list,obvs_list,misc_list,_ = data_map.get(dept_id)

                  if len(data_list) == 0:
                     continue

                  key_str = "%s_%s"%(dept_id,store_id)
                  if key_str in output_map:
                     output_data = output_map.get(key_str)
                     for _i in range(len(data_list)):
                        data_list[_i].append(output_data[_i])

                  if mode == 0:
                     proc = Process(target=rnn.run_model,args=(data_list,obvs_list,misc_list,gpu_name,None))
                  else:
                     proc = Process(target=rnn_pred.run_model_prediction,args=(data_list,obvs_list,misc_list,gpu_name,None))

                  pids.append((proc,dept_id,store_id))
                  proc.start()
               except:
                  print "[Prediction] Problem In [%s %s]" %(store_id,dept_id)

      for item,dept_id,store_id in pids:
         #q.get()
         item.join()


#processing one store a time on a single machine.
def process(store_list,depts_list,mode):
   for store_id in store_list:
      #each element of data_map is a department level data.
      #key: department
      #value : (datalist,obv_list,misc_list)
      data_map = rd.readData(store_id,depts_list)
      gpu_maps = gpu_mapping(data_map.keys())

      pids = []

      '''
      #running 1st level model
      for k,v in gpu_maps.items():
         os.environ["CUDA_VISIBLE_DEVICES"]=k        

         for dept_id in v:
            q = Queue()
            gpu_name = "gpu_l1_%s_%s_%s"%(k,dept_id,store_id)
            data_list,_,misc_list,bucket_list = data_map.get(dept_id)
            proc = Process(target=rnn.run_model,args=(data_list,bucket_list,misc_list,gpu_name,q))
            pids.append((proc,q,dept_id))
            proc.start()
      '''

      #getting the result from 1st level model 
      #Using this as the input variable in the 2nd level model
      output_map = {}
      for item,q,dept_id in pids:
         output_data = q.get()
         item.join()
         output_map[dept_id] = output_data
    

      pids = []
      #running 2nd level model
      for k,v in gpu_maps.items():
         os.environ["CUDA_VISIBLE_DEVICES"]=k        

         for dept_id in v:
            q = Queue()
            gpu_name = "gpu_l2_%s_%s"%(dept_id,store_id)
            data_list,obvs_list,misc_list,_ = data_map.get(dept_id)

            if dept_id in output_map:
              output_data = output_map.get(dept_id)
              for _i in range(len(data_list)):
                 data_list[_i].append(output_data[_i])

            proc = Process(target=rnn.run_model,args=(data_list,obvs_list,misc_list,gpu_name,mode,q))
            pids.append((proc,q))
            proc.start()

      for item,q in pids:
         output = q.get()
         item.join()
          
if __name__=='__main__':
     
   if len(sys.argv) < 5:
      print "Usage: python rnn_multigpu.py <store_file> <department_file> <source_table> <credential_file> <mode=(0,1)>"
      sys.exit(0)

   #stores file
   store_file   = sys.argv[1]
   depts_file   = sys.argv[2]
   source_table = sys.argv[3]
   credential_file = sys.argv[4]
   mode         = int(sys.argv[5])

   #reading store list and process one store at a time.
   store_list = rd.read_store_list(store_file) 
   depts_list = rd.read_depts_list(depts_file)

   process_multistores(store_list,depts_list,source_table,credential_file,mode)
