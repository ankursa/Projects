import socket
import traceback
import sys

def check_server_status(server,port):
   status = False
   sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
   try:
      server_address = (server,port)
      print "Connecting to %s port %s" %server_address
      sock.connect(server_address)
      status = True
   except:
      traceback.print_exc()
   finally:
      print "Closing Connection .."
      sock.close()

   return status

def connect_and_send(server,port,message,cleaner):
   sock = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
   try:
      server_address = (server,port)
      print "Connecting to %s port %s" %server_address
      sock.connect(server_address)

      sock.sendall(message)

      #TODO: Sychronous or Asynchronous ?
      data_received = sock.recv(20)
      print "Message Received = %s"%data_received
   except KeyboardInterrupt:
      cleaner(server)
   except:
      traceback.print_exc()
   finally:
      print "Closing Connection .."
      sock.close()
