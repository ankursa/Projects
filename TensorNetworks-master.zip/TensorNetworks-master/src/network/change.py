import csv
from collections import OrderedDict
from collections import defaultdict
from sets import Set

percentage_training = .99918387846066921967  

def change_1():
  f = open("train_data.csv")

  reader = csv.reader(f,delimiter=",")

  data_map = OrderedDict()

  for lines in reader:
     weekend_date = lines[-3]
     weekstart_date = lines[-4]

     value_list = []
     if weekend_date in data_map:
        value_list = data_map.get(weekend_date)
     else:
        data_map[weekend_date] = value_list

     value_list.append(lines)

  f1 = open("train_data_trans.csv","w")

  for k,v in data_map.items():
     for item in v:
        f1.write("%s\n"%','.join(item))

  f1.close()
  f.close()


def change_2():
  f = open("train_data.csv")
  ft = open("train_data_actual.csv","w")
  fte = open("test_data_actual.csv","w")

  reader = csv.reader(f,delimiter=",")

  data_map_overall = defaultdict(list)
  data_map_train = defaultdict(list)
  data_map_test = defaultdict(list)

  for lines in reader:
     item_id = lines[0]
     data_map_overall[item_id].append(lines)

  for k,v in data_map_overall.items():
     data_len = len(v)
     index = int(data_len*percentage_training)
     data_list_train = v[:index]
     data_list_test = v[index:]     
    
     for item in data_list_train:
        ft.write("%s\n"%','.join(item))

     for item in data_list_test:
        fte.write("%s\n"%','.join(item))

     
  f.close()
  ft.close()
  fte.close()

def change_3():
  f = open("train_data.csv")
  ft = open("train_data_actual.csv","w")
  fte = open("test_data_actual.csv","w")

  reader = csv.reader(f,delimiter=",")

  s = Set()
  data_map_overall = defaultdict(list)

  for lines in reader:
     item_id = lines[0]
     class_id = lines[1]
     data_map_overall[item_id].append(lines)
     s.add(class_id)

  index_list = list(s)
  index_map = {index_list[i]:i for i in range(len(index_list))}

  for k,v in data_map_overall.items():
     data_len = len(v)
     index = int(data_len*percentage_training)
     data_list_train = v[:index]
     data_list_test = v[index:]     
    
     for item in data_list_train:
        class_id = item[1]
        index = index_map.get(class_id)
        one_hot = ["0" for i in range(len(index_list))]
        one_hot[index] = "1"
        item.extend(one_hot)
        ft.write("%s\n"%','.join(item))

     for item in data_list_test:
        index = index_map.get(class_id)
        one_hot = ["0" for i in range(len(index_list))]
        one_hot[index] = "1"
        item.extend(one_hot)
        fte.write("%s\n"%','.join(item))

     
  f.close()
  ft.close()
  fte.close()

change_2()
