import read_data as rd
import rnn_df as rnn
import rnn_df_prediction as rnn_pred
from collections import defaultdict
from multiprocessing import Process,Queue,Array
import sys
import misc
import os
import utils as ut
import traceback

cwd = os.getcwd()
SAVED_MODELS_DIRECTORY = "%s/saved_models"%(cwd)
TEMP_MODELS_DIRECTORY = "/tmp/saved_models"

def path_check_create():
   path_exist = os.path.isdir(SAVED_MODELS_DIRECTORY)
   if not path_exist:
      print "Path = %s doesn't exists, hence creating it" %SAVED_MODELS_DIRECTORY
      os.system("mkdir %s"%SAVED_MODELS_DIRECTORY)

   path_exist = os.path.isdir(TEMP_MODELS_DIRECTORY)
   if not path_exist:
      print "Path = %s doesn't exists, hence creating it" %TEMP_MODELS_DIRECTORY
      os.system("mkdir %s"%TEMP_MODELS_DIRECTORY)


#Handling depts in parallel for chain level models
#NOTE: Generic method of running chain level models
def process_chain_generic(store_list,objs_list,source_table,credential_file,mode,mtype):
   num_of_objs_in_parallel = 1
   count = len(objs_list)/num_of_objs_in_parallel
   if(len(objs_list))%num_of_objs_in_parallel > 0:
      count += 1

   start,end=0,num_of_objs_in_parallel

   #current model runs
   stores_data_map = {}
   stores_gpu_map  = {}

   for _iter in range(count):
      new_start = end
      new_end = end+num_of_objs_in_parallel
      next_subset = objs_list[new_start:new_end]

      next_spids = ut.fetch_data_in_parallel_2(store_list,next_subset,source_table,credential_file,mtype)

      #current data pull for the 1st time 
      if _iter == 0:
         object_subset = objs_list[start:end]
         spids = ut.fetch_data_in_parallel_2(store_list,object_subset,source_table,credential_file,mtype)
     
         data_map_list = []
         gpu_map_list = []
         for item,queue in spids:
            data_map,gpu_maps,store_id = queue.get()
            if item.is_alive():
               item.join()
            #stores_data_map[store_id] = data_map
            #stores_gpu_map[store_id] = gpu_maps
            data_map_list.append(data_map)
            gpu_map_list.append(gpu_maps)

      merged_data_map = ut.mergemaps_data(data_map_list)
      merged_gpu_map  = ut.mergemaps_gpu(gpu_map_list)

      stores_data_map[store_id] = merged_data_map
      stores_gpu_map[store_id] = merged_gpu_map

      start = end
      end += num_of_objs_in_parallel

      stores_gpu_map = ut.gpu_mapping_store_depts(stores_gpu_map)

      #getting the result from 1st level model 
      #Using this as the input variable in the 2nd level model
      output_map = {}
      pids = []
      for item,q,dept_id,store_id in pids:
         output_data = q.get()
         if item.is_alive():
            item.join()
         output_map[dept_id+"_"+store_id] = output_data

      pids = []
      for store_id,value in stores_data_map.items():
         gpu_maps = stores_gpu_map.get(store_id)
         data_map = value

         #For handling item level models
         lcounter = 0
         for k,v in gpu_maps.items():
            if len(v) > lcounter:
               lcounter = len(v)
    
         chunksize = lcounter

         #when item level models to reduce oversubscibe and prevent memory shoot
         if mtype == 5 or mtype == 2:
            chunksize = 10
         
         _start,_end = 0,chunksize
         _counter = lcounter/chunksize
         if lcounter % chunksize > 0:
            _counter += 1
         
         for _ in range(_counter):    
          local_pids = []

          for k,v in gpu_maps.items():
            if k != "cpu0":
              os.environ["CUDA_VISIBLE_DEVICES"]=k      
            else:
              os.environ["CUDA_VISIBLE_DEVICES"]=""      

            for obj_id in v[_start:_end]:
               try:
                  #q = Queue()
                  if k != "cpu0":
                    gpu_name = "gpu_%s_%s"%(obj_id,store_id)
                  else:
                    gpu_name = "cpu_%s_%s"%(obj_id,store_id)
                    
                  data_list,obvs_list,misc_list,_ = data_map.get(obj_id)

                  if len(data_list) == 0:
                     continue

                  key_str = "%s_%s"%(obj_id,store_id)
                  if key_str in output_map:
                     output_data = output_map.get(key_str)
                     for _i in range(len(data_list)):
                        data_list[_i].append(output_data[_i])

                  #TODO: Need to fetch this information from hive table having stored models
                  model_file = "%s/model_%s.ckpt"%(SAVED_MODELS_DIRECTORY,"_".join(gpu_name.split("_")[1:]))
                  temp_file = "%s/model_%s.ckpt"%(TEMP_MODELS_DIRECTORY,"_".join(gpu_name.split("_")[1:]))

                  if mode == 0:
                     proc = Process(target=rnn.run_model,args=(data_list,obvs_list,misc_list,gpu_name,model_file,temp_file,None))
                  else:
                     proc = Process(target=rnn_pred.run_model_prediction,args=(data_list,obvs_list,misc_list,gpu_name,model_file,temp_file,None))

                  #NOTE: when item level models to reduce over subscribe
                  if mtype == 5 or mtype == 2:
                     local_pids.append((proc,obj_id,store_id))
                  else:
                     pids.append((proc,obj_id,store_id))

                  proc.start()
               except:
                  print "[Prediction] Problem In [%s %s]" %(store_id,obj_id)
                  traceback.print_exc()

          for item,obj_id,store_id in local_pids:
             if item.is_alive():
                item.join()

          _start = _end
          _end += chunksize

      for item,obj_id,store_id in pids:
         if item.is_alive():
            item.join()

      stores_data_map = {}
      stores_gpu_map  = {}

      data_map_list = []
      gpu_map_list = []
      #fetching data from next pre-processed stores
      for item,queue in next_spids:
         data_map,gpu_maps,store_id = queue.get()
         if item.is_alive():
            item.join()
         data_map_list.append(data_map)
         gpu_map_list.append(gpu_maps)

      merged_data_map = ut.mergemaps_data(data_map_list)
      merged_gpu_map  = ut.mergemaps_gpu(gpu_map_list)

      stores_data_map[store_id] = merged_data_map
      stores_gpu_map[store_id] = merged_gpu_map


#processing multiple store on a single machine in parallel
def process_multistores(store_list,depts_list,source_table,credential_file,mode,mtype):

   num_of_stores_in_parallel = 2
   count = len(store_list)/num_of_stores_in_parallel
   if len(store_list)%num_of_stores_in_parallel > 0:
      count += 1

   start,end=0,num_of_stores_in_parallel

   #current model runs
   stores_data_map = {}
   stores_gpu_map  = {}

   for _iter in range(count):
      #prepairing for next data pull in parallel with current model runs
      new_start = end
      new_end   = end+num_of_stores_in_parallel
      next_subset = store_list[new_start:new_end]

      next_spids = ut.fetch_data_in_parallel(next_subset,depts_list,source_table,credential_file,mtype,mode)

      #current data pull for the 1st time 
      if _iter == 0:
         store_subset = store_list[start:end]
         spids = ut.fetch_data_in_parallel(store_subset,depts_list,source_table,credential_file,mtype,mode)

         for item,queue in spids:
            data_map,gpu_maps,store_id = queue.get()
            if item.is_alive():
              item.join()
            print "waiting finished for ",store_id
            stores_data_map[store_id] = data_map
            stores_gpu_map[store_id] = gpu_maps
         

      start = end
      end += num_of_stores_in_parallel

      stores_gpu_map = ut.gpu_mapping_store_depts(stores_gpu_map)

      #getting the result from 1st level model 
      #Using this as the input variable in the 2nd level model
      pids = []
      output_map = {}
      for item,q,dept_id,store_id in pids:
         output_data = q.get()
         if item.is_alive():
            item.join()
         output_map[dept_id+"_"+store_id] = output_data

      pids = []
      for store_id,value in stores_data_map.items():
         gpu_maps = stores_gpu_map.get(store_id)
         data_map = value

         for k,v in gpu_maps.items():
            if k != "cpu0":
              os.environ["CUDA_VISIBLE_DEVICES"]=k      
            else:
              os.environ["CUDA_VISIBLE_DEVICES"]=""      

            for dept_id in v:
               try:
                  #q = Queue()
                  if k != "cpu0":
                    gpu_name = "gpu_%s_%s"%(dept_id,store_id)
                  else:
                    gpu_name = "cpu_%s_%s"%(dept_id,store_id)
                    
                  data_list,obvs_list,misc_list,_ = data_map.get(dept_id)

                  if len(data_list) == 0:
                     continue

                  key_str = "%s_%s"%(dept_id,store_id)
                  if key_str in output_map:
                     output_data = output_map.get(key_str)
                     for _i in range(len(data_list)):
                        data_list[_i].append(output_data[_i])

                  #TODO: Need to fetch this information from hive table having stored models
                  model_file = "%s/model_%s.ckpt"%(SAVED_MODELS_DIRECTORY,"_".join(gpu_name.split("_")[1:]))
                  temp_file = "%s/model_%s.ckpt"%(TEMP_MODELS_DIRECTORY,"_".join(gpu_name.split("_")[1:]))

                  if mode == 0:
                     proc = Process(target=rnn.run_model,args=(data_list,obvs_list,misc_list,gpu_name,model_file,temp_file,None))
                  else:
                     proc = Process(target=rnn_pred.run_model_prediction,args=(data_list,obvs_list,misc_list,gpu_name,model_file,temp_file,None))

                  pids.append((proc,dept_id,store_id))
                  proc.start()
               except:
                  print "[Prediction] Problem In [%s %s]" %(store_id,dept_id)

      for item,dept_id,store_id in pids:
         #q.get()
         if item.is_alive():
            item.join()

      #resetting maps
      stores_data_map = {}
      stores_gpu_map  = {}

      #fetching data from next pre-processed stores
      for item,queue in next_spids:
         data_map,gpu_maps,store_id = queue.get()
         if item.is_alive():
            item.join()
         stores_data_map[store_id] = data_map
         stores_gpu_map[store_id] = gpu_maps


#processing one store a time on a single machine.
def process(store_list,depts_list,mode):
   for store_id in store_list:
      #each element of data_map is a department level data.
      #key: department
      #value : (datalist,obv_list,misc_list)
      data_map = rd.readData(store_id,depts_list)
      gpu_maps = gpu_mapping(data_map.keys())

      pids = []

      '''
      #running 1st level model
      for k,v in gpu_maps.items():
         os.environ["CUDA_VISIBLE_DEVICES"]=k        

         for dept_id in v:
            q = Queue()
            gpu_name = "gpu_l1_%s_%s_%s"%(k,dept_id,store_id)
            data_list,_,misc_list,bucket_list = data_map.get(dept_id)
            proc = Process(target=rnn.run_model,args=(data_list,bucket_list,misc_list,gpu_name,q))
            pids.append((proc,q,dept_id))
            proc.start()
      '''

      #getting the result from 1st level model 
      #Using this as the input variable in the 2nd level model
      output_map = {}
      for item,q,dept_id in pids:
         output_data = q.get()
         if item.is_alive():
            item.join()
         output_map[dept_id] = output_data
    

      pids = []
      #running 2nd level model
      for k,v in gpu_maps.items():
         os.environ["CUDA_VISIBLE_DEVICES"]=k        

         for dept_id in v:
            q = Queue()
            gpu_name = "gpu_%s_%s"%(dept_id,store_id)
            data_list,obvs_list,misc_list,_ = data_map.get(dept_id)

            if dept_id in output_map:
              output_data = output_map.get(dept_id)
              for _i in range(len(data_list)):
                 data_list[_i].append(output_data[_i])

            proc = Process(target=rnn.run_model,args=(data_list,obvs_list,misc_list,gpu_name,mode,q))
            pids.append((proc,q))
            proc.start()

      for item,q in pids:
         output = q.get()
         if item.is_alive():
            item.join()
          
if __name__=='__main__':
     
   if len(sys.argv) < 6:
      print "Usage: python rnn_multigpu.py <store_file> <department_file> <source_table> <credential_file> <mode=(0:training,1:testing)> <mtype=(0:item-week(store-dept.),1:item-week(store-class.),2:item-week(store-items.),3:item-chain(dept.),4:item-chain(class.),5:item-chain(items.))>"
      sys.exit(0)

   methods_map = {0:process_multistores,1:process_multistores,2:process_chain_generic,
                  3:process_chain_generic,4:process_chain_generic,5:process_chain_generic}

   #stores file
   store_file   = sys.argv[1]
   depts_file   = sys.argv[2]
   source_table = sys.argv[3]
   credential_file = sys.argv[4]
   mode         = int(sys.argv[5])
   mtype        = int(sys.argv[6])

   #reading store list and process one store at a time.
   store_list = rd.read_store_list(store_file) 
   depts_list = rd.read_depts_list(depts_file)

   path_check_create()

   method = methods_map.get(mtype) 

   method(store_list,depts_list,source_table,credential_file,mode,mtype)
