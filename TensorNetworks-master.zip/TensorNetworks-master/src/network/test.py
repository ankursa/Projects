import tensorflow as tf

checkpoint_file=tf.train.latest_checkpoint("/Users/z001jv4/workspace/TensorNetworks/src/network")
graph=tf.Graph()

with graph.as_default():
     session_conf = tf.ConfigProto(log_device_placement =False)
     sess = tf.Session(config = session_conf)
     with sess.as_default():
          saver =     tf.train.import_meta_graph("{}.meta".format(checkpoint_file))
          saver.restore(sess,checkpoint_file)
          input = graph.get_operation_by_name("covariates").outputs[0]
          prediction=graph.get_operation_by_name("prediction_all").outputs[0]
          #newdata=put your data here
          print sess.run(prediction,feed_dict={input:newdata})
