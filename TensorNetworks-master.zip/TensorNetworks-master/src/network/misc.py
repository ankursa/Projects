import base64 as b64
import os
import datetime

def fetchCredentials(credential_file):
   f = open(credential_file)
   data = f.readlines()

   username,password = None,None

   for item in data:
      if len(item) > 1:
         item = item.split('|||')
         username,password = item[0],item[1]
         username = b64.b64decode(username)
         password = password.replace('\n','')
         password = b64.b64decode(password)

   f.close()

   return username,password

def kinit(credential_file):
   username,password = fetchCredentials(credential_file)      
   user_upper = username.upper()
   #initializing the ticket
   os.system('echo %s | kinit %s@CORP.TARGET.COM' %(password,user_upper))


def updateStatus(table_name,credential_file):
   kinit(credential_file)

   current_time = datetime.datetime.now()
   date_str = dt.datetime.strftime(current_time,"%Y-%m-%d")

   os.system('hive -e "USE cyno_lstm;INSERT INTO %s VALUES (%s,%s);"'%(table_name,"automation",date_str))
