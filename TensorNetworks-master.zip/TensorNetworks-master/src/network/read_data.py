import csv
import traceback
import numpy as np
#from subprocess import Popen
import os
from multiprocessing import Process,Queue

query_map = {}
#item-loc-week (loc-dept)
query_map[0] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm_new.db/%s/mode=%s/co_loc_i=%s/mdse_dept_ref_i=%s/* > %s"
#item-loc-week (loc-class)
query_map[1] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm_new.db/%s/mode=%s/co_loc_i=%s/mdse_class_i=%s/* > %s"
#item-loc-week (loc-item)
query_map[2] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm_new.db/%s/mode=%s/co_loc_i=%s/mdse_dept_ref_i=%s/* > %s"
#item-chain-week (dept)
query_map[3] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/mdse_dept_ref_i=%s/* > %s"
#item-chain-week (class)
query_map[4] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/mode=training/mdse_clas_i=%s/* > %s"
#item-chain-week (item)
query_map[5] = query_map[3]
#query_map[5] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/item_ref_i=%s/* > %s"
#query_map[5] = 'hive -e "select mdse_clas_i, mdse_dept_ref_i, unit_price, fcg_q, boh_q, clearance_pct, max_promo_daynr, max_promo_pctoff, max_promo_dollaroff, max_external_pctoff, max_external_dollaroff, cwl_offer_daynr, cwl_pct_off, circular_flag, circular_flag_count, tpc_flag, tpc_flag_count, clearance_flag, clearance_flag_count, dollar_off_flag, dollar_off_flag_count, free_product_flag, free_product_flag_count, pct_off_flag, pct_off_flag_count, giftcard_flag, giftcard_flag_count, external_promo_flag, external_promo_flag_count, christmas_f, easter_f, thanks_giving_f, cyber_monday_f, amazon_prime_f, jul_4_2016_f, may_25_2016_f, num_wks_last_sale, four_wk_mvg_avg, one_wk_lag, two_wk_lag, seven_wk_lag, cen_val_4wk_mvg, week_start_date, week_end_date, sls_unit_q, sale_bucket from cyno_lstm.%s where mdse_item_i=%s" > %s'

def reader(rd):
  out_list = []
  for line in rd:
     for item in line:
        out_list.append(item)
  return out_list

#store reading
def read_store_list(store_file):
   f = open(store_file)
   rd = csv.reader(f,delimiter=",")
   store_list = reader(rd) 
   f.close()
     
   return store_list

#department reading
def read_depts_list(depts_file):
   f = open(depts_file)
   rd = csv.reader(f,delimiter=",")
   depts_list = reader(rd)
   return depts_list


def data_preprocess(result_location,store_id,dept_id,source_table,credential_file,mtype,mode,queue):
   try:
      #os.system("hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/co_loc_i=%s/mdse_dept_ref_i=%s/* > %s"%(source_table,store_id,dept_id,result_location))
      if mode == 0:
         data_type = "Training"
      else:
         data_type = "Testing"


      matched_query = query_map.get(mtype)
      if mtype == 0 or mtype == 1 or mtype == 2:
        os.system(matched_query%(source_table,data_type,store_id,dept_id,result_location))
   
      if mtype == 3 or mtype == 4 or mtype == 5:
        os.system(matched_query%(source_table,dept_id,result_location))
        if mtype == 5:
           #converting tab file to csv file.
           os.system("sed -i $'s/\t/,/g' %s"%result_location)

      data_list,obv_list,misc_list,bucket_list = readCSV(result_location,store_id,dept_id)
      #cleaning the input file
      os.system("rm %s"%result_location)
      queue.put((data_list,obv_list,misc_list,bucket_list,store_id,dept_id))
   except:
      queue.put(([],[],[],[],store_id,dept_id))
   
#partition the input data across a given index
def datapartioning(data_list,obv_list,misc_list,bucket_list,partion_index=0):
   data_map = {}
   for i in range(len(misc_list)):
      _id = misc_list[i][partion_index]
      p_data_list,p_obv_list,p_misc_list,p_bucket_list = [],[],[],[]
      if _id not in data_map:
         data_map[_id] = (p_data_list,p_obv_list,p_misc_list,p_bucket_list)
      else:
         p_data_list,p_obv_list,p_misc_list,p_bucket_list = data_map.get(_id)

      p_data_list.append(data_list[i])
      p_obv_list.append(obv_list[i])
      p_misc_list.append(misc_list[i])
      p_bucket_list.append(bucket_list[i])

   return data_map
         


#read data from hadoop
#read one store data and return differnt department data in a map
def readData(store_id,departments,source_table,credential_file,mtype,mode):
   #Hive query for a given store.
   #split the data into multiple departmenets data.
   dept_data_map = {}

   #cleaning already existing files in a given location
   #p = Popen(["rm -rf %/*" %result_location])
   #p.wait()

   ids = []
   for dept_id in departments:
      q = Queue()
      result_location = "input_%s_%s.csv"%(store_id,dept_id)
      p = Process(target=data_preprocess,args=(result_location,store_id,dept_id,source_table,credential_file,mtype,mode,q))
      ids.append((p,q))
      p.start()

   for _id,q in ids:
      data_list,obv_list,misc_list,bucket_list,sid,did = q.get()
      #datapartioning in case of item-chain level models 
      if mtype == 5 or mtype == 2:
         dept_data_map = datapartioning(data_list,obv_list,misc_list,bucket_list,0)
         print len(dept_data_map.keys()),did
      else:
         dept_data_map[did] = (data_list,obv_list,misc_list,bucket_list)
      _id.join()

   return dept_data_map


#reading a csv file and creating list of np.array
#data_list: contains the covariates for each time step
#obv_list: containts the observation data for each time step
def readCSV(inp_file,store_id,dept_id):
   try:
      print inp_file
      f = open(inp_file)
      reader = csv.reader(f,delimiter=',')
      count = 0
      data_list = []
      obvs_list = []
      misc_list = []
      bucket_list = []

      for lines in reader:
         item_list = []
         obv_list = []
         buck_list = []
         line_len = len(lines)
         misc = []

         for i in range(len(lines)):
            if i >= 2 and i < line_len-4 and i != 28:
               if lines[i] != "\N":
                  item_list.append(float(lines[i]))
               else:
                  item_list.append(0.0)
 
            elif i == line_len-2:
               if lines[i] != "\N":
                  obv_list.append(float(lines[i]))
               else:
                  obv_list.append(0.0)
            elif i < 2 or i == line_len-3:
               misc.append(lines[i])
            elif i == line_len-1:
               if lines[i] != "\N":
                  buck_list.append(float(lines[i]))
               else:
                  buck_list.append(0.0)
 

         misc.append(store_id)
         misc.append(dept_id)

         misc_list.append(misc)
                
         x = np.array([item_list])
         y = np.array([obv_list])
         z = np.array([buck_list])

         data_list.append(x)
         obvs_list.append(y)
         bucket_list.append(z)

      f.close()

      return data_list,obvs_list,misc_list,bucket_list
   except:
      traceback.print_exc()
