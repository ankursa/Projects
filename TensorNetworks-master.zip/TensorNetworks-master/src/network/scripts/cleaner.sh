#!/bin/bash
query="rnn_multi_gpu_fast.py"
y=`nvidia-smi`
host=`hostname`

logfile="/tmp/cleaner_$host.log"

pids=`ps aux | grep $query | grep Z001JV4 | awk '{print $2}'`

ktime=1800

declare -A parent


function killprocess {
  lpid=$1
   
  run_time=`ps -p $lpid -o etimes=`

  if [ $run_time -gt $ktime  ]
     then
        echo $i $run_time '>' $ktime
        `kill -15 $i`
        echo 'killed='$i  >> $logfile
     else
        echo $i $run_time '<' $ktime  >> $logfile
  fi
}

for i in $pids
  do
    ppid=`ps -ef | grep $i | awk '{print $3}'`
    prog=`ps -ef | grep $i| awk '{print $9}'`

    declare -a pidarray
    declare -a array

    count=0
    for j in $ppid
      do
         pidarray[count]=$j
        count=$((count+1))
      done

    count=0
    for k in $prog
      do
        array[count]=$k
        #echo $k
        count=$((count+1))
      done

    arraylen=${#array[@]}
    
    for (( i=0; i<${arraylen}; i++ ))
      do
        if [ "${array[i]}" == $query ]
          then
            #echo ${array[i]} ${pidarray[i]}
            parent[${pidarray[i]}]=$((parent[${pidarray[i]}]+1))
        fi
      done
 done


for i in $pids
 do
     echo "*******************" >> $logfile
     if [ ${parent[$i]} ]
       then
           echo $i " This is parent" >> $logfile
       else
           if [[ "$y" =~ "$i" ]]
              then
                 echo "[Child Process ] = GPU Process" $i >> $logfile
                 killprocess $i
              else
                 echo "[Child Process ] = Non GPU Process" $i >> $logfile
           fi
     fi
     echo "*******************" >> $logfile
 done
