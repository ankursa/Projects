#!/bin/bash
#python rnn_multi_gpu_fast.py store_test.csv depts_2.txt final_chain_testing cred_nitin.txt 1 5
store_file=$1
dept_file=$2
source_table=$3
credential_file=$4
mode=$5
model_type=$6

python rnn_multi_gpu_fast.py $store_file $dept_file $source_table $credential_file $mode $model_type
