#!/bin/bash
export PATH=/home_dir/z001jv4/byobu/bin:/usr/anaconda2/envs/tensorflow/bin:/usr/lib64/qt-3.3/bin:/usr/anaconda2/bin:/usr/local/cuda-7.5/bin:/usr/local/bin:/usr/bin:/usr/local/sbin:/usr/sbin

export LD_LIBRARY_PATH=/usr/local/cuda-7.5/targets/x86_64-linux/lib

pids=`ps aux | grep server.py | awk '{print $2}'`
hname=`hostname`
logfile="/tmp/server_$hname.log"

count=0
for i in $pids
do
  count=$(( count+1 ))
done

if [ $count -ge 2 ]
   then
      echo "Server is running" >> $logfile
      exit
   else
      echo "Server is not running, hence starting it."
      cd /home_dir/z001jv4/network/;python /home_dir/z001jv4/network/server.py > $logfile 2>&1 &
fi
