#!/bin/bash
tracking_file="processed_files"
for filename in /home_dir/z001jv4/networks/*gpu*.csv; do
        echo $filename
        if grep -Fxq $filename $tracking_file
        then
                # code if found
                echo "processed file found"
        else
                # code if not found
                echo "new file found $filename"
                echo $filename >> $tracking_file
                tail -n +2 $filename | head -n -2 > hive/trim_out
                kdestroy
                cat ~/.mypass | kinit Z001JV4@CORP.TARGET.COM
                hive -e "load data local inpath 'hive/trim_out' into table cyno_lstm.lstm_fcst_batch;"
                echo "done for $filename"
        fi
done
