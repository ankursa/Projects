zid=$1
password=$2

if [ "$zid" == "" ]
 then
   echo "Please insert zid in caps"
   exit
fi

if [ "$password" == "" ]
 then
   echo "Please insert password file"
   exit
fi

num_of_splits=2
total_count=0

function fetch_stores {
   for i in `seq 0 $((num_of_splits-1))`
   do
     cat store_$i.csv >> allready_full.txt
   done

   cat $password | kinit $zid"@CORP.TARGET.COM"

   python hive_store.py $num_of_splits

   for i in `seq 0 $((num_of_splits-1))`
       do
          count=`cat "store_"$i".csv" | wc -l`
          total_count=$((total_count+count))
       done

   return $total_count
}

fetch_stores

while [ $total_count -gt 0 ]
 do
    echo $total_count
    #calling tensorflow gpu on machines
    #Using a TCP Client-Server setup for executing tensorflow code
    total_count=0
    fetch_stores

 done

#running predictions on multiple machines (3)


#hive upload (4)
