#conca
for i in {0..3}
do
  cat store_$i.csv >> allready_full.txt
done

kinit

python hive_store.py 4
