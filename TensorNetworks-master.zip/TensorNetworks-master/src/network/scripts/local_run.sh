#echo "Training..."
#time python rnn_multi_gpu_fast.py store_test.csv classes_1.txt final_chain_training_class cred_nitin.txt 0 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_2.txt final_chain_training_class cred_nitin.txt 0 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_3.txt final_chain_training_class cred_nitin.txt 0 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_4.txt final_chain_training_class cred_nitin.txt 0 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_5.txt final_chain_training_class cred_nitin.txt 0 2

#echo "Testing"
#time python rnn_multi_gpu_fast.py store_test.csv classes_1.txt final_chain_testing_class cred_nitin.txt 1 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_2.txt final_chain_testing_class cred_nitin.txt 1 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_3.txt final_chain_testing_class cred_nitin.txt 1 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_4.txt final_chain_testing_class cred_nitin.txt 1 2
#time python rnn_multi_gpu_fast.py store_test.csv classes_5.txt final_chain_testing_class cred_nitin.txt 1 2

echo -ne > status.txt
python async_upload.py output_results cred_nitin.txt 10 status.txt
