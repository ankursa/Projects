import os
import traceback
import re
import datetime

#1. item-loc-week (var:store,const:dept)
#2. item-loc-week (var:store,const:class)
#3. item-loc-week (var:stote,const:dept)

#4. item-chain-week (const:store,var:dept)
#5. item-chain-week (const:store,var:class)
#6. item-chain-week (const:store,var:dept)

fetch_map = {}
fetch_map[0] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm_new.db/%s/mode=%s/* > %s 2>&1"
fetch_map[1] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/mode=training/* > %s 2>&1"
fetch_map[2] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/* > %s 2>&1"

fetch_map[3] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/* > %s 2>&1"
fetch_map[4] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/* > %s 2>&1"
fetch_map[5] = "hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/%s/* > %s 2>&1"

def check_available_data(status_table,automation_status_table):
   ret = False
   tmp_file = "/tmp/status_run.txt"
   try:
      current_time = datetime.datetime.now()
      date_str = dt.datetime.strftime(current_time,"%Y-%m-%d")

      #check to see if is already processed to prevent accidental runs
      os.system('hive -e "use cyno_lstm;select count(*) from %s where wk_end_date=%s;" > %s' %(automation_status_table,date_str,tmp_file))
      
      f = open(tmp_file)
      for line in f.readlines():
         count = int(line)
         if count > 0:
            return False
      f.close()

      os.system('hive -e "use cyno_lstm;select count(*) from %s where wk_end_date=%s;" > %s' %(status_table,date_str,tmp_file))

      f = open(tmp_file)
      for line in f.readlines():
         count = int(line)
         if count >= 1:
            ret = True
      f.close()
   except:
      pass

   return ret


def fetch_stores_list(stores_file,resource_table,model_type,mode):
   #os.system("hadoop fs -cat /apps/hive/warehouse/cyno_lstm.db/final_input_data_2/* > %s 2>&1" %stores_file)
   if mode == 0:
      mtype = "Training"
   else:
      mtype = "Testing"

   os.system(fetch_map.get(model_type) %(resource_table,mtype,stores_file))

#cat: `/apps/hive/warehouse/cyno_lstm.db/final_input_data/co_loc_i=953': Is a directory
def process(stores_file,processed_file,num_of_divisions,model_type):
   try:
      f = open(stores_file)
      lines = f.readlines()
      f.close()

      fp = open(processed_file)
      lines_p = fp.readlines()
      fp.close()

      lines_p = [item.replace("\n","") for item in lines_p]
      allready_map = {item:0 for item in lines_p}

      lines = [re.search('=[0-9]{1,5}',item.replace("\n","")).group(0).split("=")[1] for item in lines if 'hive-staging_hive' not in item]
      lines = [item for item in lines if item not in allready_map]

      divisions = len(lines)/num_of_divisions

      remaining = len(lines) - divisions*num_of_divisions

      #output file type
      outfile = "store_%d.csv"
      if model_type == 4 or model_type == 6:
         outfile = "depts_%d.csv"
      if model_type == 5:
         outfile = "class_%d.csv" 

      start,end = 0,divisions
      for i in range(num_of_divisions):
         try:
            #f = open("store_%d.csv"%i,'w')
            f = open(outfile%i,'w')
            if i == num_of_divisions-1:
               end += remaining

            sub_lines = lines[start:end]
            for item in sub_lines:
               item = item.replace("\n",'')
               m = re.search('[0-9]{1,5}',item) 
               _id = m.group(0)
               f.write('%s\n'%_id)
            f.close()
            start = end
            end += divisions
         except:
            traceback.print_exc()
   except:
      traceback.print_exc()

def fetch(num_of_splits,result_file,store_status_file,model_type,mode,resource_table):
  num_of_splits = num_of_splits
  res_file = result_file

  #NOTE: Checking if data is available for next run.
  #If available proceed further.
  status = check_available_data("status_table","automation_status_table")

  if status:
     fetch_stores_list(res_file,resource_table,model_type,mode)

     process(res_file,store_status_file,num_of_splits,model_type)
 
'''
if __name__=='__main__':
  if len(sys.argv) < 2:
     print "Usage: python hive_store.py <num of splits>"
     sys.exit(0)

  num_of_splits = int(sys.argv[1])
  res_file = "all_stores.txt"
  fetch_stores_list(res_file)

  process(res_file,'allready_full.txt',num_of_splits)
'''
