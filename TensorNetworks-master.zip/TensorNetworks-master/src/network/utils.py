from multiprocessing import Process,Queue,Array
from collections import defaultdict
import time
import misc
import read_data as rd

#NOTE:can be done dynamically 
#how many gpus available
gpus = ['0','1','2','3']
#gpus = ['cpu0']

def mergemaps_gpu(list_maps):
   _map = defaultdict(list)
   for item in list_maps:
      for k,v in item.items():
         _map[k].extend(v)
   return _map

def mergemaps_data(list_maps):
   _map = {}
   for item in list_maps:
      for k,v in item.items():
         _map[k] = v
   return _map

def fetch_data(store_id,depts_list,source_table,credential_file,queue,array,index,mtype,mode):
   try:
      print store_id,index,array[index]
      while array[index] != 0:
         time.sleep(1)

      array[index] = 1

      print "Processing Started for ",store_id

      data_map = rd.readData(store_id,depts_list,source_table,credential_file,mtype,mode)
      gpu_maps = gpu_mapping(data_map.keys())
      array[index] = 0
      queue.put((data_map,gpu_maps,store_id))
      print "completed for ",store_id
   except:
      queue.put(({},{},store_id))

#fetching data in parallel for different models from hadoop
#Sequential batch processing is to avoid hive memory issues.
def fetch_data_in_parallel_2(store_list,obj_list,source_table,credential_file,mtype,mode):
   seq_batch_size = 17
   count = len(obj_list)/seq_batch_size
   if len(obj_list)%seq_batch_size > 0:
      count += 1

   start,end = 0,seq_batch_size

   spids = []

   array = Array("i",range(seq_batch_size))
   for i in range(seq_batch_size):
      array[i] = 0

   for i in range(count):
      sub_obj_list = obj_list[start:end]

      misc.kinit(credential_file)
      mycount = 0
      q = Queue()
      p = Process(target=fetch_data,args=(store_list[0],sub_obj_list,source_table,credential_file,q,array,mycount,mtype,mode))
      p.start()
      spids.append((p,q))
      mycount += 1

      start = end
      end += seq_batch_size

   return spids

#fetching data in parallel for different models from hadoop
#Sequential batch processing is to avoid hive memory issues.
def fetch_data_in_parallel(store_list,depts_list,source_table,credential_file,mtype,mode):
   seq_batch_size = 2
   count = len(store_list)/seq_batch_size
   if len(store_list)%seq_batch_size > 0:
      count += 1

   start,end = 0,seq_batch_size

   spids = []

   array = Array("i",range(seq_batch_size))
   for i in range(seq_batch_size):
      array[i] = 0

   for i in range(count):
      sub_store_list = store_list[start:end]

      misc.kinit(credential_file)
      mycount = 0
      for store_id in sub_store_list:
         q = Queue()
         p = Process(target=fetch_data,args=(store_id,depts_list,source_table,credential_file,q,array,mycount,mtype,mode))
         p.start()
         spids.append((p,q))
         mycount += 1

      start = end
      end += seq_batch_size

   return spids



#This mapping is across all the departments of a given store on a single machine.
#Assumption is that one store will run on one machine.
def gpu_mapping(ids):
   mapping = defaultdict(list)
   for i in range(len(ids)):
      gpu = i%len(gpus)
      mapping[gpus[gpu]].append(ids[i])

   return mapping

#This mapping is across given stores on a single machine.
#One store on one gpu.
#i.e Store1(all depts) -> GPU0, Store2(all depts) -> GPU2 .. 
def gpu_mapping_stores(gpu_map):
   counter = 0
   new_store_map = {}
   for store_id,value in gpu_map.items():
      gpu = counter%len(gpus)
      new_map = defaultdict(list)
      for k,v in value.items():
        for item in v:
          new_map[gpus[gpu]].append(item)

      new_store_map[store_id]=new_map
      counter +=1 
   return new_store_map

#This is mapping is across given stores and across given depts on a single machine.
#Heterogeneous mapping on multiple stores.
#Round Robin method of assigning depts to a gpu.
def gpu_mapping_store_depts(gpu_map): 
   new_store_map = {}
   total_depts = []

   for store_id,value in gpu_map.items():
      new_map = defaultdict(list)
      for k,v in value.items():
        for item in v:
          total_depts.append((store_id,item))
          
   for i in range(len(total_depts)):
      gpu = gpus[i%len(gpus)]
      store_id,dept = total_depts[i]
      total_depts[i] = (store_id,dept,gpu)

   for store_id,dept,gpu in total_depts:
      dept_map = defaultdict(list)
      if store_id in new_store_map:
         dept_map = new_store_map.get(store_id)
      else: 
         new_store_map[store_id]=dept_map

      dept_map[gpu].append(dept)

   return new_store_map
