import tensorflow as tf
import numpy as np
import traceback
import csv
from tensorflow.python.ops import rnn,rnn_cell
import sys
import os
import read_data as rd
import upload2hive as u2h

def run_model(data_list,obvs_list,misc_list,gname,model_path,temp_model_path,queue=None):
   ###### params #########
   #input_file = input_file
   percentage = 1.0
   mbatch = 180000
   rnn_size = 20
   alpha = 0.0
   num_of_layers = 2
   iterations = 250
   #######################

   #covariated & Observations
   #data_list,obvs_list = rd.readCSV(input_file)
   datalen_ = len(data_list)
   #state dimension calculations
   N = len(data_list[0][0])

   #Extracting Training and Testing data
   index = int(datalen_*percentage)

   data_list_train = data_list[:index]
   #data_list_test  = data_list[index:]

   obvs_list_train = obvs_list[:index]
   #obvs_list_test  = obvs_list[index:]

   misc_list_train = misc_list[:index]
   #misc_list_test = misc_list[index:]

   train_size = len(obvs_list_train)

   #for i in range(datalen-index):
   #   data_list_train.append(np.array([[0 for _ii in range(N)]]))

   index_diff = datalen_ - index

   #for i in range(index_diff,index):
   #   data_list_test.append(np.array([[-10000 for _ii in range(N)]]))

   #for i in range(datalen-index):
   #   obvs_list_train.append(np.array([[0 for _ii in range(1)]]))

   #for i in range(index_diff,index):
   #   obvs_list_test.append(np.array([[-10000 for _ii in range(1)]]))

   '''
   additional = mbatch - len(obvs_list_train)%mbatch

   if mbatch > len(obvs_list_train):
     mbatch = len(obvs_list_train)
     additional = 0

   for i in range(additional):
      data_list_train.append(np.array([[-10000 for _ii in range(N)]]))
      obvs_list_train.append(np.array([[-10000 for _ii in range(1)]]))

      data_list_test.append(np.array([[-10000 for _ii in range(N)]]))
      obvs_list_test.append(np.array([[-10000 for _ii in range(1)]]))
   '''

   total_division = len(data_list_train)/mbatch
   if len(data_list_train)%mbatch > 0:
      total_division += 1

   #aa = np.array(data_list_train)
   dlist = []
   start = 0
   end = mbatch
   for i in range(total_division):
      dlist.append(np.transpose(np.array(data_list_train[start:end]),[1,0,2]))
      start = end
      end += mbatch


   #dlist.append(np.transpose(np.array(data_list_train[start:end]),[1,0,2]))
   #aa = np.transpose(aa,(1,0,2))

   #bb = np.array(obvs_list_train)
   start = 0
   end = mbatch
   blist = []
   for i in range(total_division):
      blist.append(np.transpose(np.array(obvs_list_train[start:end]),[1,0,2]))
      start = end
      end += mbatch

   #blist.append(np.transpose(np.array(obvs_list_train[start:end]),[1,0,2]))
   #bb = np.transpose(bb,[1,0,2])

   #cc = np.array(data_list_test)
   #cc = np.transpose(cc,[1,0,2])

   #dd = np.array(obvs_list_test)
   #dd = np.transpose(dd,[1,0,2])

   covariates = tf.placeholder(tf.float32,[None,None,N],name="covariates")
   dependent = tf.placeholder(tf.float32,[None,None,1],name="dependent")
   covariates_ = [covariates]

   if "cpu" in gname:
      device_str = "/cpu:0"
   else:    
      device_str = "/gpu:0"


   with tf.device(device_str):
      weights = tf.Variable(tf.random_normal([rnn_size,1]),name="weights")
      biases = tf.Variable(tf.random_normal([1]),name="biases")

   def model():

      x = tf.transpose(covariates,[1,0,2])

      lstm_cell = rnn_cell.BasicLSTMCell(rnn_size,state_is_tuple=True)
      #lstm_cell = rnn_cell.GRUCell(rnn_size)
      DCell = rnn_cell.DropoutWrapper(lstm_cell,output_keep_prob=0.5)
      multi_cell = rnn_cell.MultiRNNCell([lstm_cell]*num_of_layers,state_is_tuple=True)

      outputs,_ = rnn.dynamic_rnn(multi_cell,x,dtype=tf.float32)
      outputs_flattened = tf.reshape(outputs,[-1,rnn_size])

      output_all = tf.matmul(outputs_flattened,weights) + biases

      return output_all

   prediction_all = model()
   cost_all = tf.reduce_mean((dependent-prediction_all)**2)

   cost = cost_all
   optimizer = tf.train.AdamOptimizer(0.01).minimize(cost)

   config = tf.ConfigProto(allow_soft_placement = True)
   config.gpu_options.allow_growth = True

   #saving model
   model_file = temp_model_path
   #model_file = "model_%s.ckpt"%("_".join(gname.split("_")[1:]))

   model_existence = os.path.isfile(model_file)  

   #If not finding in /tmp then look for model saver folder
   if not model_existence:
      print "Not Found in /tmp new path = %s"%model_path
      model_file = model_path
      model_existence = os.path.isfile(model_file)  
   else:
      print "Found in /tmp new path = %s"%temp_model_path

   #NOTE: Assuming if file is not existing then model is running for the 1st time else incremental run.

   saver = tf.train.Saver()


   with tf.Session(config=config) as sess:
     with tf.device(device_str):

      if model_existence:
         saver.restore(sess,model_file)               
      else:
         sess.run(tf.initialize_all_variables())

      #sess.run(tf.global_variables_initializer())

      overall_predictions = []

      for iter_ in range(iterations):
         overall_predictions = []
         for i in range(len(dlist)):
            cov_ = dlist[i]
            obv_ = blist[i]

            feed_dict = {covariates:cov_,dependent:obv_}
            _,cost_,pred_all = sess.run([optimizer,cost,prediction_all],feed_dict=feed_dict)
            overall_predictions.extend(pred_all.tolist())
         #print "*********************************"
         #print iter_
         #print pred_all[-1]
         #print obvs_list_train[-1]
         #print cost_
         #print "*********************************\n"


      #result_file = "output_results/result_%s.csv"%gname
      #f1 = open('estimated_%s.csv'%gname,'w')
      #f1 = open(result_file,'w')
      #f1.write('wk_end_date,horizon,actual_sales,pred_sales,item_id,store,dept,class\n')
      total_non_zero_counter = 0

      predicted_outputs = []     

      '''
      mse,mape = 0.0,0.0
      for i in range(len(obvs_list_train)):
         mse += (obvs_list_train[i][0][0]-overall_predictions[i][0])**2
         if obvs_list_train[i][0][0] > 0:
            mape += abs(obvs_list_train[i][0][0]-overall_predictions[i][0])/obvs_list_train[i][0][0]
            total_non_zero_counter += 1

         item_id,class_id,date,store_id,dept_id = misc_list_train[i]

         d = [date,'4',str(obvs_list_train[i][0][0]),str(overall_predictions[i][0]),item_id,store_id,dept_id,class_id]
         #f1.write('%s\n'%','.join(d))

         #storing results in a predicted output for further use
         predicted_outputs.append(obvs_list_train[i][0][0])

      f1.write("MSE,%s\n"%(str(mse/len(obvs_list_train))))
      f1.write("MAPE,%s\n"%(str(mape/total_non_zero_counter)))
      f1.close()
      '''

      #Training
      print "saving model to %s"%model_file
      saver.save(sess,model_file)

      #copying the trained model file both in main directory and /tmp
      model_existence = os.path.isfile(temp_model_path)  
      if model_existence:
         print "cp %s %s" %(temp_model_path,model_path)
         os.system("cp %s %s" %(temp_model_path,model_path))
      else:
         print "cp %s %s" %(model_path,temp_model_path)
         os.system("cp %s %s" %(model_path,temp_model_path))
         
      
      #f.write("MSE,%s\n"%(str(mse/len([0 for i in test_ds if i > -10000]))))
      #f.write("MAPE,%s\n"%(str(mape/len([0 for i in test_ds if i > 0]))))
      #f.close()
      #f1.close()

      if queue:
         queue.put(predicted_outputs)
