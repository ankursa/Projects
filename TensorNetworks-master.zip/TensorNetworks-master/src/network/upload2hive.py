import os
import traceback
import base64 as b64

hive_location = "cyno_lstm.lstm_fcst_dept_3"

def fetchCredentials(credential_file):
   f = open(credential_file)
   data = f.readlines()

   username,password = None,None

   for item in data:
      if len(item) > 1:
         item = item.split('|||')
         username,password = item[0],item[1]
         username = b64.b64decode(username)
         password = password.replace('\n','')
         password = b64.b64decode(password)

   f.close()

   return username,password


#uploading data to hive location.
#args: data_file: Data file to be uploaded to hive
#credential file: encrypted username and password for uploading.
def upload(data_file,hive_location,credential_file='credentials.txt'):
   try:
      #fetch user credentials from the encrypted file
      username,password = fetchCredentials(credential_file)      
      user_upper = username.upper()
      #initializing the ticket
      os.system('echo %s | kinit %s@CORP.TARGET.COM' %(password,user_upper))
      #uploading data file to hive location
      os.system('hive -e "load data local inpath \'%s\' into table %s;"'%(data_file,hive_location))
      print "Hive Upload Complete for %s"%data_file
   except:
      traceback.print_exc()
      
