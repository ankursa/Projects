import upload2hive as u2h
import traceback
import os
from multiprocessing import Process,Queue
import sys
import time
from collections import defaultdict

# number of files to be clubbed in a single file.
BATCH = 10

def upload(root,dataset,credential_file,allready_processed,queue,prediction_table,index):
   completed_files = []
   clubbed_file = "clubbed_%d.csv"%index

   count = len(dataset)/BATCH
   if len(dataset)%BATCH > 0:
      count += 1

   start,end = 0,BATCH
   for i in range(count):
      sublist = dataset[start:end]

      for _file in sublist:
         try:
            _file = "%s/%s"%(root,_file)
            #checking the file size.
            statinfo = os.stat(_file)
            file_size = statinfo.st_size
            if file_size <= 0:
               print "[process:%d] %s size is 0"%(index,_file)
               continue
            #ignore the file if is already processed earlier to handle duplicacy in hive table
            if _file in allready_processed:
               print "[process:%d] ignoring %s "%(index,_file)
               continue

            print "[process:%d] Uploading file %s "%(index,_file)
            #u2h.upload(_file,credential_file)
            os.system("cat %s >> %s"%(_file,clubbed_file))
            print "[process:%d] File Upload Complete for %s hence removing."%(index,_file)
            os.system("rm %s"%(_file))
            completed_files.append(_file)
         except:
            traceback.print_exc()

      #uploading a clubbed file
      if os.path.isfile(clubbed_file):
         u2h.upload(clubbed_file,prediction_table,credential_file)

      os.system("echo -ne > %s" %(clubbed_file))

      start = end
      end += BATCH

   queue.put(completed_files) 


def run(source_folder,credential_file,num_of_parallels,status_file,prediction_table):
  try:
     allready_processed = {}
     num_of_parallels = int(num_of_parallels)
     try:
        f = open(status_file)
        #allready_processed = f.readlines()
        for item in f.readlines():
           item = item.replace("\n",'')
           allready_processed[item]=""
        f.close()
     except:
        traceback.print_exc()

     for root,_,files in os.walk(source_folder):
        divisions = len(files)/num_of_parallels
        remainimg = len(files)-divisions*num_of_parallels

        process_list = []
        start,end = 0,divisions
        for i in range(num_of_parallels):
           try:
              if i == num_of_parallels-1:
                 end += remainimg

              sublist = files[start:end]
              q = Queue()
              process = Process(target=upload,args=(root,sublist,credential_file,allready_processed,q,prediction_table,i))
              
              process_list.append((process,q))
              process.start()

              start = end
              end += divisions
           except:
              traceback.print_exc()
       
        #writing back to the status file
        f = open(status_file,'a') 
        for process,queue in process_list:
           completed_files = queue.get()
           for item in completed_files:
              f.write("%s\n"%item) 

        f.close()     
  except:
     traceback.print_exc()

#one file per store store_id = {# of depts}.zip
def upload_saved_models(saved_models_directory,models_table,model_type=0):
   try:
      store_models_map = defaultdict(list)

      for root,_,files in os.walk(saved_models_directory):
         for _file in files:
            _file = "%s/%s"%(root,_file)
            if "meta" not in _file:
               store_id = _file.split(".")[0].split("_")[-1]
               store_models_map[store_id].append(_file)

      #zipping store_models and upload it
      #NOTE: Need to find a way of storing binary data into hadoop.
      for k,v in store_models_map.items():
         pass
                

   except:
      traceback.print_exc()

'''
if __name__=="__main__":
   if len(sys.argv) < 7:
      print "Usage: python async_upload.py <source_result_folder> <prediction_table> <models_table> <credential_file> <# of parallel procs> <status_file> <saved_models_directory>" 
      sys.exit(0)

   source_folder = sys.argv[1]
   prediction_table = sys.argv[2]
   models_table = sys.argv[3]
   credential_file = sys.argv[4]
   parallel_procs = sys.argv[5]
   status_file = sys.argv[6]
   saved_models_directory = sys.argv[7]

   while True:
      print "Starting Hive Upload Process"
      run(source_folder,credential_file,parallel_procs,status_file,prediction_table)
      print "Completed Hive Upload Process"
      
      print "Uploading Saved Models"
      upload_saved_models(saved_models_directory,models_table)
      time.sleep(5)
'''
