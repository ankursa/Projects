import sys
import os
import csv
import misc as ms
import traceback
import hive_store as hs
import tcp_client as tclient
import time
from multiprocessing import Process,Queue
import async_upload as asup

class Automate(object):
   def __init__(self,zid,credential_file,all_store_file,nodes_file):
      self.zid = zid
      self.credential_file = credential_file
      self.all_stores = all_store_file
      self.nodes_file = nodes_file

   def nodes(self):
      f = open(self.nodes_file)
      reader = csv.reader(f,delimiter=",")

      nodes_list = []
      for node in reader:
         nodes_list.append(node[0])
 
      return nodes_list


   def readCSV(self,file_name,file_handler=None):
      counter = 0
      try:
         f = open(file_name)
         reader = csv.reader(f,delimiter=",")
         for item in reader:
            if file_handler:
               file_handler.write("%s\n"%item[0])
            counter += 1
         f.close()
      except KeyboardInterrupt:
         self.cleaner()
      except:
         traceback.print_exc()

      return counter


   def fetch_stores(self,num_of_splits,last_num_of_splits,store_status_file,source_table,model_type,mode):
      #TODO: Check the status of handshaking table.
      #If there is an entry for today proceed further otherwise return.
  
      filetype = "store_%d.csv"

      total_files = []

      if model_type == 3 or model_type == 5:
         filetype = "depts_%d.csv"
      if model_type == 4:
         filetype  = "class_%d.csv"
 
      f = open(store_status_file,"a")
      for i in range(last_num_of_splits):
         filename = filetype%i
         self.readCSV(filename,f) 

      ms.kinit(self.credential_file)
      hs.fetch(num_of_splits,self.all_stores,store_status_file,model_type,mode,source_table)

      total_count = 0
      for i in range(num_of_splits):
         filename = filetype%i
         total_files.append(filename)
         counter = self.readCSV(filename,f) 
         total_count += counter

      f.close()

      return total_count,total_files

   #python rnn_multigpu.py <store_file> <department_file> <source_table> <credential_file> <mode=(0:training,1:testing)> <mtype=(0:item-week(store-dept.),1:item-week(store-class.),2:item-week(store-items.),3:item-chain(dept.),4:item-chain(class.),5:item-chain(items.))>
   def create_message(self,**kwargs):
      table = kwargs.get("table")
      mode = kwargs.get("mode")
      model_type = kwargs.get("model_type")
      input_file = kwargs.get("input_file")
      credentials = kwargs.get("credentials")

      primary = "stores.txt"
      secondary = "depts.txt"

      if model_type == 0 or model_type == 1 or model_type == 2:
          primary = input_file
          secondary = "depts.txt"
          if model_type == 1:
             secondary = "class.txt"
     
      if model_type == 3 or model_type == 4 or model_type == 5:
          primary = "stores.txt"
          secondary = input_file

      input_string_list = [primary,secondary,table,credentials,str(mode),str(model_type)]

      input_string = " ".join(input_string_list)

      return input_string
       

   def get_alive_servers(self,port):
      nodes_list = self.nodes()

      #checking alive servers
      alive_servers = []
      for server in nodes_list: 
         status = tclient.check_server_status(server,port)
         if status:
            alive_servers.append(server)

      return alive_servers

   def remote_execution(self,server,port,message):
      try:
         print "Connecting to server %s"%server
         tclient.connect_and_send(server,port,message,self.cleaner)
      except KeyboardInterrupt:
         self.cleaner()
      except:
         traceback.print_exc()

   def execute_models(self,alive_servers,port,store_status_file,mode,source_table,model_type):
      try:
         num_of_splits = len(alive_servers)
         last_num_of_splits = 0

         count,total_files = self.fetch_stores(num_of_splits,last_num_of_splits,store_status_file,source_table,model_type,mode)
         last_num_of_splits = num_of_splits

         print count 
         while count > 0:
            print "# of store to run %d"%count 
            
            process_list = []
            #Step1: Call TCP Tensorflow code on multiple machines
            for i in range(len(alive_servers)):
               input_file = total_files[i]
               message_dict = {"table":source_table,"mode":mode,"model_type":model_type,
                               "input_file":input_file,"credentials":self.credential_file}

               message = self.create_message(**message_dict)
               print "Message = ",message
               pid = Process(target=self.remote_execution,args=(alive_servers[i],port,message))
               process_list.append(pid)

               pid.start() 
          
            for item in process_list:
               item.join()
               
            alive_servers = self.get_alive_servers(port) 
            num_of_splits = len(alive_servers)
            count,total_files = self.fetch_stores(num_of_splits,last_num_of_splits,store_status_file,source_table,model_type,mode)
            print "New Count =",count
            last_num_of_splits = num_of_splits
        
      except:
         traceback.print_exc()

   def cleaner(self,server):
      try:
         for i in range(5):
             print "ssh %s@%s '%s'" %('z001jv4',server,'/home_dir/z001jv4/preprocessor/clean.sh')
             os.system("ssh %s@%s '%s'" %('z001jv4',server,'/home_dir/z001jv4/preprocessor/clean.sh'))
      except:
         traceback.print_exc()

   def clean_all(self):
      nodes_list = self.nodes()

      for node in nodes_list:
         self.cleaner(node)


   #python rnn_multigpu.py <store_file> <department_file> <source_table> <credential_file> <mode=(0:training,1:testing)> <mtype=(0:item-week(store-dept.),1:item-week(store-class.),2:item-week(store-items.),3:item-chain(dept.),4:item-chain(class.),5:item-chain(items.))>
   #1. item-loc-week (var:store,const:dept)
   #2. item-loc-week (var:store,const:class)
   #3. item-loc-week (var:stote,const:dept)

   #4. item-chain-week (const:store,var:dept)
   #5. item-chain-week (const:store,var:class)
   #6. item-chain-week (const:store,var:dept)

   #mode: training / prediction

   def execute(self,store_status_file,**kwargs):
      try:
         #cleaning allready running unwanted process on nodes
         self.clean_all()
         
         port = 5000

         #Input
         #6 options
         model_type = kwargs.get("model_type")

         #Source table for training data.
         source_table = kwargs.get("source_table_training")

         #Source table for prediction data.
         source_table_prediction = kwargs.get("source_table_prediction")

         #Model results directory
         result_directory = kwargs.get("result_directory")

         #Prediction Results Table
         predicted_result_table = kwargs.get("predicted_result_table")

        
         #NOTE: Step: 1 For Training
         alive_servers = self.get_alive_servers(port) 
         if len(alive_servers) > 0:
            os.system("echo -ne > %s" %(store_status_file))
            #step 1: execute training on multiple machines
            self.execute_models(alive_servers,port,store_status_file,0,source_table,model_type)


         #NOTE: Step 2 For Prediction
         alive_servers = self.get_alive_servers(port) 
         if len(alive_servers) > 0:
            os.system("echo -ne > %s" %(store_status_file))
            #Step 2: running predictions on multiple machines
            self.execute_models(alive_servers,port,store_status_file,1,source_table_prediction,model_type)

         #NOTE: Step 3: Hive upload
         os.system("echo -ne > status.txt")
         asup.run(result_directory,self.credential_file,10,"status.txt",predicted_result_table)


         #NOTE: Step 4: Update the status to prevent accidental runs
         ms.updateStatus("automation_status_table",self.credential_file)

      except KeyboardInterrupt:
         self.cleaner()
      except:
         traceback.print_exc()

#TODO:
#This part should be run infinitely.
#Handshaking should be there with preprocessing module.
#Once the data is available to the system , this module should start automatically.


kwargs = {}
kwargs["model_type"] = 0
kwargs["source_table_training"] = "preprocessed_30k_new_wthr_store10"
kwargs["source_table_prediction"] = "preprocessed_30k_new_wthr_store10"
kwargs["result_directory"] = "output_results"
kwargs["predicted_result_table"] = "cyno_lstm.lstm_fcst_dept_full"

auto = Automate("z001jv4","cred_nitin.txt","all_stores.txt","nodes.txt")
auto.execute("allready_full.txt",**kwargs)

"""
kwargs = {"model_type":0,"source_table_training":"preprocessed_30k_new_wthr_store2","source_table_prediction":"preprocessed_30k_new_wthr_store2",
          "result_directory":"output_results","predicted_result_table":"cyno_lstm.lstm_fcst_dept_full"}
"""

