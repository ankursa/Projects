import tensorflow as tf
import numpy as np
import traceback
import csv
from tensorflow.python.ops import rnn,rnn_cell
import sys
import os
import read_data as rd
import upload2hive as u2h

#input_file = sys.argv[1]
#gname = sys.argv[2]

def run_model_prediction(data_list,obvs_list,misc_list,gname,model_path,temp_model_path,queue=None):
   ###### params #########
   #input_file = input_file
   percentage = 1
   mbatch = 70000
   rnn_size = 20
   alpha = 0.0
   num_of_layers = 2
   iterations = 1
   #######################

   #covariated & Observations
   #data_list,obvs_list = rd.readCSV(input_file)
   datalen_ = len(data_list)
   #state dimension calculations
   N = len(data_list[0][0])

   #Extracting Training and Testing data
   '''
   index = int(datalen_*percentage)

   data_list_train = data_list[:index]
   obvs_list_train = obvs_list[:index]

   misc_list_train = misc_list[:index]

   train_size = len(obvs_list_train)

   index_diff = datalen_ - index

   total_division = len(data_list_train)/mbatch
   if len(data_list_train)%mbatch > 0:
      total_division += 1
   '''
   #aa = np.array(data_list_train)
   dlist = []
   '''
   start = 0
   end = mbatch
   for i in range(total_division):
      dlist.append(np.transpose(np.array(data_list_train[start:end]),[1,0,2]))
      start = end
      end += mbatch
   '''
   dlist.append(np.array(data_list))

   #dlist.append(np.transpose(np.array(data_list_train[start:end]),[1,0,2]))
   #aa = np.transpose(aa,(1,0,2))

   '''
   start = 0
   end = mbatch
   '''

   covariates = tf.placeholder(tf.float32,[None,None,N],name="covariates")
   covariates_ = [covariates]


   weights = tf.Variable(tf.random_normal([rnn_size,1]),name="weights")
   biases = tf.Variable(tf.random_normal([1]),name="biases")

   def model():

      #x = tf.transpose(covariates,[1,0,2])
      x = covariates

      lstm_cell = rnn_cell.BasicLSTMCell(rnn_size,state_is_tuple=True)
      #lstm_cell = rnn_cell.GRUCell(rnn_size)
      DCell = rnn_cell.DropoutWrapper(lstm_cell,output_keep_prob=0.5)
      multi_cell = rnn_cell.MultiRNNCell([lstm_cell]*num_of_layers,state_is_tuple=True)

      outputs,_ = rnn.dynamic_rnn(multi_cell,x,dtype=tf.float32)
      outputs_flattened = tf.reshape(outputs,[-1,rnn_size])

      output_all = tf.matmul(outputs_flattened,weights) + biases

      return output_all

   prediction_all = model()

   config = tf.ConfigProto()
   config.gpu_options.allow_growth = True

   #restoring model
   current_directory = os.getcwd()
   #model_file = "%s/model_%s.ckpt"%(current_directory,"_".join(gname.split("_")[1:]))
   model_file = temp_model_path
   model_existence = os.path.isfile(model_file)  

   if not model_existence:
      model_file = model_path
      print "model reloaded %s exists" %model_file
   else:
      print "model = %s exists" %model_file

   saver = tf.train.Saver()

   with tf.Session(config=config) as sess:
     with tf.device("/gpu:0"):
      #sess.run(tf.initialize_all_variables())

      saver.restore(sess,model_file)

      overall_predictions = []

      for iter_ in range(iterations):
         overall_predictions = []
         for i in range(len(dlist)):
            cov_ = dlist[i]

            feed_dict = {covariates:cov_}
            pred_all = sess.run([prediction_all],feed_dict=feed_dict)
            overall_predictions.extend(pred_all[0].tolist())


      result_file = "output_results/prediction_%s.csv"%gname
      f1 = open(result_file,'w')

      mse,mape = 0.0,0.0
      for i in range(len(obvs_list)):
         item_id,class_id,date,store_id,dept_id = misc_list[i]
         predicted_value = overall_predictions[i][0] if overall_predictions[i][0] > 0.0 else 0.0
         horizon = '4'

         d = [date,horizon,str(obvs_list[i][0][0]),str(predicted_value),item_id,store_id,dept_id,class_id]
         #d = [date,'4',str(obvs_list[i][0][0]),str(overall_predictions[i][0]),dept_id,store_id,class_id,item_id]
         f1.write('%s\n'%','.join(d))

      f1.close()
