/*
 * Licensed to the Apache Software Foundation (ASF) under one or more
 * contributor license agreements.  See the NOTICE file distributed with
 * this work for additional information regarding copyright ownership.
 * The ASF licenses this file to You under the Apache License, Version 2.0
 * (the "License"); you may not use this file except in compliance with
 * the License.  You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package org.apache.spark.mllib.feature

import java.io.{File, StringWriter}
import java.lang.{Iterable => JavaIterable}

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.module.scala.DefaultScalaModule
import groovy.transform.Synchronized

import scala.collection.JavaConverters._
import scala.collection.mutable
import scala.collection.mutable.ArrayBuilder
import scala.io.Source

import scala.util.parsing.json
import org.zeromq.ZMQ
import org.zeromq.ZMQ.{Context,Socket}

import com.github.fommil.netlib.BLAS.{getInstance => blas}

import org.json4s.DefaultFormats
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods._

import org.apache.spark.{SparkConf, Logging, SparkContext}
import org.apache.spark.SparkContext._
import org.apache.spark.annotation.Experimental
import org.apache.spark.api.java.JavaRDD
import org.apache.spark.mllib.linalg.{Vector, Vectors, DenseMatrix, BLAS, DenseVector}
import org.apache.spark.mllib.util.{Loader, Saveable}
import org.apache.spark.rdd._
import org.apache.spark.util.Utils
import org.apache.spark.util.random.XORShiftRandom
import org.apache.spark.sql.{SQLContext, Row}
import com.codahale.jerkson

/**
 *  Entry in vocabulary
 */
private case class VocabWord(
  var word: String,
  var cn: Int,
  var point: Array[Int],
  var code: Array[Int],
  var codeLen: Int
)


/**
 * :: Experimental ::
 * Word2Vec creates vector representation of words in a text corpus.
 * The algorithm first constructs a vocabulary from the corpus
 * and then learns vector representation of words in the vocabulary.
 * The vector representation can be used as features in
 * natural language processing and machine learning algorithms.
 *
 * We used skip-gram model in our implementation and hierarchical softmax
 * method to train the model. The variable names in the implementation
 * matches the original C implementation.
 *
 * For original C implementation, see https://code.google.com/p/word2vec/
 * For research papers, see
 * Efficient Estimation of Word Representations in Vector Space
 * and
 * Distributed Representations of Words and Phrases and their Compositionality.
 */
@Experimental
class Word2Vec extends Serializable with Logging {

  private var vectorSize = 100
  private var learningRate = 0.025
  private var numPartitions = 1
  private var numIterations = 1
  private var seed = Utils.random.nextLong()
  private var minCount = 5

  /**
   * Sets vector size (default: 100).
   */
  def setVectorSize(vectorSize: Int): this.type = {
    this.vectorSize = vectorSize
    this
  }

  /**
   * Sets initial learning rate (default: 0.025).
   */
  def setLearningRate(learningRate: Double): this.type = {
    this.learningRate = learningRate
    this
  }

  /**
   * Sets number of partitions (default: 1). Use a small number for accuracy.
   */
  def setNumPartitions(numPartitions: Int): this.type = {
    require(numPartitions > 0, s"numPartitions must be greater than 0 but got $numPartitions")
    this.numPartitions = numPartitions
    this
  }

  /**
   * Sets number of iterations (default: 1), which should be smaller than or equal to number of
   * partitions.
   */
  def setNumIterations(numIterations: Int): this.type = {
    this.numIterations = numIterations
    this
  }

  /**
   * Sets random seed (default: a random long integer).
   */
  def setSeed(seed: Long): this.type = {
    this.seed = seed
    this
  }

  /**
   * Sets minCount, the minimum number of times a token must appear to be included in the word2vec
   * model's vocabulary (default: 5).
   */
  def setMinCount(minCount: Int): this.type = {
    this.minCount = minCount
    this
  }

  private val EXP_TABLE_SIZE = 1000
  private val MAX_EXP = 6
  private val MAX_CODE_LENGTH = 40
  private val MAX_SENTENCE_LENGTH = 102400//1000

  /** context words from [-window, window] */
  private val window = 5

  private var trainWordsCount = 0
  private var vocabSize = 0
  private var vocab: Array[VocabWord] = null
  private var vocabHash = mutable.HashMap.empty[String, Int]

  private def learnVocab(words: RDD[String]): Unit = {
    vocab = words.map(w => (w, 1))
      .reduceByKey(_ + _)
      .map(x => VocabWord(
        x._1,
        x._2,
        new Array[Int](MAX_CODE_LENGTH),
        new Array[Int](MAX_CODE_LENGTH),
        0))
      .filter(_.cn >= minCount)
      .collect()
      .sortWith((a, b) => a.cn > b.cn)

    vocabSize = vocab.length
    var a = 0
    while (a < vocabSize) {
      vocabHash += vocab(a).word -> a
      trainWordsCount += vocab(a).cn
      a += 1
    }
    logInfo("trainWordsCount = " + trainWordsCount)
  }

  private def createExpTable(): Array[Float] = {
    val expTable = new Array[Float](EXP_TABLE_SIZE)
    var i = 0
    while (i < EXP_TABLE_SIZE) {
      val tmp = math.exp((2.0 * i / EXP_TABLE_SIZE - 1.0) * MAX_EXP)
      expTable(i) = (tmp / (tmp + 1.0)).toFloat
      i += 1
    }
    expTable
  }

  private def createBinaryTree(): Unit = {
    val count = new Array[Long](vocabSize * 2 + 1)
    val binary = new Array[Int](vocabSize * 2 + 1)
    val parentNode = new Array[Int](vocabSize * 2 + 1)
    val code = new Array[Int](MAX_CODE_LENGTH)
    val point = new Array[Int](MAX_CODE_LENGTH)
    var a = 0
    while (a < vocabSize) {
      count(a) = vocab(a).cn
      a += 1
    }
    while (a < 2 * vocabSize) {
      count(a) = 1e9.toInt
      a += 1
    }
    var pos1 = vocabSize - 1
    var pos2 = vocabSize

    var min1i = 0
    var min2i = 0

    a = 0
    while (a < vocabSize - 1) {
      if (pos1 >= 0) {
        if (count(pos1) < count(pos2)) {
          min1i = pos1
          pos1 -= 1
        } else {
          min1i = pos2
          pos2 += 1
        }
      } else {
        min1i = pos2
        pos2 += 1
      }
      if (pos1 >= 0) {
        if (count(pos1) < count(pos2)) {
          min2i = pos1
          pos1 -= 1
        } else {
          min2i = pos2
          pos2 += 1
        }
      } else {
        min2i = pos2
        pos2 += 1
      }
      count(vocabSize + a) = count(min1i) + count(min2i)
      parentNode(min1i) = vocabSize + a
      parentNode(min2i) = vocabSize + a
      binary(min2i) = 1
      a += 1
    }
    // Now assign binary code to each vocabulary word
    var i = 0
    a = 0
    while (a < vocabSize) {
      var b = a
      i = 0
      while (b != vocabSize * 2 - 2) {
        code(i) = binary(b)
        point(i) = b
        i += 1
        b = parentNode(b)
      }
      vocab(a).codeLen = i
      vocab(a).point(0) = vocabSize - 2
      b = 0
      while (b < i) {
        vocab(a).code(i - b - 1) = code(b)
        vocab(a).point(i - b) = point(b) - vocabSize
        b += 1
      }
      a += 1
    }
  }

  /**
   * Computes the vector representation of each word in vocabulary.
   * @param dataset an RDD of words
   * @return a Word2VecModel
   */
  def fit[S <: Iterable[String]](dataset: RDD[S]): Word2VecModel = {

    val words = dataset.flatMap(x => x)

    learnVocab(words)

    createBinaryTree()

    val sc = dataset.context

    val expTable = sc.broadcast(createExpTable())
    val bcVocab = sc.broadcast(vocab)
    val bcVocabHash = sc.broadcast(vocabHash)

    val sentences: RDD[Array[Int]] = words.mapPartitions { iter =>
      new Iterator[Array[Int]] {
        def hasNext: Boolean = iter.hasNext

        def next(): Array[Int] = {
          val sentence = ArrayBuilder.make[Int]
          var sentenceLength = 0
          while (iter.hasNext && sentenceLength < MAX_SENTENCE_LENGTH) {
            val word = bcVocabHash.value.get(iter.next())
            word match {
              case Some(w) =>
                sentence += w
                sentenceLength += 1
              case None =>
            }
          }
          sentence.result()
        }
      }
    }

    val newSentences = sentences.repartition(numPartitions).cache()
    val initRandom = new XORShiftRandom(seed)

    if (vocabSize.toLong * vectorSize * 8 >= Int.MaxValue) {
      throw new RuntimeException("Please increase minCount or decrease vectorSize in Word2Vec" +
        " to avoid an OOM. You are highly recommended to make your vocabSize*vectorSize, " +
        "which is " + vocabSize + "*" + vectorSize + " for now, less than `Int.MaxValue/8`.")
    }

    val syn0Global =
      Array.fill[Float](vocabSize * vectorSize)((initRandom.nextFloat() - 0.5f) / vectorSize)
    val syn1Global = new Array[Float](vocabSize * vectorSize)
    var alpha = learningRate
    for (k <- 1 to numIterations) {
      val partial = newSentences.mapPartitionsWithIndex { case (idx, iter) =>
        val random = new XORShiftRandom(seed ^ ((idx + 1) << 16) ^ ((-k - 1) << 8))
        val syn0Modify = new Array[Int](vocabSize)
        val syn1Modify = new Array[Int](vocabSize)
        val model = iter.foldLeft((syn0Global, syn1Global, 0, 0)) {
          case ((syn0, syn1, lastWordCount, wordCount), sentence) =>
            var lwc = lastWordCount
            var wc = wordCount
            if (wordCount - lastWordCount > 10000) {
              lwc = wordCount
              // TODO: discount by iteration?
              alpha =
                learningRate * (1 - numPartitions * wordCount.toDouble / (trainWordsCount + 1))
              if (alpha < learningRate * 0.0001) alpha = learningRate * 0.0001
              logInfo("wordCount = " + wordCount + ", alpha = " + alpha)
            }
            wc += sentence.size
            var pos = 0
            while (pos < sentence.size) {
              val word = sentence(pos)
              val b = random.nextInt(window)
              // Train Skip-gram
              var a = b
              while (a < window * 2 + 1 - b) {
                if (a != window) {
                  val c = pos - window + a
                  if (c >= 0 && c < sentence.size) {
                    val lastWord = sentence(c)
                    val l1 = lastWord * vectorSize
                    val neu1e = new Array[Float](vectorSize)
                    // Hierarchical softmax
                    var d = 0
                    while (d < bcVocab.value(word).codeLen) {
                      val inner = bcVocab.value(word).point(d)
                      val l2 = inner * vectorSize
                      // Propagate hidden -> output
                      var f = blas.sdot(vectorSize, syn0, l1, 1, syn1, l2, 1)
                      if (f > -MAX_EXP && f < MAX_EXP) {
                        val ind = ((f + MAX_EXP) * (EXP_TABLE_SIZE / MAX_EXP / 2.0)).toInt
                        f = expTable.value(ind)
                        val g = ((1 - bcVocab.value(word).code(d) - f) * alpha).toFloat
                        blas.saxpy(vectorSize, g, syn1, l2, 1, neu1e, 0, 1)
                        blas.saxpy(vectorSize, g, syn0, l1, 1, syn1, l2, 1)
                        syn1Modify(inner) += 1
                      }
                      d += 1
                    }
                    blas.saxpy(vectorSize, 1.0f, neu1e, 0, 1, syn0, l1, 1)
                    syn0Modify(lastWord) += 1
                  }
                }
                a += 1
              }
              pos += 1
            }
            (syn0, syn1, lwc, wc)
        }
        val syn0Local = model._1
        val syn1Local = model._2
        // Only output modified vectors.
        Iterator.tabulate(vocabSize) { index =>
          if (syn0Modify(index) > 0) {
            Some((index, syn0Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten ++ Iterator.tabulate(vocabSize) { index =>
          if (syn1Modify(index) > 0) {
            Some((index + vocabSize, syn1Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten
      }
      val synAgg = partial.reduceByKey { case (v1, v2) =>
          blas.saxpy(vectorSize, 1.0f, v2, 1, v1, 1)
          v1
      }.collect()
      var i = 0
      while (i < synAgg.length) {
        val index = synAgg(i)._1
        if (index < vocabSize) {
          Array.copy(synAgg(i)._2, 0, syn0Global, index * vectorSize, vectorSize)
        } else {
          Array.copy(synAgg(i)._2, 0, syn1Global, (index - vocabSize) * vectorSize, vectorSize)
        }
        i += 1
      }
    }
    newSentences.unpersist()

    val word2VecMap = mutable.HashMap.empty[String, Array[Float]]
    var i = 0
    while (i < vocabSize) {
      val word = bcVocab.value(i).word
      val vector = new Array[Float](vectorSize)
      Array.copy(syn0Global, i * vectorSize, vector, 0, vectorSize)
      word2VecMap += word -> vector
      i += 1
    }
    //test
    new Word2VecModel(word2VecMap.toMap)
  }

  /**
   * Computes the vector representation of each word in vocabulary (Java version).
   * @param dataset a JavaRDD of words
   * @return a Word2VecModel
   */
  def fit[S <: JavaIterable[String]](dataset: JavaRDD[S]): Word2VecModel = {
    fit(dataset.rdd.map(_.asScala))
  }
}
case class Vocab(vocab : Array[Map[String,Int]],vocabSize : Int, iter_num : Int, trainWordsCount : Int, numPartitions : Int) extends Serializable
case class Syn0_new(syn0 : Array[Float],start : Int, end : Int, size : Int) extends Serializable
case class Syn1_new(syn1 : Array[Float], start : Int, end : Int, size : Int) extends Serializable
case class Sentence(sentence:Array[Int],sen_length:Int) extends Serializable
case class Syn0Updated(syn0 : Array[Float],syn0BitVectorJson : Array[Int],start: Int, end: Int, size : Int) extends Serializable
case class Syn1Updated(syn1 : Array[Float],syn1BitVectorJson : Array[Int],start: Int, end: Int, size : Int) extends Serializable

case class Vocab_fileIO(vocab : String,vocabSize : Int, iter_num : Int, trainWordsCount : Int, numPartitions : Int) extends Serializable
case class Syn0_fileIO(syn0 : String,size : Int) extends Serializable
case class Syn1_fileIO(syn1 : String,size : Int) extends Serializable
case class Sentence_fileIO(sentence:Array[Int],sen_length:Int) extends Serializable
case class Syn0Updated_fileIO(syn0 : String,syn0BitVectorJson : Array[Int], size : Int) extends Serializable
case class Syn1Updated_fileIO(syn1 : String,syn1BitVectorJson : Array[Int], size : Int) extends Serializable

@Experimental
class Word2Vec2 extends Serializable with Logging {

  private var vectorSize = 100
  private var learningRate = 0.025
  private var numPartitions = 2
  private var numIterations = 2
  private var seed = Utils.random.nextLong()
  private var minCount = 5

  /**
   * Sets vector size (default: 100).
   */
  def setVectorSize(vectorSize: Int): this.type = {
    this.vectorSize = vectorSize
    this
  }

  /**
   * Sets initial learning rate (default: 0.025).
   */
  def setLearningRate(learningRate: Double): this.type = {
    this.learningRate = learningRate
    this
  }

  /**
   * Sets number of partitions (default: 1). Use a small number for accuracy.
   */
  def setNumPartitions(numPartitions: Int): this.type = {
    require(numPartitions > 0, s"numPartitions must be greater than 0 but got $numPartitions")
    this.numPartitions = numPartitions
    this
  }

  /**
   * Sets number of iterations (default: 1), which should be smaller than or equal to number of
   * partitions.
   */
  def setNumIterations(numIterations: Int): this.type = {
    this.numIterations = numIterations
    this
  }

  /**
   * Sets random seed (default: a random long integer).
   */
  def setSeed(seed: Long): this.type = {
    this.seed = seed
    this
  }

  /**
   * Sets minCount, the minimum number of times a token must appear to be included in the word2vec
   * model's vocabulary (default: 5).
   */
  def setMinCount(minCount: Int): this.type = {
    this.minCount = minCount
    this
  }

  private val EXP_TABLE_SIZE = 1000
  private val MAX_EXP = 6
  private val MAX_CODE_LENGTH = 40
  private var MAX_SENTENCE_LENGTH = 409600

  private var MAX_SYN_SIZE_TO_SEND = 45000000
  private var FILE_IO_PATH = ""

  /**
   * Sets max_sentence_length, the maximum size of sentence to be parsed at a time.
   */
  def setMaxSentenceLength(sen_length: Int): this.type = {
    this.MAX_SENTENCE_LENGTH = sen_length
    this
  }

  /**
   * Sets max_syn_size, the maximum size of syn arrays to be send at a time.
   */
  def setMaxSynSizeToSend(syn_size: Int): this.type = {
    this.MAX_SYN_SIZE_TO_SEND = syn_size
    this
  }

  /**
   * Sets the path where syn0, syn1, vocab etc are persisted on disk
   */
  def setFILEIOPATH(file_io_path: String): this.type = {
    this.FILE_IO_PATH = file_io_path
    this
  }

  /** context words from [-window, window] */
  private val window = 5

  private var trainWordsCount = 0
  private var vocabSize = 0
  private var vocab: Array[VocabWord] = null
  private var vocabHash = mutable.HashMap.empty[String, Int]

  private def learnVocab(words: RDD[String]): Unit = {
    vocab = words.map(w => (w, 1))
      .reduceByKey(_ + _)
      .map(x => VocabWord(
      x._1,
      x._2,
      new Array[Int](MAX_CODE_LENGTH),
      new Array[Int](MAX_CODE_LENGTH),
      0))
      .filter(_.cn >= minCount)
      .collect()
      .sortWith((a, b) => a.cn > b.cn)

    vocabSize = vocab.length
    var a = 0
    while (a < vocabSize) {
      vocabHash += vocab(a).word -> a
      trainWordsCount += vocab(a).cn
      a += 1
    }
    logInfo("trainWordsCount = " + trainWordsCount)
  }

  private def createExpTable(): Array[Float] = {
    val expTable = new Array[Float](EXP_TABLE_SIZE)
    var i = 0
    while (i < EXP_TABLE_SIZE) {
      val tmp = math.exp((2.0 * i / EXP_TABLE_SIZE - 1.0) * MAX_EXP)
      expTable(i) = (tmp / (tmp + 1.0)).toFloat
      i += 1
    }
    expTable
  }

  private def learnVocab_new[S <: Iterable[String]](dataset: RDD[S]): Unit = {
    val words = dataset.flatMap(x => x)

    vocab = words.map(w => (w, 1))
      .reduceByKey(_ + _)
      .filter(_._2 >= minCount)
      .map(x => VocabWord(
      x._1,
      x._2,
      new Array[Int](MAX_CODE_LENGTH),
      new Array[Int](MAX_CODE_LENGTH),
      0))
      .collect()
      .sortWith((a, b) => a.cn > b.cn)

    vocabSize = vocab.length
    require(vocabSize > 0, "The vocabulary size should be > 0. You may need to check " +
      "the setting of minCount, which could be large enough to remove all your words in sentences.")

    var a = 0
    while (a < vocabSize) {
      vocabHash += vocab(a).word -> a
      trainWordsCount += vocab(a).cn
      a += 1
    }
    logInfo(s"vocabSize = $vocabSize, trainWordsCount = $trainWordsCount")
  }

  private def createBinaryTree(): Unit = {
    val count = new Array[Long](vocabSize * 2 + 1)
    val binary = new Array[Int](vocabSize * 2 + 1)
    val parentNode = new Array[Int](vocabSize * 2 + 1)
    val code = new Array[Int](MAX_CODE_LENGTH)
    val point = new Array[Int](MAX_CODE_LENGTH)
    var a = 0
    while (a < vocabSize) {
      count(a) = vocab(a).cn
      a += 1
    }
    while (a < 2 * vocabSize) {
      count(a) = 1e9.toInt
      a += 1
    }
    var pos1 = vocabSize - 1
    var pos2 = vocabSize

    var min1i = 0
    var min2i = 0

    a = 0
    while (a < vocabSize - 1) {
      if (pos1 >= 0) {
        if (count(pos1) < count(pos2)) {
          min1i = pos1
          pos1 -= 1
        } else {
          min1i = pos2
          pos2 += 1
        }
      } else {
        min1i = pos2
        pos2 += 1
      }
      if (pos1 >= 0) {
        if (count(pos1) < count(pos2)) {
          min2i = pos1
          pos1 -= 1
        } else {
          min2i = pos2
          pos2 += 1
        }
      } else {
        min2i = pos2
        pos2 += 1
      }
      count(vocabSize + a) = count(min1i) + count(min2i)
      parentNode(min1i) = vocabSize + a
      parentNode(min2i) = vocabSize + a
      binary(min2i) = 1
      a += 1
    }
    // Now assign binary code to each vocabulary word
    var i = 0
    a = 0
    while (a < vocabSize) {
      var b = a
      i = 0
      while (b != vocabSize * 2 - 2) {
        code(i) = binary(b)
        point(i) = b
        i += 1
        b = parentNode(b)
      }
      vocab(a).codeLen = i
      vocab(a).point(0) = vocabSize - 2
      b = 0
      while (b < i) {
        vocab(a).code(i - b - 1) = code(b)
        vocab(a).point(i - b) = point(b) - vocabSize
        b += 1
      }
      a += 1
    }
  }

  private def createSerializedSyn(syn : Array[Float], index : Int, mapper: ObjectMapper, id : Int) : (Int,Boolean,String) = {
    var isPartRemaining = true
    val size = syn.length
    val max_index = index + MAX_SYN_SIZE_TO_SEND
    var endIndex = max_index
    if(max_index+1>=size){
      isPartRemaining = false
      endIndex = size
    }
    val subsetSyn = syn.slice(index,endIndex)
    var serializedString = ""
    if(id == 0){
      serializedString = mapper.writeValueAsString(Syn0_new(subsetSyn,index,endIndex-1,size))
    }
    else{
      serializedString = mapper.writeValueAsString(Syn1_new(subsetSyn,index,endIndex-1,size))
    }
    (endIndex,isPartRemaining,serializedString)
  }

  def printToFile(f: java.io.File)(op: java.io.PrintWriter => Unit) {
    val p = new java.io.PrintWriter(f)
    try { op(p) } finally { p.close() }
  }

  /**
   * Computes the vector representation of each word in vocabulary.
   * @param dataset an RDD of words
   * @return a Word2VecModel
   */
  def fit[S <: Iterable[String]](dataset: RDD[S]): Word2VecModel = {

    val words = dataset.flatMap(x => x)
    learnVocab(words)

    val sc = dataset.context

    val bcVocab = sc.broadcast(vocab)
    val bcVocabHash = sc.broadcast(vocabHash)

    val sentences: RDD[Array[Int]] = words.mapPartitions { iter =>
      new Iterator[Array[Int]] {
        def hasNext: Boolean = iter.hasNext

        def next(): Array[Int] = {
          val sentence = ArrayBuilder.make[Int]
          var sentenceLength = 0
          while (iter.hasNext && sentenceLength < MAX_SENTENCE_LENGTH) {
            val word = bcVocabHash.value.get(iter.next())
            word match {
              case Some(w) =>
                sentence += w
                sentenceLength += 1
              case None =>
            }
          }
          sentence.result()
        }
      }
    }

    val newSentences = sentences.repartition(numPartitions).cache()
    println("Number of sentences to send : " + newSentences.count())
    //val newSentences = sentences.cache()
    val initRandom = new XORShiftRandom(seed)

    if (vocabSize.toLong * vectorSize * 8 >= Int.MaxValue) {
      throw new RuntimeException("Please increase minCount or decrease vectorSize in Word2Vec" +
        " to avoid an OOM. You are highly recommended to make your vocabSize*vectorSize, " +
        "which is " + vocabSize + "*" + vectorSize + " for now, less than `Int.MaxValue/8`.")
    }

    val syn0Global =
      Array.fill[Float](vocabSize * vectorSize)((initRandom.nextFloat() - 0.5f) / vectorSize)
    val syn1Global = new Array[Float](vocabSize * vectorSize)
    var alpha = learningRate

    var partRemaining = true
    var endIndex = 0
    var synMsg = ""
    var outTriplet = (endIndex,partRemaining,synMsg)

    for (k <- 1 to numIterations) {
      val partial = newSentences.mapPartitionsWithIndex { case (idx, iter) =>
        val random = new XORShiftRandom(seed ^ ((idx + 1) << 16) ^ ((-k - 1) << 8))
        var syn0Modify = new Array[Int](vocabSize)
        var syn1Modify = new Array[Int](vocabSize)
        @transient val context = ZMQ.context(1)
        @transient val socket = context.socket(ZMQ.REQ)
        val mapper = new ObjectMapper()
        mapper.registerModule(DefaultScalaModule)

        println("Connecting to W2V GPU server…")
        socket.connect("tcp://localhost:5556")
        var vocabDone = false
        var syn0Done = false
        var syn1Done = false
        /*Sending vocab. Only during the first iteration as it can be reused in later iterations*/
        val thread_vocab = new Thread{
          override def run : Unit = {
            if(k==1){
              logInfo("Sending vocab request … " )
              val vocab_array = vocab.map(x => Map("cn" -> x.cn))
              socket.send(mapper.writeValueAsString(Vocab(vocab_array,vocab.length,k,trainWordsCount,numPartitions)),ZMQ.SNDMORE)
              println("Vocab Request sent")
            }
            else{
              logInfo("Sending iter_num info alone … " )
              socket.send(mapper.writeValueAsString(Map("iter_num"->k,"trainWordsCount"->trainWordsCount,"numPartitions"->numPartitions)),ZMQ.SNDMORE)
              println("iter_num info sent")
            }
            vocabDone = true
          }
        }
        thread_vocab.start()

        /*Sending syn0*/
        println("Sending Syn0 request … , size : " + syn0Global.length )
        var syn0msg = ""
        endIndex = 0
        partRemaining = true
        var reply_syn:Array[Byte] = null
        val thread_syn0 = new Thread{
          override def run : Unit = {
            while(partRemaining){
              outTriplet = createSerializedSyn(syn0Global,endIndex,mapper,0)
              syn0msg = outTriplet._3
              partRemaining = outTriplet._2
              endIndex = outTriplet._1
              socket.send(syn0msg,ZMQ.SNDMORE)
              println("SYN0 Request sent")
            }
            syn0msg = ""
            syn0Done = true
          }
        }
        thread_syn0.start()
        while(!syn0Done){
          println("Waiting for syn0 to be sent fully!!")
          Thread.sleep(5000)
        }
        socket.send(mapper.writeValueAsString(Map("syn0Done"->"true")),0)
        val reply_syn0 = socket.recv()
        println("Reply rcvd after syn0 : " + new String(reply_syn0))
        /*Sending syn1*/
        println("Sending Syn1 request … , size : " + syn1Global.length )
        var syn1msg = ""
        endIndex = 0
        partRemaining = true
        val thread_syn1 = new Thread{
          override def run : Unit = {
            while(partRemaining){
              outTriplet = createSerializedSyn(syn0Global,endIndex,mapper,1)
              syn1msg = outTriplet._3
              partRemaining = outTriplet._2
              endIndex = outTriplet._1
              socket.send(syn1msg,ZMQ.SNDMORE)
              println("SYN1 Request sent")
            }
            syn1msg = ""
            syn1Done = true
          }
        }
        thread_syn1.start()
        while(!(vocabDone && syn0Done && syn1Done)){
          println("Waiting for serializations for vocab, syn0 and syn1 to finish!!")
          Thread.sleep(1000)
        }
        socket.send(mapper.writeValueAsString(Map("syn1Done"->"true")),0)
        val reply_syn1 = socket.recv()
        println("Reply rcvd after syn1 : " + new String(reply_syn1))

        val model = iter.foldLeft((syn0Global, syn1Global, 0, 0)) {
          case ((syn0, syn1, lastWordCount, wordCount), sentence) =>
            // Send the message
            logInfo("Sending sentence request … , size : " + sentence.length)
            socket.send(mapper.writeValueAsString(Sentence(sentence,sentence.length)),ZMQ.SNDMORE)
            println("Sentence request sent")
            (syn0, syn1, lastWordCount, wordCount)
        }

        var syn0Local : Array[Float] = null// = model._1
        var syn1Local : Array[Float] = null// = model._2

        partRemaining = true
        var reply_foldComplete : Array[Byte] = null
        var processedSynValuesJson = ""
        var syn0_rcvd : Array[Float] = Array.fill[Float](vocabSize * vectorSize)(0)

        logInfo("Sending foldComplete 0 request … ")
        socket.send(mapper.writeValueAsString(Map("foldComplete"->"Done")),0)
        println("foldComplete sent")

        var threads_list : List[Thread] = List()

        do{
          //  Get the reply.
          reply_foldComplete = socket.recv(0)
          val processedSynValuesJson0 = new String(reply_foldComplete)

          val t_syn0_part = new Thread{
            override def run : Unit = {
              //val processedSynValues_jerkson = jerkson.Json.parse[Map[String,List[Double]]](processedSynValuesJson)
              val syn0_updated = mapper.readValue(processedSynValuesJson0,classOf[Syn0Updated])
              Array.copy(syn0_updated.syn0,0,syn0_rcvd,syn0_updated.start,syn0_updated.end-syn0_updated.start+1)
              if(syn0_updated.end == syn0_updated.size-1){
                syn0Modify = syn0_updated.syn0BitVectorJson
                partRemaining = false
                println("Syn0 end reached!!! start : " + syn0_updated.start + ", end : " + syn0_updated.end)
              }
              println("Syn0 part rcvd and deserialized and copied")
            }
          }
          t_syn0_part.start()
          threads_list = threads_list :+ t_syn0_part
        }while(socket.hasReceiveMore)
        processedSynValuesJson = ""

        //threads_list = List()
        partRemaining = true
        var reply_foldComplete_1 : Array[Byte] = null
        var processedSynValuesJson1 = ""
        var syn1_rcvd : Array[Float] = Array.fill[Float](vocabSize * vectorSize)(0)
        logInfo("Sending foldComplete 1 request … ")
        //socket.send(json.JSONObject(Map("foldComplete"->"Done")).toString())
        socket.send(mapper.writeValueAsString(Map("foldComplete_1"->"Done")),0)
        println("foldComplete 1 sent")

        do{
          //  Get the reply.
          reply_foldComplete_1 = socket.recv(0)
          val processedSynValuesJson11 = new String(reply_foldComplete_1)

          val t_syn1_part = new Thread{
            override def run : Unit = {
              val syn1_updated = mapper.readValue(processedSynValuesJson11,classOf[Syn1Updated])

              Array.copy(syn1_updated.syn1,0,syn1_rcvd,syn1_updated.start,syn1_updated.end-syn1_updated.start+1)
              if(syn1_updated.end == syn1_updated.size-1){
                syn1Modify = syn1_updated.syn1BitVectorJson
                partRemaining = false
              }
            }
          }
          t_syn1_part.start()
          threads_list = threads_list :+ t_syn1_part
        }while(socket.hasReceiveMore)

        //Joining threads
        for(t <- threads_list){
          t.join()
        }

        processedSynValuesJson1 = ""

        syn0Local = syn0_rcvd
        syn1Local = syn1_rcvd
        println("Subset of received syn0Local : " + syn0Local(2) + ", " + syn0Local(3) + ", " + syn0Local(10))

        // Only output modified vectors.
        Iterator.tabulate(vocabSize) { index =>
          if (syn0Modify(index) > 0) {
            Some((index, syn0Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten ++ Iterator.tabulate(vocabSize) { index =>
          if (syn1Modify(index) > 0) {
            Some((index + vocabSize, syn1Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten
      }
      println("Partial syn values computed, Calculating synAggregate!")
      val synAgg = partial.reduceByKey { case (v1, v2) =>
        blas.saxpy(vectorSize, 1.0f, v2, 1, v1, 1)
        v1
      }.collect()
      println("ReduceByKey step completed! Proceeding to merging of syn values using bit vectors")
      var i = 0
      while (i < synAgg.length) {
        val index = synAgg(i)._1
        if (index < vocabSize) {
          Array.copy(synAgg(i)._2, 0, syn0Global, index * vectorSize, vectorSize)
        } else {
          Array.copy(synAgg(i)._2, 0, syn1Global, (index - vocabSize) * vectorSize, vectorSize)
        }
        i += 1
      }
      println("New syn global values calculated! Starting new iteration...")
    }
    newSentences.unpersist()

    val word2VecMap = mutable.HashMap.empty[String, Array[Float]]
    var i = 0
    while (i < vocabSize) {
      val word = bcVocab.value(i).word
      val vector = new Array[Float](vectorSize)
      Array.copy(syn0Global, i * vectorSize, vector, 0, vectorSize)
      word2VecMap += word -> vector
      i += 1
    }

    new Word2VecModel(word2VecMap.toMap)
  }

  /**
   * Computes the vector representation of each word in vocabulary.
   * Logic is similar to fit function above, but uses file i/o instead of serialization for communicating with w2v server
   * @param dataset an RDD of words
   * @return a Word2VecModel
   */
  def fit2[S <: Iterable[String]](dataset: RDD[S]): Word2VecModel = {

    val words = dataset.flatMap(x => x)
    learnVocab(words)
    val sc = dataset.context

    val bcVocab = sc.broadcast(vocab)
    val bcVocabHash = sc.broadcast(vocabHash)

    val sentences: RDD[Array[Int]] = words.mapPartitions { iter =>
      new Iterator[Array[Int]] {
        def hasNext: Boolean = iter.hasNext

        def next(): Array[Int] = {
          val sentence = ArrayBuilder.make[Int]
          var sentenceLength = 0
          while (iter.hasNext && sentenceLength < MAX_SENTENCE_LENGTH) {
            val word = bcVocabHash.value.get(iter.next())
            word match {
              case Some(w) =>
                sentence += w
                sentenceLength += 1
              case None =>
            }
          }
          sentence.result()
        }
      }
    }

    val newSentences = sentences.repartition(numPartitions).cache()
    println("Number of sentences to send : " + newSentences.count())
    val initRandom = new XORShiftRandom(seed)

    if (vocabSize.toLong * vectorSize * 8 >= Int.MaxValue) {
      throw new RuntimeException("Please increase minCount or decrease vectorSize in Word2Vec" +
        " to avoid an OOM. You are highly recommended to make your vocabSize*vectorSize, " +
        "which is " + vocabSize + "*" + vectorSize + " for now, less than `Int.MaxValue/8`.")
    }

    val syn0Global =
      Array.fill[Float](vocabSize * vectorSize)((initRandom.nextFloat() - 0.5f) / vectorSize)
    val syn1Global = new Array[Float](vocabSize * vectorSize)
    var alpha = learningRate

    var partRemaining = true
    var endIndex = 0
    var synMsg = ""
    var outTriplet = (endIndex,partRemaining,synMsg)

    for (k <- 1 to numIterations) {
      val partial = newSentences.mapPartitionsWithIndex { case (idx, iter) =>
        val random = new XORShiftRandom(seed ^ ((idx + 1) << 16) ^ ((-k - 1) << 8))
        var syn0Modify = new Array[Int](vocabSize)
        var syn1Modify = new Array[Int](vocabSize)
        @transient val context = ZMQ.context(1)
        @transient val socket = context.socket(ZMQ.REQ)
        val mapper = new ObjectMapper()
        mapper.registerModule(DefaultScalaModule)
        var vocabDone = false
        var syn0Done = false
        var syn1Done = false

        println("Connecting to W2V GPU server…")
        socket.connect("tcp://localhost:5556")

        /*Sending vocab. Only during the first iteration as it can be reused in later iterations*/
        if(k==1){
          logInfo("Sending vocab request … " )
          val vocab_filename = FILE_IO_PATH + "/vocab"

          val thread_vocab = new Thread {
            override def run: Unit = {
              //Writing vocab cn values to vocab_filename
              printToFile(new File(vocab_filename)) { p =>
                vocab.foreach(x=> p.println(x.cn))
              }
              socket.send(mapper.writeValueAsString(Vocab_fileIO(vocab_filename,vocab.length,k,trainWordsCount,numPartitions)),ZMQ.SNDMORE)
              println("Vocab Request sent")
              vocabDone = true
            }
          }
          thread_vocab.start()

        }
        else{
          logInfo("Sending iter_num info alone … " )
          socket.send(mapper.writeValueAsString(Map("iter_num"->k,"trainWordsCount"->trainWordsCount,"numPartitions"->numPartitions)),ZMQ.SNDMORE)
          println("iter_num info sent")
        }

        /*Sending syn0*/
        logInfo("Sending Syn0 request … , size : " + syn0Global.length )
        val syn0_filename = FILE_IO_PATH + "/syn0"

        val thread_syn0 = new Thread {
          override def run : Unit = {
            //Writing syn0 values to syn0_filename
            printToFile(new File(syn0_filename)) { p =>
              syn0Global.foreach(p.println)
            }
            socket.send(mapper.writeValueAsString(Syn0_fileIO(syn0_filename,syn0Global.length)),ZMQ.SNDMORE)
            println("SYN0 Request sent")
            syn0Done = true
          }
        }
        thread_syn0.start()

        /*Sending syn1*/
        logInfo("Sending Syn1 request … , size : " + syn1Global.length )
        val syn1_filename = FILE_IO_PATH + "/syn1"

        val thread_syn1 = new Thread{
          override def run : Unit = {
            printToFile(new File(syn1_filename)) { p =>
              syn1Global.foreach(p.println)
            }
            socket.send(mapper.writeValueAsString(Syn1_fileIO(syn1_filename,syn1Global.length)),ZMQ.SNDMORE)
            println("SYN1 Request sent")
            syn1Done = true
          }
        }
        thread_syn1.start()

        while(!(vocabDone && syn0Done && syn1Done)){
          println("Waiting for file IO to complete")
          Thread.sleep(1000)
        }

        val model = iter.foldLeft((syn0Global, syn1Global, 0, 0)) {
          case ((syn0, syn1, lastWordCount, wordCount), sentence) =>
            // Send the message
            logInfo("Sending sentence request … , size : " + sentence.length)
            socket.send(mapper.writeValueAsString(Sentence(sentence,sentence.length)),ZMQ.SNDMORE)
            println("Sentence request sent")
            (syn0, syn1, lastWordCount, wordCount)
        }

        var syn0Local : Array[Float] = null// = model._1
        var syn1Local : Array[Float] = null// = model._2

        var reply_foldComplete : Array[Byte] = null
        var processedSynValuesJson = ""
        var syn0_rcvd : Array[Float] = Array.fill[Float](vocabSize * vectorSize)(0)

        logInfo("Sending Syn 0 update request … ")
        val s0up = mapper.writeValueAsString(Map("syn0Update"->"Done","placeholder1"->"dummy","placeholder2"->"dummy2"))
        println("s0UP : " + s0up)
        socket.send(s0up,0)
        println("Syn0 Update request sent")

        //Get the reply
        reply_foldComplete = socket.recv(0)
        processedSynValuesJson = new String(reply_foldComplete)
        val syn0_updated = mapper.readValue(processedSynValuesJson,classOf[Syn0Updated_fileIO])
        println("ProcessedSynValues received! After parsing")
        //Reading from syn0 file into syn0_rcvd
        var index0 = 0
        Source.fromFile(syn0_updated.syn0).getLines().foreach(x=>
        {
          syn0_rcvd(index0) = x.toFloat
          index0 = index0 + 1
        }
        )
        syn0Modify = syn0_updated.syn0BitVectorJson

        processedSynValuesJson = ""

        var reply_foldComplete_1 : Array[Byte] = null
        var processedSynValuesJson1 = ""
        var syn1_rcvd : Array[Float] = Array.fill[Float](vocabSize * vectorSize)(0)
        logInfo("Sending Syn 1 update request … ")
        socket.send(mapper.writeValueAsString(Map("syn1Update"->"Done","placeholder1"->"dummy","placeholder2"->"dummy2")))
        println("Syn 1 update request sent")

        //  Get the reply.
        reply_foldComplete_1 = socket.recv(0)
        processedSynValuesJson1 = new String(reply_foldComplete_1)
        val syn1_updated = mapper.readValue(processedSynValuesJson1,classOf[Syn1Updated_fileIO])
        println("ProcessedSynValues received! After parsing")
        //Reading syn1 from file into syn1_rcvd
        var index1 = 0
        Source.fromFile(syn1_updated.syn1).getLines().foreach(x=>
        {
          syn1_rcvd(index1) = x.toFloat
          index1 = index1 + 1
        }
        )
        syn1Modify = syn1_updated.syn1BitVectorJson

        processedSynValuesJson1 = ""

        syn0Local = syn0_rcvd
        syn1Local = syn1_rcvd
        println("Subset of received syn0Local : " + syn0Local(2) + ", " + syn0Local(3) + ", " + syn0Local(10))

        // Only output modified vectors.
        Iterator.tabulate(vocabSize) { index =>
          if (syn0Modify(index) > 0) {
            Some((index, syn0Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten ++ Iterator.tabulate(vocabSize) { index =>
          if (syn1Modify(index) > 0) {
            Some((index + vocabSize, syn1Local.slice(index * vectorSize, (index + 1) * vectorSize)))
          } else {
            None
          }
        }.flatten
      }
      val synAgg = partial.reduceByKey { case (v1, v2) =>
        blas.saxpy(vectorSize, 1.0f, v2, 1, v1, 1)
        v1
      }.collect()
      var i = 0
      while (i < synAgg.length) {
        val index = synAgg(i)._1
        if (index < vocabSize) {
          Array.copy(synAgg(i)._2, 0, syn0Global, index * vectorSize, vectorSize)
        } else {
          Array.copy(synAgg(i)._2, 0, syn1Global, (index - vocabSize) * vectorSize, vectorSize)
        }
        i += 1
      }
      println("New syn global values calculated! Starting new iteration...")
    }
    newSentences.unpersist()

    val word2VecMap = mutable.HashMap.empty[String, Array[Float]]
    var i = 0
    while (i < vocabSize) {
      val word = bcVocab.value(i).word
      val vector = new Array[Float](vectorSize)
      Array.copy(syn0Global, i * vectorSize, vector, 0, vectorSize)
      word2VecMap += word -> vector
      i += 1
    }

    new Word2VecModel(word2VecMap.toMap)
  }

  /**
   * Computes the vector representation of each word in vocabulary (Java version).
   * @param dataset a JavaRDD of words
   * @return a Word2VecModel
   */
  def fit[S <: JavaIterable[String]](dataset: JavaRDD[S]): Word2VecModel = {
    fit(dataset.rdd.map(_.asScala))
  }
}

object Word2Vec_demo2 extends Logging{
  def main(args: Array[String]) {
    println("Starting the demo...")
    val conf = new SparkConf().setAppName("W2V Demo")
    val sc:SparkContext = new SparkContext(conf)

    val file_path = args(0)
    val input = sc.textFile(file_path).map(line => line.split(" ").toSeq)

    val word2vec = new Word2Vec2()
    val num_partitions = Integer.parseInt(args(1))
    val sen_size = Integer.parseInt(args(2))
    val num_iterations = Integer.parseInt(args(3))
    val vector_size = Integer.parseInt(args(4))
    val syn_size = Integer.parseInt(args(5))
    val file_io_path = args(6)
    val input_word = args(7)
    word2vec.setNumPartitions(num_partitions)
    word2vec.setNumIterations(num_iterations)
    word2vec.setMaxSentenceLength(sen_size)
    word2vec.setVectorSize(vector_size)
    word2vec.setMaxSynSizeToSend(syn_size)
    word2vec.setFILEIOPATH(file_io_path)

    var model : Word2VecModel = null
    if(syn_size>0) {
      model = word2vec.fit(input)
    }
    else {
      //Using file i/o for communicating vocab,syn0 and syn1 to w2v server
      model = word2vec.fit2(input)
    }

    println("Finding top 40 closest words for input = " + input_word)
    val synonyms = model.findSynonyms(input_word, 40)

    for((synonym, cosineSimilarity) <- synonyms) {
      println(s"$synonym $cosineSimilarity")
    }
    val modelPath = args(8)
    if(!modelPath.equals("noSave")){
      model.save(sc, modelPath)
    }

    sc.stop()

  }
}

object Word2Vec_model_demo extends Logging{
  def main(args : Array[String]): Unit ={
    val conf = new SparkConf().setAppName("W2V Model Demo")
    val sc:SparkContext = new SparkContext(conf)
    println("Fetching Model for W2V training...")
    val modelPath = args(0)
    val inputWord = args(1)
    val model = Word2VecModel.load(sc, modelPath)
    val synonyms = model.findSynonyms(inputWord,40)
    println("Following are the top 40 words found similar to " + inputWord)
    for((synonym, cosineSimilarity) <- synonyms) {
      println(s"$synonym $cosineSimilarity")
    }
    sc.stop()
  }
}


object zmq_server{
  import scala.io.Source
  import java.io.File
  import java.io.PrintWriter
  import java.io._

  val MAX_SYN_SIZE_TO_SEND = 6

  private def createSerializedSyn(syn : Array[Int], index : Int, mapper: ObjectMapper) : (Int,Boolean,String) = {
    var isPartRemaining = true
    val size = syn.length
    val max_index = index + MAX_SYN_SIZE_TO_SEND
    var endIndex = max_index
    if(max_index+1>=size){
      isPartRemaining = false
      endIndex = size
    }
    val subsetSyn = syn.slice(index,endIndex)
    val serializedString = mapper.writeValueAsString(subsetSyn)
    (endIndex,isPartRemaining,serializedString)
  }

  def ArrayToString(arr : Array[Double]): String ={
    var out = arr(0).toString
    arr.foreach(x => out = out + " " + x.toString)
    out
  }

  def printToFile(f: java.io.File)(op: java.io.PrintWriter => Unit) {
    val p = new java.io.PrintWriter(f)
    try { op(p) } finally { p.close() }
  }

  def main(args : Array[String]): Unit ={
    val size = 87000000
    val arr1 = Array.fill(size)(1.234)
    val start_time = System.nanoTime()
    val context = ZMQ.context(1)
    val socket = context.socket(ZMQ.REQ)
    println("Connecting to W2V GPU server…")
    socket.connect("tcp://localhost:5556")
    /*Thread start*/
    // scala thread example
    for (i <- 1 to 10) {
      val thread = new Thread {
        override def run: Unit = {

          println(i*50)
          var b = 0
          for(j<-1 to 100000000){
            b = b + j
          }
          b = b + i
          println("here's b, for i = " + i + ", b = " + b)
          socket.send(b.toString,0)
          val r = new String(socket.recv(0))
          println("Message rcvd by thread " + i + ", " + r)
        }
      }
      thread.start()
      Thread.sleep(50)
    }

    /*Thread ends*/



    for(i<- 1 to 1){
      val k = size+i
      socket.send(k.toString,ZMQ.NOBLOCK)
    }
    var moredata = ""
    
    do{
      moredata = new String(socket.recv(0))
      println("New multipart msg : " + moredata)
    }while(socket.hasReceiveMore)
  }
}
/**
 * :: Experimental ::
 * Word2Vec model
 */
@Experimental
class Word2VecModel private[mllib] (
    model: Map[String, Array[Float]]) extends Serializable with Saveable {

  // wordList: Ordered list of words obtained from model.
  private val wordList: Array[String] = model.keys.toArray

  // wordIndex: Maps each word to an index, which can retrieve the corresponding
  //            vector from wordVectors (see below).
  private val wordIndex: Map[String, Int] = wordList.zip(0 until model.size).toMap

  // vectorSize: Dimension of each word's vector.
  private val vectorSize = model.head._2.size
  private val numWords = wordIndex.size

  // wordVectors: Array of length numWords * vectorSize, vector corresponding to the word
  //              mapped with index i can be retrieved by the slice
  //              (ind * vectorSize, ind * vectorSize + vectorSize)
  // wordVecNorms: Array of length numWords, each value being the Euclidean norm
  //               of the wordVector.
  private val (wordVectors: Array[Float], wordVecNorms: Array[Double]) = {
    val wordVectors = new Array[Float](vectorSize * numWords)
    val wordVecNorms = new Array[Double](numWords)
    var i = 0
    while (i < numWords) {
      val vec = model.get(wordList(i)).get
      Array.copy(vec, 0, wordVectors, i * vectorSize, vectorSize)
      wordVecNorms(i) = blas.snrm2(vectorSize, vec, 1)
      i += 1
    }
    (wordVectors, wordVecNorms)
  }

  private def cosineSimilarity(v1: Array[Float], v2: Array[Float]): Double = {
    require(v1.length == v2.length, "Vectors should have the same length")
    val n = v1.length
    val norm1 = blas.snrm2(n, v1, 1)
    val norm2 = blas.snrm2(n, v2, 1)
    if (norm1 == 0 || norm2 == 0) return 0.0
    blas.sdot(n, v1, 1, v2, 1) / norm1 / norm2
  }

  override protected def formatVersion = "1.0"

  def save(sc: SparkContext, path: String): Unit = {
    Word2VecModel.SaveLoadV1_0.save(sc, path, getVectors)
  }

  /**
   * Transforms a word to its vector representation
   * @param word a word
   * @return vector representation of word
   */
  def transform(word: String): Vector = {
    model.get(word) match {
      case Some(vec) =>
        Vectors.dense(vec.map(_.toDouble))
      case None =>
        throw new IllegalStateException(s"$word not in vocabulary")
    }
  }

  /**
   * Find synonyms of a word
   * @param word a word
   * @param num number of synonyms to find
   * @return array of (word, cosineSimilarity)
   */
  def findSynonyms(word: String, num: Int): Array[(String, Double)] = {
    val vector = transform(word)
    findSynonyms(vector, num)
  }

  /**
   * Find synonyms of the vector representation of a word
   * @param vector vector representation of a word
   * @param num number of synonyms to find
   * @return array of (word, cosineSimilarity)
   */
  def findSynonyms(vector: Vector, num: Int): Array[(String, Double)] = {
    require(num > 0, "Number of similar words should > 0")

    val fVector = vector.toArray.map(_.toFloat)
    val cosineVec = Array.fill[Float](numWords)(0)
    val alpha: Float = 1
    val beta: Float = 0

    blas.sgemv(
      "T", vectorSize, numWords, alpha, wordVectors, vectorSize, fVector, 1, beta, cosineVec, 1)

    // Need not divide with the norm of the given vector since it is constant.
    val updatedCosines = new Array[Double](numWords)
    var ind = 0
    while (ind < numWords) {
      updatedCosines(ind) = cosineVec(ind) / wordVecNorms(ind)
      ind += 1
    }
    wordList.zip(updatedCosines)
      .toSeq
      .sortBy(- _._2)
      .take(num + 1)
      .tail
      .toArray
  }

  /**
   * Returns a map of words to their vector representations.
   */
  def getVectors: Map[String, Array[Float]] = {
    wordIndex.map { case (word, ind) =>
      (word, wordVectors.slice(vectorSize * ind, vectorSize * ind + vectorSize))
    }
  }
}

@Experimental
object Word2VecModel extends Loader[Word2VecModel] {

  private object SaveLoadV1_0 {

    val formatVersionV1_0 = "1.0"

    val classNameV1_0 = "org.apache.spark.mllib.feature.Word2VecModel"

    case class Data(word: String, vector: Array[Float])

    def load(sc: SparkContext, path: String): Word2VecModel = {
      val dataPath = Loader.dataPath(path)
      val sqlContext = new SQLContext(sc)
      val dataFrame = sqlContext.read.parquet(dataPath)

      val dataArray = dataFrame.select("word", "vector").collect()

      // Check schema explicitly since erasure makes it hard to use match-case for checking.
      Loader.checkSchema[Data](dataFrame.schema)

      val word2VecMap = dataArray.map(i => (i.getString(0), i.getSeq[Float](1).toArray)).toMap
      new Word2VecModel(word2VecMap)
    }

    def save(sc: SparkContext, path: String, model: Map[String, Array[Float]]): Unit = {

      val sqlContext = new SQLContext(sc)
      import sqlContext.implicits._

      val vectorSize = model.values.head.size
      val numWords = model.size
      val metadata = compact(render
        (("class" -> classNameV1_0) ~ ("version" -> formatVersionV1_0) ~
         ("vectorSize" -> vectorSize) ~ ("numWords" -> numWords)))
      sc.parallelize(Seq(metadata), 1).saveAsTextFile(Loader.metadataPath(path))

      val dataArray = model.toSeq.map { case (w, v) => Data(w, v) }
      sc.parallelize(dataArray.toSeq, 1).toDF().write.parquet(Loader.dataPath(path))
    }
  }

  override def load(sc: SparkContext, path: String): Word2VecModel = {

    val (loadedClassName, loadedVersion, metadata) = Loader.loadMetadata(sc, path)
    implicit val formats = DefaultFormats
    val expectedVectorSize = (metadata \ "vectorSize").extract[Int]
    val expectedNumWords = (metadata \ "numWords").extract[Int]
    val classNameV1_0 = SaveLoadV1_0.classNameV1_0
    (loadedClassName, loadedVersion) match {
      case (classNameV1_0, "1.0") =>
        val model = SaveLoadV1_0.load(sc, path)
        val vectorSize = model.getVectors.values.head.size
        val numWords = model.getVectors.size
        require(expectedVectorSize == vectorSize,
          s"Word2VecModel requires each word to be mapped to a vector of size " +
          s"$expectedVectorSize, got vector of size $vectorSize")
        require(expectedNumWords == numWords,
          s"Word2VecModel requires $expectedNumWords words, but got $numWords")
        model
      case _ => throw new Exception(
        s"Word2VecModel.load did not recognize model with (className, format version):" +
        s"($loadedClassName, $loadedVersion).  Supported:\n" +
        s"  ($classNameV1_0, 1.0)")
    }
  }


}
