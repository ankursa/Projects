# w2v_spark_gpu
Spark + GPU based distributed computation version for w2v algorithm

Command for running spark client : 
time spark-submit --verbose --driver-memory 2G --driver-cores 1 --executor-memory 2G --class org.apache.spark.mllib.feature.Word2Vec_demo2 --driver-java-options -Djava.library.path=/usr/local/lib --master local ./spark-mllib_2.10.jar <hdfs-location-of-training-file>/tmp/text8 <num-partitions>1 <sen_large_size>8192000 <num-iterations>1 <hidden-layer-size>128 <syn_size for ser/de mode, 0 for file i/o mode>12800000 <dir for file i/o, only applicable for file i/o mode>/tmp/w2v <input word>science <location for saving model, noSave to disable model saving>noSave

For running on yarn, on spl queue, the following command is usable: 
time spark-submit --verbose --driver-memory 2G --driver-cores 1 --executor-memory 2G --class org.apache.spark.mllib.feature.Word2Vec_demo2 --driver-java-options -Djava.library.path=/usr/local/lib --master yarn --deploy-mode cluster --queue spl ./spark-mllib_2.10.jar <hdfs-location-of-training-file>/tmp/text8 <num-partitions>1 <sen_large_size>8192000 <num-iterations>1 <hidden-layer-size>128 <syn_size for ser/de mode, 0 for file i/o mode>12800000 <dir for file i/o, only applicable for file i/o mode>/tmp/w2v <input word>science <location for saving model, noSave to disable model saving>noSave

Command for running w2v server:
./word2vec tcp://*:5556 <syn_size>20000000 -cbow 1 -size 416 -window 4 -negative 25 -hs 0 -iter 2


