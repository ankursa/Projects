//  Copyright 2013 Google Inc. All Rights Reserved.
//
//  Licensed under the Apache License, Version 2.0 (the "License");
//  you may not use this file except in compliance with the License.
//  You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
//  Unless required by applicable law or agreed to in writing, software
//  distributed under the License is distributed on an "AS IS" BASIS,
//  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//  See the License for the specific language governing permissions and
//  limitations under the License.

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <unistd.h>
#include <string.h>
//#include <malloc.h>
#include <math.h>
#include <pthread.h>
#include <vector>
#include "cbow-bitvector.h"
#include <zmq.h>
//#include "zmq.hpp"
#include <assert.h>
#include <rapidjson/document.h>
#include <rapidjson/writer.h>
#include <rapidjson/stringbuffer.h>

using namespace rapidjson;

std::vector<GPUTrainer> gpuTrainers;

int initGPU = 1;
int binary = 0, cbow = 1, debug_mode = 2, window = 5, min_count = 5,
    num_threads = 12, min_reduce = 1;

int vocab_max_size = 1000, vocab_size = 0, layer1_size = 100,
    layer1_size_aligned;

int iter_num,num_partitions,trainWordsCount = 0;
unsigned int train_words = 0, iter = 5;
int file_size = 0, classes = 0;
unsigned int word_count_actual = 0;
real alpha = 0.025, starting_alpha, sample = 1e-3;
real *syn0;
real *syn1neg;

clock_t start;

int benchmark = 0;
int hs = 0, negative = 5;
int table_size = 1e8;
int *table;

int* sen_large;

MyBitMap g_syn0_bitmap;
MyBitMap g_syn1neg_bitmap;

//Threads for parallel deserialization
int num_threads_deser = 100;
int counter_th_deser = 0;
int num_threads_ser = 100;
int counter_th_ser = 0;
pthread_t *pt_deser = (pthread_t *) malloc(num_threads_deser* sizeof(pthread_t));
	
//Threads for parallel serialization
pthread_t *pt_ser = (pthread_t *) malloc(num_threads_ser * sizeof(pthread_t));

void *TrainModelThread(void *id) {
	int word, sentence_length = 0;
	unsigned int word_count = 0, last_word_count = 0;
	unsigned int next_random = (long) id;
	int fid = (int) (long) id;
	int sentence_num;
	clock_t now;
	int * sen = gpuTrainers[fid].getSentencePtr();
	real * alpha_ptr = (float *) sen + MAX_SENTENCE_NUM * MAX_SENTENCE_LENGTH;

	unsigned int maxPartialCount =(unsigned int)(  (gpuTrainers[fid].getEnd() - gpuTrainers[fid].getStart()) + 1);
	int offset = gpuTrainers[fid].getStart();
	printf("Printing maxPartialCount : %d \n",maxPartialCount);
	sentence_length = 0;
	sentence_num = 0;
	//int count_kernels = 0;
	while (1) {
		if (word_count - last_word_count > 10000) {
			word_count_actual += word_count - last_word_count;
			last_word_count = word_count;
			if ((debug_mode > 1)) {
				now = clock();
				printf(
						"%cAlpha: %f  Progress: %.2f%%  Words/thread/sec: %.2fk  ",
						13, alpha,
						word_count_actual / (real) (iter * train_words + 1)
						* 100,
						word_count_actual
						/ ((real) (now - start + 1)
							/ (real) CLOCKS_PER_SEC * 1000));
				fflush(stdout);
			}
			alpha = starting_alpha
				* (1 -((num_partitions* word_count_actual) / (real) (iter_num*iter * trainWordsCount + 1)));
			if (alpha < starting_alpha * 0.0001)
				alpha = starting_alpha * 0.0001;
			//printf("Printing starting_alpha : %f,num_partitions : %d, word_count_actual : %d, iter_num : %d, iter : %d, trainWordsCount : %d and alpha : %f\n",starting_alpha,num_partitions,word_count_actual,iter_num,iter,trainWordsCount,alpha);			
		}

		while (1) {

			if(word_count >= maxPartialCount)
			{	
				printf("word count = %d, maxCount = %d\n", word_count, maxPartialCount);
				break;
			}

			word = sen_large[word_count + offset];
			word_count++;
			//if (word_count)
			//	break;
			if (word == -1)
				continue;
			//word_count++;
			if (word == 0){
				//printf("word == 0\n");
				continue;
			}

			if(word >= vocab_size)
			{
				printf("word=%d , word count =%d, offset = %d\n", word, word_count,offset);

			}	
			sen[sentence_num * MAX_SENTENCE_LENGTH + sentence_length] = word;
			if (gpuTrainers[fid].bitmap.getBit(word) == 0)
			{
				gpuTrainers[fid].bitmap.setBit(word);
			}
			sentence_length++;
			if (sentence_length >= MAX_SENTENCE_LENGTH) {
				alpha_ptr[sentence_num] = alpha;
				sentence_num++;
				sentence_length = 0;
				if (sentence_num >= MAX_SENTENCE_NUM)
					break;
			}

			if(word_count >= maxPartialCount)
				break;
		}

		// Do GPU training here
		printf("calling train gpu\n");
		gpuTrainers[fid].trainGPU(sentence_num);
		printf("returned from gpu \n");
		//////////////////////
		sentence_num = 0;
		sentence_length = 0;

		if  (word_count >= maxPartialCount) {
			word_count_actual += word_count - last_word_count;
			break;
		}

	}

	gpuTrainers[fid].getResultData();

	pthread_exit(NULL);
}

void TrainModel(int total_num_words ) {
	printf("Printing total_num_words : %d\n",total_num_words);
	train_words = total_num_words;
	long a, b;
	//alpha = 0.05;
	starting_alpha = alpha;
	if(initGPU == 1)
	{
		initializeGPU();
		for(int i=0; i < num_threads; i++)
		{

			gpuTrainers[i].bitmap.setSize(vocab_size);

			gpuTrainers[i].syn1neg_bitmap.setSize(vocab_size);


		}	

		initGPU = 0;
	}

	setWorkingRanges(total_num_words);

	num_threads = gpuTrainers.size();

	for(int i=0; i < num_threads; i++)
	{

		gpuTrainers[i].bitmap.initBits(vocab_size);

		gpuTrainers[i].syn1neg_bitmap.initBits(vocab_size);


	}
	int fid = 0;

	pthread_t *pt = (pthread_t *) malloc(num_threads * sizeof(pthread_t));
	start = clock();
	printf("num_threads = %d    iter = %d\n\n", num_threads, iter);
	// loop iteration
	for (unsigned int local_iter = 0; local_iter < iter; local_iter++){
		// distribute global syn0 to all GPUTrainer's syn0
		if (local_iter == 0){
			for (int i = 0; i < num_threads; i++)
			{
				gpuTrainers[i].updateSyn0(syn0);
				gpuTrainers[i].updateSyn1Neg(syn1neg);
			}
		}
		// launch threads
		for (a = 0; a < num_threads; a++)
			pthread_create(&pt[a], NULL, TrainModelThread, (void *) a);
		for (a = 0; a < num_threads; a++)
			pthread_join(pt[a], NULL);

		// update global syn0 from all GPUTrainer's syn0
		if ( local_iter == iter -1){
			printf("---AVERAGING------\n");
			for (a = 0; a < vocab_size ; a++)
				for (b = 0; b < layer1_size; b++)
				{
					float value = 0;
					int c = 0;
					int index = a * layer1_size_aligned + b;
					for (int i = 0 ; i < num_threads; i++)
					{
						if (gpuTrainers[i].bitmap.getBit(a)) {
							g_syn0_bitmap.setBit(a);
							value += gpuTrainers[i].getSyn0()[index];
							c++;
						}
					}
					if(c > 0)
						syn0[index] = value / c;

					// update global syn1neg

					value = 0;
					c = 0;
					index = a * layer1_size_aligned + b;
					for (int i = 0 ; i < num_threads; i++)
					{
						if (gpuTrainers[i].getSyn1Neg()[index] != syn1neg[index])
						{
							g_syn1neg_bitmap.setBit(a);
							value += gpuTrainers[i].getSyn1Neg()[index];
							c++;
						}

					}
					if(c > 0)
						syn1neg[index] = value/c;

				}

		}

	}


}

int ArgPos(char *str, int argc, char **argv) {
	int a;
	for (a = 1; a < argc; a++)
		if (!strcmp(str, argv[a])) {
			if (a == argc - 1) {
				printf("Argument missing for %s\n", str);
				exit(1);
			}
			return a;
		}
	return -1;
}

void InitUnigramTable(rapidjson::Value& vocabJson, int vocab_size_rcvd) {
	int a, i;
	double train_words_pow = 0;
	double d1, power = 0.75;
	vocab_size = vocab_size_rcvd;
	table = (int *)malloc(table_size * sizeof(int));
	for (a = 0; a < vocab_size; a++) train_words_pow += pow(vocabJson[(a)]["cn"].GetDouble(), power);
	i = 0;
	//d1 = pow(vocab[i].cn, power) / train_words_pow;
	d1 = pow(vocabJson[i]["cn"].GetDouble(), power) / train_words_pow;
	for (a = 0; a < table_size; a++) {
		table[a] = i;
		if (a / (double)table_size > d1) {
			i++;
			//d1 += pow(vocab[i].cn, power) / train_words_pow;
			d1 += pow(vocabJson[i]["cn"].GetDouble(), power) / train_words_pow;
		}
		if (i >= vocab_size) i = vocab_size - 1;
	}
}

void InitUnigramTableFromFile(rapidjson::Document& d) {
	assert(d["vocab"].IsString());
	const char* filename = d["vocab"].GetString();
	FILE* fp = fopen(filename,"r");
	int a, i;
	double train_words_pow = 0;
	double d1, power = 0.75;
	vocab_size = d["vocabSize"].GetInt();
	table = (int *)malloc(table_size * sizeof(int));
	float cn;
	float* vocab_cns = (float *)malloc(sizeof(float)*vocab_size);
	for (a = 0; a < vocab_size; a++){
		if(fscanf(fp,"%f",&cn)!=EOF){
			train_words_pow += pow(cn,power);
			vocab_cns[a] = cn;
		}
		else{
			printf("EOF reached before vocab_size exhausted!\n");
			break;
		}
	}
	fclose(fp);
	i = 0;
	//d1 = pow(vocab[i].cn, power) / train_words_pow;
	d1 = pow(vocab_cns[i], power) / train_words_pow;
	for (a = 0; a < table_size; a++) {
		table[a] = i;
		if (a / (double)table_size > d1) {
			i++;
			//d1 += pow(vocab[i].cn, power) / train_words_pow;
			d1 += pow(vocab_cns[i], power) / train_words_pow;
		}
		if (i >= vocab_size) i = vocab_size - 1;
	}
}


void InitSenLarge(rapidjson::Value& senLargeJson, int size) {

	sen_large = (int*)malloc(sizeof(int)*size);
	for(int a=0;a<size;a++){
		sen_large[a] = senLargeJson[a].GetInt();
		if(sen_large[a] >= vocab_size) printf("Absurd value found for word : %d\n",sen_large[a]);
	}


}

void InitSyn0(rapidjson::Document& d) {
	int start = d["start"].GetInt();
	int end = d["end"].GetInt();
	int size = d["size"].GetInt();
	int a = 0;	
	if(start==0){
		a = posix_memalign((void **)&syn0, 128, (int)vocab_size * layer1_size_aligned * sizeof(real));
	}	
	if (syn0 == NULL) {
		printf("SYN0 Memory allocation failed\n");
		exit(1);
	}
	int syn0_size = vocab_size * layer1_size_aligned;
	rapidjson::Value& syn0Json = d["syn0"];
	for(a=0;a<=end-start;a++){
		syn0[start+a] = (float)syn0Json[a].GetDouble();
	}
	if(end==size-1){
		g_syn0_bitmap.setSize(vocab_size);

		g_syn0_bitmap.initBits(vocab_size);
	}
}

void *InitSyn0Thread(void * Obj){
	rapidjson::Document* d = reinterpret_cast<rapidjson::Document *>(Obj);
	InitSyn0(*d);
}

void InitSyn0FromFile(rapidjson::Document& d) {
	int size = d["size"].GetInt();
	int a = 0;	
	a = posix_memalign((void **)&syn0, 128, (int)vocab_size * layer1_size_aligned * sizeof(real));
	if (syn0 == NULL) {
		printf("SYN0 Memory allocation failed\n");
		exit(1);
	}
	int syn0_size = vocab_size * layer1_size_aligned;
	FILE* fp = fopen(d["syn0"].GetString(),"r");	
	float syn0_val;
	for(a=0;a<=size;a++){
		if(fscanf(fp,"%f",&syn0_val)!=EOF){
			syn0[a] = syn0_val;
		}
		else{
			printf("EOF reached before syn0 size exhausted! a = %d, size = %d\n",a,size);
			break;
		} 
	}
	fclose(fp);
	g_syn0_bitmap.setSize(vocab_size);

	g_syn0_bitmap.initBits(vocab_size);
}


void InitSyn1(rapidjson::Document& d) {
	int start = d["start"].GetInt();
	int end = d["end"].GetInt();
	int size = d["size"].GetInt();
	int a = 0;	
	if(start==0){
		a = posix_memalign((void **)&syn1neg, 128, (int)vocab_size * layer1_size_aligned * sizeof(real));
	}
	if (syn1neg == NULL) {
		printf("SYN1 Memory allocation failed\n");
		exit(1);
	}
	int syn1_size = vocab_size * layer1_size_aligned;
	rapidjson::Value& syn1Json = d["syn1"];
	for(a=0;a<=end-size;a++){
		syn1neg[start+a] = (float)syn1Json[a].GetDouble();
	}
	if(end==size-1){
		g_syn1neg_bitmap.setSize(vocab_size);

		g_syn1neg_bitmap.initBits(vocab_size);
	}
}

void *InitSyn1Thread(void * Obj){
	rapidjson::Document* d = reinterpret_cast<rapidjson::Document *>(Obj);
	InitSyn1(*d);
}

void InitSyn1FromFile(rapidjson::Document& d) {
	int size = d["size"].GetInt();
	int a = 0;	
	a = posix_memalign((void **)&syn1neg, 128, (int)vocab_size * layer1_size_aligned * sizeof(real));
	if (syn1neg == NULL) {
		printf("SYN1 Memory allocation failed\n");
		exit(1);
	}
	int syn1_size = vocab_size * layer1_size_aligned;
	FILE* fp = fopen(d["syn1"].GetString(),"r");	
	float syn1_val;
	for(a=0;a<=size;a++){
		if(fscanf(fp,"%f",&syn1_val)!=EOF){
			syn1neg[a] = syn1_val;
		}
		else{
			printf("EOF reached before syn1neg size exhausted!\n");
			break;
		} 
	}
	fclose(fp);
	g_syn1neg_bitmap.setSize(vocab_size);

	g_syn1neg_bitmap.initBits(vocab_size);
}

int main(int argc, char **argv) {
	int i;
	if (argc == 1) {
		printf("WORD VECTOR estimation toolkit v 0.1c\n\n");
		printf("Options:\n");
		printf("Parameters for training:\n");
		printf("\t-train <file>\n");
		printf("\t\tUse text data from <file> to train the model\n");
		printf("\t-output <file>\n");
		printf(
				"\t\tUse <file> to save the resulting word vectors / word clusters\n");
		printf("\t-size <int>\n");
		printf("\t\tSet size of word vectors; default is 100\n");
		printf("\t-window <int>\n");
		printf("\t\tSet max skip length between words; default is 5\n");
		printf("\t-sample <float>\n");
		printf(
				"\t\tSet threshold for occurrence of words. Those that appear with higher frequency in the training data\n");
		printf(
				"\t\twill be randomly down-sampled; default is 1e-3, useful range is (0, 1e-5)\n");
		printf("\t-hs <int>\n");
		printf("\t\tUse Hierarchical Softmax; default is 0 (not used)\n");
		printf("\t-negative <int>\n");
		printf(
				"\t\tNumber of negative examples; default is 5, common values are 3 - 10 (0 = not used)\n");
		//		printf("\t-threads <int>\n");
		//		printf("\t\tUse <int> threads (default 12)\n");
		printf("\t-iter <int>\n");
		printf("\t\tRun more training iterations (default 5)\n");
		printf("\t-min-count <int>\n");
		printf(
				"\t\tThis will discard words that appear less than <int> times; default is 5\n");
		printf("\t-alpha <float>\n");
		printf(
				"\t\tSet the starting learning rate; default is 0.025 for skip-gram and 0.05 for CBOW\n");
		printf("\t-classes <int>\n");
		printf(
				"\t\tOutput word classes rather than word vectors; default number of classes is 0 (vectors are written)\n");
		printf("\t-debug <int>\n");
		printf(
				"\t\tSet the debug mode (default = 2 = more info during training)\n");
		printf("\t-binary <int>\n");
		printf(
				"\t\tSave the resulting vectors in binary moded; default is 0 (off)\n");
		printf("\t-save-vocab <file>\n");
		printf("\t\tThe vocabulary will be saved to <file>\n");
		printf("\t-read-vocab <file>\n");
		printf(
				"\t\tThe vocabulary will be read from <file>, not constructed from the training data\n");
		printf("\t-cbow <int>\n");
		printf(
				"\t\tUse the continuous bag of words model; default is 1 (use 0 for skip-gram model)\n");
		printf("\nExamples:\n");
		printf(
				"./word2vec -train data.txt -output vec.txt -size 200 -window 5 -sample 1e-4 -negative 5 -hs 0 -binary 0 -cbow 1 -iter 3\n\n");
		return 0;
	}
	/*output_file[0] = 0;
	  save_vocab_file[0] = 0;
	  read_vocab_file[0] = 0;*/
	if ((i = ArgPos((char *) "-size", argc, argv)) > 0) {
		layer1_size = atoi(argv[i + 1]);
		layer1_size_aligned = ((layer1_size - 1) / ALIGNMENT_FACTOR + 1)
			* ALIGNMENT_FACTOR;
	}
	/*if ((i = ArgPos((char *) "-train", argc, argv)) > 0)
	  strcpy(train_file, argv[i + 1]);
	  if ((i = ArgPos((char *) "-save-vocab", argc, argv)) > 0)
	  strcpy(save_vocab_file, argv[i + 1]);
	  if ((i = ArgPos((char *) "-read-vocab", argc, argv)) > 0)
	  strcpy(read_vocab_file, argv[i + 1]);*/
	if ((i = ArgPos((char *) "-debug", argc, argv)) > 0)
		debug_mode = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-binary", argc, argv)) > 0)
		binary = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-cbow", argc, argv)) > 0)
		cbow = atoi(argv[i + 1]);
	if (cbow)
		alpha = 0.05;
	if ((i = ArgPos((char *) "-alpha", argc, argv)) > 0)
		alpha = atof(argv[i + 1]);
	//if ((i = ArgPos((char *) "-output", argc, argv)) > 0)
	//  strcpy(output_file, argv[i + 1]);
	if ((i = ArgPos((char *) "-window", argc, argv)) > 0)
		window = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-sample", argc, argv)) > 0)
		sample = atof(argv[i + 1]);
	if ((i = ArgPos((char *) "-hs", argc, argv)) > 0)
		hs = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-negative", argc, argv)) > 0)
		negative = atoi(argv[i + 1]);
	//	if ((i = ArgPos((char *) "-threads", argc, argv)) > 0)
	//		num_threads = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-iter", argc, argv)) > 0)
		iter = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-min-count", argc, argv)) > 0)
		min_count = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-classes", argc, argv)) > 0)
		classes = atoi(argv[i + 1]);
	if ((i = ArgPos((char *) "-benchmark", argc, argv)) > 0)
		benchmark = atoi(argv[i + 1]);

	//  Socket to talk to clients
	void *zmq_context = zmq_ctx_new ();
	void *responder = zmq_socket (zmq_context, ZMQ_REP);
	int rc = zmq_bind (responder, argv[1]);
	assert (rc == 0);

	//zmq_msg_t rcvd;
	zmq_msg_t response;
	//zmq_msg_init (&rcvd);
	zmq_msg_init (&response);
	Document d;

	
	bool iteration_finished = false;	
	int syn0StartIndex=0, syn0EndIndex=0, syn1StartIndex=0, syn1EndIndex = 0;
	int max_syn_size_to_send = atoi(argv[2]);
	int iterCount = 1;
	while (1) {
		zmq_msg_init_size (&response, 6);
		memcpy ((void *) zmq_msg_data (&response), "World", 6);
		uint64_t more;
		size_t more_size = sizeof more;
		int count = 0;
		printf("\n\nLoop Iteration %d\n\n", iterCount);
		do{
			//rcvd = NULL;
			zmq_msg_t rcvd;
			rc = zmq_msg_init (&rcvd);
			assert(rc==0);
			zmq_recvmsg (responder, &rcvd, 0);
			char * rjsonMsg = (char *)zmq_msg_data(&rcvd);
			d.Parse(rjsonMsg);
			bool parsingSuccessful = d.IsObject();
			if(strstr(rjsonMsg,"syn0Update")!=NULL) printf("This is the message : %s\n\n",rjsonMsg); 
			if(strstr(rjsonMsg,"foldComplete")!=NULL) printf("This is the foldcomplete message : %s\n\n",rjsonMsg); 
			if (parsingSuccessful){
				if(d.HasMember("expTable")){/*receiving the table data*/
					const Value& expTable1 = d["expTable"];
					assert(expTable1.IsArray()); 
					printf("Table received! %d\n",expTable1[1].GetInt());	
				}	
				else if(d.HasMember("syn0")){/*receiving the syn0 data*/
					if(d["syn0"].IsString()){
						printf("Syn0 received through file : %s\n",d["syn0"]);
						InitSyn0FromFile(d);	
					}
					else if(d["syn0"].IsArray()){
						printf("Syn0 received properly. Initializing SYN0.....!!\n");
						//Initialize syn0 here
						//InitSyn0(d);
						pthread_t tid;
						rapidjson::Document * newD = (rapidjson::Document *)malloc(sizeof(rapidjson::Document));
						memcpy(newD,&d,sizeof(rapidjson::Document));
						pthread_create(&tid,NULL, InitSyn0Thread,newD);
						pt_deser[counter_th_deser] = tid;
						counter_th_deser++;
					}
					else{
						printf("Syn0 received isnt an array! \n");
						exit(0);	
					}	
				}	
				else if(d.HasMember("syn1")){/*receiving the syn1 data*/
					if(d["syn1"].IsString()){
						printf("Syn1 received through file : %s\n",d["syn1"]);
						InitSyn1FromFile(d);	
					}
					else if(d["syn1"].IsArray()){
						printf("syn1 received!\n");	
						//Initialize syn1 here
						//InitSyn1(d);
						pthread_t tid;
						rapidjson::Document * newD = (rapidjson::Document *)malloc(sizeof(rapidjson::Document));
						memcpy(newD,&d,sizeof(rapidjson::Document));
						pthread_create(&tid,NULL, InitSyn1Thread,newD);
						pt_deser[counter_th_deser] = tid;
						counter_th_deser++;
					}
					else{
						printf("Syn1 received isnt an array! \n");
						exit(0);
					}	
				}
				else if(d.HasMember("sentence")){/*receiving the sentence data*/
					if(counter_th_deser!=0){
						printf("Parallel no of threads for deser of s0 and s1 = %d\n",counter_th_deser);
						for(int c=0;c<counter_th_deser;c++){
							pthread_join(pt_deser[c],NULL);
						}
						counter_th_deser = 0;	
					}
					if(d["sentence"].IsArray()){
						int sen_size = d["sen_length"].GetInt();
						printf("sen_large received! size : %d\n", sen_size);
						//initialize sen_large here
						InitSenLarge(d["sentence"],sen_size);
						TrainModel(sen_size);
						free(sen_large);
					}
					else{
						printf("Sentence received isnt an array! \n");
					}
				}	
				else if(d.HasMember("vocab")){/*receiving the vocab data for intialization of table*/
					if(d["vocab"].IsString()){
						printf("Vocab received through file : %s\n",d["vocab"].GetString());
						InitUnigramTableFromFile(d);
					}
					else if(d["vocab"].IsArray()){
						printf("Vocab received properly. Initializing table for negative sampling.....!!\n");
						//Initialize table here
						InitUnigramTable(d["vocab"], d["vocabSize"].GetInt());
						trainWordsCount = d["trainWordsCount"].GetInt();
						num_partitions = d["numPartitions"].GetInt();
						iter_num = d["iter_num"].GetInt();
					}
					else{
						printf("Vocab received isnt an array! \n");
						exit(0);	
					}	
				}
				else if(d.HasMember("iter_num")){/*receiving the iter_num of spark client*/
					iter_num = d["iter_num"].GetInt();
				}
				else if(d.HasMember("syn0Update")){/*processing request for the syn0 data*/
				 	printf("Syn0Update request received!\n");	
				 	FILE* fp;	
					char * filename_syn0 = "/tmp/w2v/syn0Updated";
					int syn_size = vocab_size * layer1_size_aligned;
					if((fp = fopen(filename_syn0,"w"))==NULL){
                                		printf("Cannot open file.\n");
                       			}
                        		else{
                                		printf("Writing syn0updated to file array of size : %d\n",syn_size);
                                		for(int i=0;i<syn_size;i++){
                                        		fprintf(fp,"%f\n",syn0[i]);
                                		}
                                		fclose(fp);
						StringBuffer sb;
						Writer<StringBuffer> writer(sb);
						writer.StartObject();
						/*Writing syn0 filename*/
						writer.Key("syn0");
						writer.String(filename_syn0);
						/*Writing syn0 bitvector*/
						writer.Key("syn0BitVectorJson");
						writer.StartArray();
						for(int i =0; i < vocab_size; i++)
						{
							if(g_syn0_bitmap.getBit(i) == 1)
							 	writer.Int(1);	
							else
								writer.Int(0);	
						}
						writer.EndArray();
						/*Writing syn_size*/	
						writer.Key("size");
						writer.Int(syn_size);
						writer.EndObject();
						const char * synOutput = sb.GetString(); 
						zmq_msg_init_size (&response, strlen(synOutput));
						memcpy ((void *) zmq_msg_data (&response), synOutput, strlen(synOutput));
                        		}	
				}
				else if(d.HasMember("syn1Update")){/*processing request for the syn1 data*/
				 	printf("Syn1Update request received!\n");	
				 	FILE* fp;	
					char * filename_syn1neg = "/tmp/w2v/syn1negUpdated";
					int syn_size = vocab_size * layer1_size_aligned;
					if((fp = fopen(filename_syn1neg,"w"))==NULL){
                                		printf("Cannot open file.\n");
                       			}
                        		else{
                                		printf("Writing syn1negupdated to file array of size : %d\n",syn_size);
                                		for(int i=0;i<syn_size;i++){
                                        		fprintf(fp,"%f\n",syn1neg[i]);
                                		}
                                		fclose(fp);
						StringBuffer sb;
						Writer<StringBuffer> writer(sb);
						writer.StartObject();
						/*Writing syn1neg filename*/
						writer.Key("syn1");
						writer.String(filename_syn1neg);
						/*Writing syn1neg bitvector*/
						writer.Key("syn1BitVectorJson");
						writer.StartArray();
						for(int i =0; i < vocab_size; i++)
						{
							if(g_syn1neg_bitmap.getBit(i) == 1)
							 	writer.Int(1);	
							else
								writer.Int(0);	
						}
						writer.EndArray();
						/*Writing syn_size*/	
						writer.Key("size");
						writer.Int(syn_size);
						writer.EndObject();
						const char * synOutput = sb.GetString(); 
						zmq_msg_init_size (&response, strlen(synOutput));
						memcpy ((void *) zmq_msg_data (&response), synOutput, strlen(synOutput));
                        		}
					iterCount++;
					iteration_finished=true;	
				}
				else if(d.HasMember("foldComplete")){/*processing request for the syn0 data*/
					printf("foldComplete received! Calling getResultData..\n");
					//printf("Printing syn0StartIndex before modification : %d and %d\n",syn0StartIndex,syn0EndIndex);
					iteration_finished=false;//Setting it to false to indicate that syn0,syn1 start and end indexes should not be reset while processing foldComplete_1	
					int syn_size = vocab_size * layer1_size_aligned;
					while(syn0EndIndex!=syn_size-1){
						StringBuffer sb;
						Writer<StringBuffer> writer(sb);
						writer.StartObject();
						syn0EndIndex = (syn0StartIndex+max_syn_size_to_send < syn_size) ? syn0StartIndex+max_syn_size_to_send-1 : syn_size-1;				
						writer.Key("syn0");
						writer.StartArray();	
						for(int i=0;i<=syn0EndIndex-syn0StartIndex;i++){
							writer.Double(syn0[i+syn0StartIndex]);
						}
						writer.EndArray();
						writer.Key("syn0BitVectorJson");
						writer.StartArray();
						if(syn0EndIndex==syn_size-1){
							for(int i =0; i < vocab_size; i++)
							{
								if(g_syn0_bitmap.getBit(i) == 1)
								 	writer.Int(1);	
								else
									writer.Int(0);	
							}
						}
						writer.EndArray();
						/* Add syn0 and syn1neg bit vectors */
						writer.Key("start");
						writer.Int(syn0StartIndex);
						writer.Key("end");
						writer.Int(syn0EndIndex);
						writer.Key("size");
						writer.Int(syn_size);
						writer.EndObject();
						const char * synOutput = sb.GetString(); 
						zmq_msg_init_size (&response, strlen(synOutput));
						memcpy ((void *) zmq_msg_data (&response), synOutput, strlen(synOutput));
						//printf("Printing syn0StartIndex : %d and %d\n",syn0StartIndex,syn0EndIndex);			
						if(syn0EndIndex!=syn_size-1){
							//printf("syn0EndIndex : %d, syn_size : %d\n",syn0EndIndex,syn_size);	
							zmq_sendmsg(responder, &response, ZMQ_SNDMORE);		
						}	
						syn0StartIndex = syn0EndIndex+1;
					}
					//iterCount++;
				}
				else if(d.HasMember("foldComplete_1")){/*receiving request for syn1 values*/
					printf("foldComplete_1 received! Calling getResultData..\n");

					int syn_size = vocab_size * layer1_size_aligned;
					while(!iteration_finished){
						//printf("Printing syn1EndIndex : %d and syn_size : %d \n",syn1EndIndex,syn_size);
						StringBuffer sb;
						Writer<StringBuffer> writer(sb);
						writer.StartObject();
						syn1EndIndex = (syn1StartIndex+max_syn_size_to_send < syn_size) ? syn1StartIndex+max_syn_size_to_send-1 : syn_size-1;				
						writer.Key("syn1");
						writer.StartArray();	
						for(int i=0;i<=syn1EndIndex-syn1StartIndex;i++){
							//syn1Json[Json::ArrayIndex(i)] = (float)syn1neg[i+syn1StartIndex];
							writer.Double(syn1neg[i+syn1StartIndex]);
						}
						writer.EndArray();
					 	writer.Key("syn1BitVectorJson");	
					 	writer.StartArray();
						if(syn1EndIndex==syn_size-1){
							for(int i =0; i < vocab_size; i++)
							{
								if(g_syn1neg_bitmap.getBit(i) == 1)
									writer.Int(1);	
								else
									writer.Int(0);	
							}
							/*At this point, a single iteration of the client has completed. Therefore, we increment iterCount here. Also syn0 and syn1 start and end indexes has to be reset to 0 for the next iteration*/
							iterCount++;
							iteration_finished=true;
						}
					 	writer.EndArray();
						/* Add syn0 and syn1neg bit vectors */
						writer.Key("start");
						writer.Int(syn1StartIndex);
						writer.Key("end");
						writer.Int(syn1EndIndex);
						writer.Key("size");
						writer.Int(syn_size);
						writer.EndObject();
						const char * synOutput = sb.GetString();	
						zmq_msg_init_size (&response, strlen(synOutput));
						memcpy ((void *) zmq_msg_data (&response), synOutput, strlen(synOutput));
						//printf("Before sending the msgs!\n");						
						if(syn1EndIndex!=syn_size-1){
							zmq_sendmsg(responder, &response, ZMQ_SNDMORE);
						}
						syn1StartIndex = syn1EndIndex+1;
						//iterCount++;
						if(iteration_finished){
							syn0StartIndex=0;
							syn0EndIndex=0;
							syn1StartIndex=0;
							syn1EndIndex=0;
						}
					}
				}
				else{
					printf("\n\n Unfaimiliar Message received!!\n");
				}	

			}
			else{
				printf("\n\n Message received!!!!!!\n");
			}	
			int rc = zmq_getsockopt (responder, ZMQ_RCVMORE, &more, &more_size);
			assert (rc == 0);
			count++;
		} while(more);
		printf("Sending response \n");
		zmq_sendmsg(responder, &response, 0);	
	}
	return 0;
}
